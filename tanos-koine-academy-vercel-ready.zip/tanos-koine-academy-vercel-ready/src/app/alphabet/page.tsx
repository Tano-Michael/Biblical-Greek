import { AlphabetLab } from "@/components/AlphabetLab";
import { ALPHABET, DIPHTHONGS, PRONUNCIATION_SYSTEMS } from "@/lib/content/alphabet";
import { MEDIA_LIBRARY } from "@/lib/content/media";

export const metadata = {
  title: "Alphabet Lab",
  description:
    "Interactive Greek alphabet with audio for every letter, three pronunciation systems side by side, diphthongs, breathings and accents.",
};

export default function AlphabetPage() {
  const videos = MEDIA_LIBRARY.filter((m) => m.category === "pronunciation" && m.youtubeId);
  return (
    <AlphabetLab
      letters={ALPHABET}
      diphthongs={DIPHTHONGS}
      systems={PRONUNCIATION_SYSTEMS.map((s) => ({ ...s }))}
      videos={videos.map((v) => ({
        id: v.youtubeId!,
        title: v.title,
        channel: v.creator,
        note: v.description,
      }))}
    />
  );
}
