"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { emptyProgress, readProgress, subscribeProgress } from "@/lib/localProgress";
import { LESSONS, TRACKS, lessonsForTrack } from "@/lib/content/curriculum";


const KIND_LABEL: Record<string, string> = {
  orientation: "Orientation",
  phonology: "Sound & script",
  morphology: "Forms",
  syntax: "Syntax",
  reading: "Reading",
  immersion: "Immersion",
  seminar: "Seminar",
};

export default function LearnPage() {
  const [progress, setProgress] = useState(() => emptyProgress());

  useEffect(() => {
    const refresh = () => setProgress(readProgress());
    refresh();
    return subscribeProgress(refresh);
  }, []);

  const completed = useMemo(
    () => new Set(Object.keys(progress.completedLessons)),
    [progress.completedLessons],
  );
  const started = completed;

  const totalMinutes = LESSONS.reduce((sum, l) => sum + l.minutes, 0);
  const totalVideos = LESSONS.reduce((sum, l) => sum + l.videos.length, 0);

  return (
    <div className="space-y-10">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Πρόγραμμα</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">The Curriculum</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          {LESSONS.length} lessons · {totalVideos} curated videos · roughly {Math.round(totalMinutes / 60)}{" "}
          hours of guided study, plus unlimited drilling. Work top to bottom, or jump to whichever track
          matches where you are. Every lesson ends in real New Testament text.
        </p>
      </header>

      {TRACKS.map((track) => {
        const trackLessons = lessonsForTrack(track.id);
        const done = trackLessons.filter((l) => completed.has(l.slug)).length;
        return (
          <section key={track.id} id={track.id} className="scroll-mt-24">
            <div className="panel relative overflow-hidden rounded-2xl p-5">
              <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${track.accent}`} aria-hidden />
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="greek text-xs tracking-[0.25em] text-slate-500">{track.greekName}</p>
                  <h2 className="mt-1 text-xl font-semibold text-slate-100">
                    {track.name}
                    <span className="ml-2 text-sm font-normal text-slate-500">{track.tagline}</span>
                  </h2>
                </div>
                <span className={`rounded-full border px-3 py-1 text-xs ${track.chip}`}>
                  {done} of {trackLessons.length} complete
                </span>
              </div>
              <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">{track.description}</p>
            </div>

            <ol className="mt-4 grid gap-3 lg:grid-cols-2">
              {trackLessons.map((lesson, i) => {
                const isDone = completed.has(lesson.slug);
                const inProgress = !isDone && started.has(lesson.slug);
                return (
                  <li key={lesson.slug}>
                    <Link
                      href={`/learn/${lesson.slug}`}
                      className="panel panel-hover group flex h-full gap-4 rounded-2xl p-4 transition"
                    >
                      <span
                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-semibold ${
                          isDone
                            ? "bg-emerald-500/20 text-emerald-300"
                            : inProgress
                              ? "bg-amber-500/20 text-amber-300"
                              : "bg-white/5 text-slate-400"
                        }`}
                      >
                        {isDone ? "✓" : i + 1}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="text-sm font-semibold text-slate-100 group-hover:text-amber-100">
                            {lesson.title}
                          </h3>
                          <span className="greek text-xs text-slate-500">{lesson.greekTitle}</span>
                        </div>
                        <p className="mt-1 text-xs leading-relaxed text-slate-400">{lesson.summary}</p>
                        <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[10px] text-slate-500">
                          <span className="rounded-md bg-white/5 px-2 py-0.5">
                            {KIND_LABEL[lesson.kind] ?? lesson.kind}
                          </span>
                          <span className="rounded-md bg-white/5 px-2 py-0.5">{lesson.minutes} min</span>
                          <span className="rounded-md bg-white/5 px-2 py-0.5">
                            🎬 {lesson.videos.length} video{lesson.videos.length > 1 ? "s" : ""}
                          </span>
                          <span className="rounded-md bg-white/5 px-2 py-0.5">
                            🔊 {lesson.listening.length} audio drills
                          </span>
                          {lesson.reading && (
                            <span className="rounded-md bg-white/5 px-2 py-0.5">📖 {lesson.reading.ref}</span>
                          )}
                        </div>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ol>
          </section>
        );
      })}
    </div>
  );
}
