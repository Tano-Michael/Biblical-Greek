import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { LESSONS, LESSONS_BY_SLUG, TRACK_BY_ID } from "@/lib/content/curriculum";
import { VOCAB_BY_ID } from "@/lib/content/vocabulary";
import { LessonView } from "@/components/LessonView";



export function generateStaticParams() {
  return LESSONS.map((lesson) => ({ slug: lesson.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const lesson = LESSONS_BY_SLUG[slug];
  if (!lesson) return { title: "Lesson not found" };
  return { title: lesson.title, description: lesson.summary };
}

export default async function LessonPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const lesson = LESSONS_BY_SLUG[slug];
  if (!lesson) notFound();

  const track = TRACK_BY_ID[lesson.trackId];
  const index = LESSONS.findIndex((l) => l.slug === slug);
  const prev = index > 0 ? LESSONS[index - 1] : null;
  const next = index < LESSONS.length - 1 ? LESSONS[index + 1] : null;

  const vocab = lesson.vocabIds.map((id) => VOCAB_BY_ID[id]).filter(Boolean);

  return (
    <LessonView
      lesson={lesson}
      vocab={vocab}
      trackName={track.name}
      trackChip={track.chip}
      trackAccent={track.accent}
      prev={prev ? { slug: prev.slug, title: prev.title } : null}
      next={next ? { slug: next.slug, title: next.title } : null}
      initiallyCompleted={false}
      position={index + 1}
      total={LESSONS.length}
    />
  );
}
