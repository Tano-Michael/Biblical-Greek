import { LeaderboardView } from "@/components/LeaderboardView";

export const metadata = {
  title: "Progress Board",
  description:
    "Review your XP, weekly activity, streak, completed lessons and personal game records in Tano's Koine Academy.",
};

export default function ProgressPage() {
  return (
    <div className="space-y-6">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Πρόοδος</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Your Progress Board</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          XP from lessons, reviews, assignments and games is saved automatically in this browser. Your weekly
          activity, streak, completed lessons and personal game records are collected here.
        </p>
      </header>
      <div className="rounded-2xl border border-sky-400/20 bg-sky-400/[0.07] p-4 text-xs leading-relaxed text-sky-100/80">
        Privacy note: this zero-setup Vercel edition stores learning progress on the learner&apos;s device. It does
        not require an account or database, and the data is not shared between browsers.
      </div>
      <LeaderboardView />
    </div>
  );
}
