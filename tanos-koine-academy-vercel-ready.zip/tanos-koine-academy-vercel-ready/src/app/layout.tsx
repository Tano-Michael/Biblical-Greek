import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SiteNav } from "@/components/SiteNav";

export const metadata: Metadata = {
  applicationName: "Tano's Koine Academy",
  manifest: "/site.webmanifest",
  icons: { icon: "/favicon.svg" },
  title: {
    default: "Tano's Koine Academy — Learn Biblical Greek",
    template: "%s — Tano's Koine Academy",
  },
  description:
    "Tano's Koine Academy teaches Biblical Greek from beginner to scholar through deep written guides, English-to-Greek comparisons, video, corrected Greek audio, assignments, flashcards, an interlinear reader, and parsing practice.",
  openGraph: {
    title: "Tano's Koine Academy",
    description: "Learn Biblical Greek from beginner to scholar through reading, hearing, speaking, assignments, and spaced-repetition flashcards.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#070a12] text-slate-200 antialiased">
        <SiteNav />
        <main className="mx-auto w-full max-w-7xl px-4 pb-24 pt-6 sm:px-6">{children}</main>
        <footer className="border-t border-white/10 py-8 text-center text-xs text-slate-500">
          <p className="greek text-base text-slate-400">ἡ ἀρχὴ ἥμισυ παντός</p>
          <p className="mt-1">
            The beginning is half of the whole. Built for learners of the Greek New Testament.
          </p>
          <p className="mt-2 text-[11px] text-slate-600">Progress is saved privately in this browser.</p>
        </footer>
      </body>
    </html>
  );
}
