import { ReaderView } from "@/components/ReaderView";
import { PASSAGES } from "@/lib/content/readings";

export const metadata = {
  title: "Interlinear Reader",
  description:
    "Read the Greek New Testament with tap-to-parse interlinear glosses and spoken audio for every verse.",
};

export default function ReaderPage() {
  return <ReaderView passages={PASSAGES} />;
}
