import { LessonCardsBrowser } from "@/components/LessonCardsBrowser";
import { LESSONS } from "@/lib/content/curriculum";


export const metadata = {
  title: "Flashcards",
  description:
    "All lesson flashcards — words, forms, concepts, sentences — with spaced repetition. The fastest way to make Greek feel like English.",
};

export default function FlashcardsPage() {
  return <LessonCardsBrowser lessons={LESSONS.map((l) => ({ slug: l.slug, title: l.title, greekTitle: l.greekTitle, trackId: l.trackId }))} />;
}
