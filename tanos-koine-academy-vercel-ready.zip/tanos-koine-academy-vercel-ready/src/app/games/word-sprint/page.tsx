import { GameWordSprint } from "@/components/GameWordSprint";
import { VOCABULARY } from "@/lib/content/vocabulary";

export const metadata = {
  title: "Word Sprint",
  description: "Match New Testament Greek words to their meanings in a 60-second combo-building sprint.",
};

export default function WordSprintPage() {
  return <GameWordSprint pool={VOCABULARY} />;
}
