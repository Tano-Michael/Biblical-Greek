"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { emptyProgress, readProgress, subscribeProgress } from "@/lib/localProgress";
import { GAMES } from "@/lib/games";




export default function GamesPage() {
  const [progress, setProgress] = useState(() => emptyProgress());

  useEffect(() => {
    const refresh = () => setProgress(readProgress());
    refresh();
    return subscribeProgress(refresh);
  }, []);

  const bests = useMemo(() => {
    const result: Record<string, { best: number; plays: number }> = {};
    for (const [game, stats] of Object.entries(progress.games)) {
      if (stats) result[game] = { best: stats.best, plays: stats.plays };
    }
    return result;
  }, [progress.games]);

  const totalPlays = Object.values(bests).reduce((n, b) => n + b.plays, 0);

  return (
    <div className="space-y-8">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Ἀγῶνες</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Games Arena</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          Short bursts of competition make vocabulary and morphology stick. Every game earns real XP toward
          your total and your personal records. Beat yesterday's score and keep improving.
        </p>
      </header>

      <div className="grid gap-4 md:grid-cols-3">
        {GAMES.map((game) => {
          const stats = bests[game.id];
          return (
            <Link
              key={game.id}
              href={`/games/${game.id}`}
              className="panel panel-hover group flex h-full flex-col rounded-3xl p-6 transition"
            >
              <div className="flex items-start justify-between">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400/20 to-orange-500/10 text-3xl ring-1 ring-amber-400/20">
                  {game.emoji}
                </span>
                {stats ? (
                  <div className="text-right">
                    <p className="text-xl font-bold text-amber-300">{stats.best}</p>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500">
                      personal best · {stats.plays}×
                    </p>
                  </div>
                ) : (
                  <span className="rounded-full border border-sky-400/30 bg-sky-400/10 px-2.5 py-1 text-[10px] text-sky-300">
                    unplayed
                  </span>
                )}
              </div>
              <p className="greek mt-4 text-xs tracking-[0.25em] text-amber-400/70">{game.greekName}</p>
              <h2 className="mt-1 text-xl font-semibold text-slate-100 group-hover:text-amber-100">
                {game.name}
              </h2>
              <p className="mt-1 text-xs text-slate-500">{game.tagline}</p>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-slate-400">{game.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="rounded-md bg-white/5 px-2 py-1 text-[10px] uppercase tracking-wider text-slate-400">
                  {game.skill}
                </span>
                <span className="text-sm font-semibold text-amber-300 transition group-hover:translate-x-1">
                  Play →
                </span>
              </div>
            </Link>
          );
        })}
      </div>

      <div className="panel grid gap-4 rounded-3xl p-6 sm:grid-cols-[1fr_auto] sm:items-center">
        <div>
          <h3 className="text-lg font-semibold text-slate-100">Review your personal records</h3>
          <p className="mt-1 text-sm text-slate-400">
            {totalPlays > 0
              ? `You've played ${totalPlays} game${totalPlays === 1 ? "" : "s"}. Open your progress board to review your XP, streak and best scores.`
              : "Your progress board tracks XP, weekly activity, streaks and every personal best on this device."}
          </p>
        </div>
        <Link
          href="/leaderboard"
          className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-5 py-3 text-center text-sm font-semibold text-slate-950 transition hover:brightness-110"
        >
          🏆 Open progress board
        </Link>
      </div>
    </div>
  );
}
