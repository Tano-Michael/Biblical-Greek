import { GameSentenceScramble, type ScrambleRound } from "@/components/GameSentenceScramble";
import { PASSAGES } from "@/lib/content/readings";

export const metadata = {
  title: "Sentence Scramble",
  description: "Rebuild real Greek New Testament verses word by word and hear them read aloud.",
};

function round(passage: string, verseIndex: number): ScrambleRound {
  const verse = PASSAGES.find((p) => p.id === passage)!.verses[verseIndex];
  return {
    ref: `${PASSAGES.find((p) => p.id === passage)!.reference.split(" ")[0]} ${verse.ref}`,
    words: verse.words.map((w) => w.g),
    english: verse.english,
  };
}

const ROUNDS: ScrambleRound[] = [
  round("john-1", 1), // John 1:2 — 7 words
  round("mark-1", 0), // Mark 1:1 — 7 words
  round("lords-prayer", 2), // Matt 6:11 — 8 words
  round("lords-prayer", 0), // Matt 6:9 — 10 words
  round("john-1", 3), // John 1:4 — 12 words
  round("john-1", 0), // John 1:1 — the iconic finale
];

export default function SentenceScramblePage() {
  return <GameSentenceScramble rounds={ROUNDS} />;
}
