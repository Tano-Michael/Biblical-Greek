import { GameParsingRush } from "@/components/GameParsingRush";
import { ALL_DRILLS } from "@/lib/content/parsing";

export const metadata = {
  title: "Parsing Rush",
  description: "Parse Greek noun and verb forms against a 45-second timer with combo scoring.",
};

export default function ParsingRushPage() {
  return <GameParsingRush drills={ALL_DRILLS} />;
}
