"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { emptyProgress, getActivityHeatmap, readProgress, subscribeProgress } from "@/lib/localProgress";
import { LESSONS, TRACKS, lessonsForTrack } from "@/lib/content/curriculum";
import { VOCABULARY } from "@/lib/content/vocabulary";
import { MEDIA_LIBRARY } from "@/lib/content/media";
import { GreekAudioProvider, SpeakButton } from "@/components/GreekAudio";
import { VideoEmbed } from "@/components/VideoEmbed";


const VERSE_OF_DAY = [
  { greek: "Ἐν ἀρχῇ ἦν ὁ λόγος", english: "In the beginning was the Word", ref: "John 1:1" },
  { greek: "ὁ θεὸς ἀγάπη ἐστίν", english: "God is love", ref: "1 John 4:8" },
  { greek: "τετέλεσται", english: "It is finished", ref: "John 19:30" },
  { greek: "ὁ κύριος ποιμαίνει με", english: "The Lord shepherds me", ref: "Psalm 22:1 LXX" },
  { greek: "χάρις ὑμῖν καὶ εἰρήνη", english: "Grace to you and peace", ref: "Romans 1:7" },
  { greek: "μακάριοι οἱ καθαροὶ τῇ καρδίᾳ", english: "Blessed are the pure in heart", ref: "Matthew 5:8" },
  { greek: "ἐγώ εἰμι τὸ φῶς τοῦ κόσμου", english: "I am the light of the world", ref: "John 8:12" },
];

export default function DashboardPage() {
  const [progress, setProgress] = useState(() => emptyProgress());

  useEffect(() => {
    const refresh = () => setProgress(readProgress());
    refresh();
    return subscribeProgress(refresh);
  }, []);

  const completedSlugs = useMemo(
    () => new Set(Object.keys(progress.completedLessons)),
    [progress.completedLessons],
  );
  const now = Date.now();
  const dueCount = Object.values(progress.srs).filter(
    (card) => new Date(card.dueAt).getTime() <= now,
  ).length;
  const cardCount = Object.keys(progress.srs).length;
  const heat = getActivityHeatmap(84, progress);

  const nextLesson = LESSONS.find((lesson) => !completedSlugs.has(lesson.slug)) ?? LESSONS[0];
  const verse = VERSE_OF_DAY[new Date().getDate() % VERSE_OF_DAY.length];
  const featured = MEDIA_LIBRARY.find((m) => m.id === "lumo-mark-1")!;
  const pct = Math.round((completedSlugs.size / LESSONS.length) * 100);

  return (
    <GreekAudioProvider>
      <div className="space-y-10">
        {/* Hero */}
        <section className="rise relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-6 sm:p-10">
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-amber-500/10 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-32 -left-20 h-72 w-72 rounded-full bg-sky-500/10 blur-3xl" />
          <div className="relative grid gap-8 lg:grid-cols-[1.25fr_1fr]">
            <div>
              <p className="text-[11px] font-medium uppercase tracking-[0.28em] text-amber-400/80">
                Biblical Greek · Beginner → Scholar
              </p>
              <h1 className="greek mt-3 text-4xl leading-tight font-semibold text-slate-50 sm:text-6xl">
                Μάθε τὴν κοινὴν διάλεκτον
              </h1>
              <p className="mt-3 max-w-xl text-base leading-relaxed text-slate-400">
                Learn to read, hear and speak the Greek of the New Testament. {LESSONS.length} lessons across
                four tracks and {LESSONS.reduce((n, l) => n + l.videos.length, 0)} hand-picked videos — every
                one built on curated film, spoken audio drills, spaced-repetition vocabulary and real text.
                Never text alone.
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  href={`/learn/${nextLesson.slug}`}
                  className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-5 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:brightness-110"
                >
                  {completedSlugs.size ? "Continue" : "Start"} · {nextLesson.title.split(":")[0]}
                </Link>
                <Link
                  href="/vocabulary"
                  className="rounded-xl border border-white/15 px-5 py-3 text-sm font-semibold text-slate-200 transition hover:border-amber-400/50 hover:text-amber-200"
                >
                  Review vocabulary{dueCount ? ` · ${dueCount} due` : ""}
                </Link>
                <Link
                  href="/alphabet"
                  className="rounded-xl border border-white/15 px-5 py-3 text-sm font-semibold text-slate-200 transition hover:border-sky-400/50 hover:text-sky-200"
                >
                  Alphabet Lab
                </Link>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Stat label="Lessons done" value={`${completedSlugs.size}/${LESSONS.length}`} />
                <Stat label="Day streak" value={String(progress.streak)} accent="text-orange-300" />
                <Stat label="XP earned" value={String(progress.xp)} accent="text-emerald-300" />
                <Stat label="Words in SRS" value={`${cardCount}/${VOCABULARY.length}`} accent="text-sky-300" />
              </div>
            </div>

            <div className="space-y-4">
              <div className="panel rounded-2xl p-5">
                <p className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Verse of the day</p>
                <div className="mt-3 flex items-start gap-3">
                  <SpeakButton text={verse.greek} size="lg" />
                  <div>
                    <p className="greek text-2xl leading-snug text-amber-100">{verse.greek}</p>
                    <p className="mt-1 text-sm text-slate-400">{verse.english}</p>
                    <p className="mt-1 text-xs text-slate-600">{verse.ref}</p>
                  </div>
                </div>
              </div>

              <div className="panel rounded-2xl p-5">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Course progress</span>
                  <span className="font-semibold text-amber-300">{pct}%</span>
                </div>
                <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500 transition-all"
                    style={{ width: `${Math.max(pct, 2)}%` }}
                  />
                </div>
                {heat.length > 0 && (
                  <>
                    <p className="mt-5 text-[11px] uppercase tracking-[0.2em] text-slate-500">
                      Last 12 weeks
                    </p>
                    <div className="mt-2 grid grid-flow-col grid-rows-7 gap-[3px]">
                      {heat.map((cell) => (
                        <span
                          key={cell.day}
                          title={`${cell.day}: ${cell.xp} XP`}
                          className={`h-2.5 w-2.5 rounded-[3px] ${
                            cell.xp === 0
                              ? "bg-white/6"
                              : cell.xp < 10
                                ? "bg-amber-500/30"
                                : cell.xp < 30
                                  ? "bg-amber-500/55"
                                  : cell.xp < 60
                                    ? "bg-amber-400/80"
                                    : "bg-amber-300"
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Tracks */}
        <section>
          <SectionHeading
            greek="Ἡ ὁδός"
            title="The path from zero to scholarship"
            subtitle="Four tracks, twenty-two lessons. Each combines curated video, spoken drills, grammar, and real New Testament text."
          />
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {TRACKS.map((track) => {
              const trackLessons = lessonsForTrack(track.id);
              const done = trackLessons.filter((l) => completedSlugs.has(l.slug)).length;
              const trackPct = Math.round((done / trackLessons.length) * 100);
              return (
                <Link
                  key={track.id}
                  href={`/learn#${track.id}`}
                  className="panel panel-hover group relative overflow-hidden rounded-2xl p-5 transition"
                >
                  <div
                    className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${track.accent}`}
                    aria-hidden
                  />
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="greek text-sm tracking-[0.2em] text-slate-500">{track.greekName}</p>
                      <h3 className="mt-1 text-lg font-semibold text-slate-100">{track.name}</h3>
                      <p className="text-xs text-slate-500">{track.tagline}</p>
                    </div>
                    <span className={`rounded-full border px-2.5 py-1 text-[11px] ${track.chip}`}>
                      {done}/{trackLessons.length}
                    </span>
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-slate-400">{track.description}</p>
                  <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-white/8">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${track.accent}`}
                      style={{ width: `${Math.max(trackPct, 1)}%` }}
                    />
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

        {/* Featured media + quick tools */}
        <section className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <div>
            <SectionHeading
              greek="Θέαμα"
              title="Watch the Gospel in Koine"
              subtitle="Benjamin Kantor's LUMO project films dubbed in reconstructed first-century pronunciation — the best immersion resource that exists."
            />
            <div className="mt-5">
              <VideoEmbed
                id={featured.youtubeId!}
                kind="video"
                title={featured.title}
                channel={featured.creator}
                note={featured.description}
              />
            </div>
          </div>

          <div>
            <SectionHeading greek="Ἐργαλεῖα" title="Practice tools" subtitle="Short daily sessions beat long weekend cramming." />
            <div className="mt-5 grid gap-3">
              <ToolCard
                href="/vocabulary"
                emoji="🃏"
                title="Spaced-repetition vocabulary"
                body={`${VOCABULARY.length} frequency-ranked New Testament words with audio, SM-2 scheduling and typed recall.`}
                badge={dueCount ? `${dueCount} due now` : "Start a deck"}
              />
              <ToolCard
                href="/games"
                emoji="🎮"
                title="Games arena"
                body="Word Sprint, Sentence Scramble and Parsing Rush — timed competitions that convert to XP."
                badge="3 games"
              />
              <ToolCard
                href="/leaderboard"
                emoji="🏆"
                title="Progress board"
                body="See your XP, weekly activity, streak, completed lessons and personal game records."
                badge="Saved on device"
              />
              <ToolCard
                href="/parsing"
                emoji="🏋️"
                title="Parsing gym"
                body="Timed drills on verb and noun forms — case, number, gender, tense, voice, mood."
                badge="Endless drills"
              />
              <ToolCard
                href="/reader"
                emoji="📖"
                title="Interlinear reader"
                body="Tap any word for its lemma and full parsing, hear the verse read aloud, then hide the glosses."
                badge="4 passages"
              />
              <ToolCard
                href="/library"
                emoji="🎧"
                title="Media library"
                body="Complete audio New Testaments, immersion channels, full free video courses and scholarly lectures."
                badge={`${MEDIA_LIBRARY.length} resources`}
              />
            </div>
          </div>
        </section>
      </div>
    </GreekAudioProvider>
  );
}

function Stat({ label, value, accent = "text-amber-300" }: { label: string; value: string; accent?: string }) {
  return (
    <div className="panel rounded-xl px-3 py-3">
      <p className={`text-xl font-semibold ${accent}`}>{value}</p>
      <p className="mt-0.5 text-[11px] uppercase tracking-wider text-slate-500">{label}</p>
    </div>
  );
}

export function SectionHeading({
  greek,
  title,
  subtitle,
}: {
  greek: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div>
      <p className="greek text-sm tracking-[0.25em] text-amber-400/70">{greek}</p>
      <h2 className="mt-1 text-2xl font-semibold text-slate-100">{title}</h2>
      {subtitle && <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-slate-400">{subtitle}</p>}
    </div>
  );
}

function ToolCard({
  href,
  emoji,
  title,
  body,
  badge,
}: {
  href: string;
  emoji: string;
  title: string;
  body: string;
  badge: string;
}) {
  return (
    <Link href={href} className="panel panel-hover flex items-start gap-4 rounded-2xl p-4 transition">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/5 text-xl">
        {emoji}
      </span>
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-sm font-semibold text-slate-100">{title}</h3>
          <span className="rounded-full border border-amber-400/25 bg-amber-400/10 px-2 py-0.5 text-[10px] text-amber-300">
            {badge}
          </span>
        </div>
        <p className="mt-1 text-xs leading-relaxed text-slate-400">{body}</p>
      </div>
    </Link>
  );
}
