import { LibraryView } from "@/components/LibraryView";
import { MEDIA_LIBRARY } from "@/lib/content/media";

export const metadata = {
  title: "Media Library",
  description:
    "Curated free Koine Greek video and audio: complete audio New Testaments, full video courses, immersion channels and scholarly lectures.",
};

export default function LibraryPage() {
  return <LibraryView items={MEDIA_LIBRARY} />;
}
