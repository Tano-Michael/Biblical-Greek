import { ParsingGym } from "@/components/ParsingGym";
import { ALL_DRILLS } from "@/lib/content/parsing";

export const metadata = {
  title: "Parsing Gym",
  description:
    "Timed parsing drills for Greek nouns and verbs: case, number, gender, tense-form, voice, mood and person.",
};

export default function ParsingPage() {
  return <ParsingGym drills={ALL_DRILLS} />;
}
