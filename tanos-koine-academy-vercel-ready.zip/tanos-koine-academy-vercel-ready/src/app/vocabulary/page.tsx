import { VocabTrainer } from "@/components/VocabTrainer";
import { VOCABULARY } from "@/lib/content/vocabulary";


export const metadata = {
  title: "Vocabulary Trainer",
  description:
    "Spaced-repetition drilling for the high-frequency vocabulary of the Greek New Testament, with audio on every card.",
};

export default function VocabularyPage() {
  return <VocabTrainer library={VOCABULARY} />;
}
