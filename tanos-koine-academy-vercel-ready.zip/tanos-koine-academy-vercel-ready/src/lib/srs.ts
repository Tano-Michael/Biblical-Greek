export type Rating = 0 | 1 | 2 | 3; // again | hard | good | easy

export type CardState = {
  ease: number;
  intervalDays: number;
  reps: number;
  lapses: number;
};

/**
 * A compact SM-2 variant tuned for vocabulary drilling.
 * Returns the next state plus the due date.
 */
export function schedule(card: CardState, rating: Rating, now = new Date()) {
  let { ease, intervalDays, reps, lapses } = card;

  if (rating === 0) {
    lapses += 1;
    reps = 0;
    ease = Math.max(1.3, ease - 0.25);
    intervalDays = 0; // ~10 minutes, handled below
  } else {
    reps += 1;
    if (rating === 1) {
      ease = Math.max(1.3, ease - 0.15);
      intervalDays = reps === 1 ? 0.6 : Math.max(1, intervalDays * 1.2);
    } else if (rating === 2) {
      if (reps === 1) intervalDays = 1;
      else if (reps === 2) intervalDays = 4;
      else intervalDays = Math.round(intervalDays * ease * 10) / 10;
    } else {
      ease = Math.min(3.2, ease + 0.15);
      if (reps === 1) intervalDays = 3;
      else if (reps === 2) intervalDays = 7;
      else intervalDays = Math.round(intervalDays * ease * 1.35 * 10) / 10;
    }
    intervalDays = Math.min(intervalDays, 365);
  }

  const minutes = rating === 0 ? 10 : intervalDays * 24 * 60;
  const dueAt = new Date(now.getTime() + Math.max(minutes, 1) * 60 * 1000);

  return { ease, intervalDays, reps, lapses, dueAt };
}

export const RATING_LABELS: { value: Rating; label: string; hint: string; tone: string }[] = [
  { value: 0, label: "Again", hint: "10 min", tone: "bg-rose-600 hover:bg-rose-500" },
  { value: 1, label: "Hard", hint: "shorter", tone: "bg-amber-600 hover:bg-amber-500" },
  { value: 2, label: "Good", hint: "normal", tone: "bg-emerald-600 hover:bg-emerald-500" },
  { value: 3, label: "Easy", hint: "longer", tone: "bg-sky-600 hover:bg-sky-500" },
];

export function xpForRating(rating: Rating): number {
  return rating === 0 ? 1 : rating === 1 ? 2 : rating === 2 ? 3 : 4;
}
