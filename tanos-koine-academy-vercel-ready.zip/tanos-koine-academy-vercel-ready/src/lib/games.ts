export type GameId = "word-sprint" | "sentence-scramble" | "parsing-rush";

export const GAMES: {
  id: GameId;
  name: string;
  greekName: string;
  emoji: string;
  tagline: string;
  description: string;
  skill: string;
}[] = [
  {
    id: "word-sprint",
    name: "Word Sprint",
    greekName: "ΔΡΟΜΟΣ",
    emoji: "⚡",
    tagline: "60 seconds. Greek → English. Combos.",
    description:
      "How many New Testament words can you match in one minute? Streaks multiply your points — a wrong answer resets your combo and costs you 3 seconds.",
    skill: "Rapid vocabulary recognition",
  },
  {
    id: "sentence-scramble",
    name: "Sentence Scramble",
    greekName: "ΣΥΝΤΑΓΜΑ",
    emoji: "🧩",
    tagline: "Rebuild real verses, word by word.",
    description:
      "Real New Testament sentences get shattered. Put them back together. Word order tells you what mattered to the author — first try pays double.",
    skill: "Word order, cases, and intuition",
  },
  {
    id: "parsing-rush",
    name: "Parsing Rush",
    greekName: "ΤΑΧΟΣ",
    emoji: "🏋️",
    tagline: "45 seconds. Three slots. No mercy.",
    description:
      "Nouns get case · number · gender. Verbs get tense-form · voice · mood. Every correct slot scores; full parses score double.",
    skill: "Morphology under pressure",
  },
];

export const GAME_IDS = GAMES.map((g) => g.id);

/** Convert a game score into XP. Capped so games never out-earn lessons+review. */
export function xpForGameScore(score: number): number {
  return Math.max(0, Math.min(100, Math.round(score / 5)));
}
