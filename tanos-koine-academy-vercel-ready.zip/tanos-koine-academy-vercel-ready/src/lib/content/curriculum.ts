export type MediaKind = "video" | "playlist";

export type LessonVideo = {
  id: string;
  kind: MediaKind;
  title: string;
  channel: string;
  note: string;
};

export type ListenItem = {
  greek: string;
  translit?: string;
  gloss: string;
};

export type GrammarTable = {
  caption: string;
  headers: string[];
  rows: string[][];
};

export type GrammarBlock = {
  heading: string;
  body: string[];
  table?: GrammarTable;
  tip?: string;
};

export type QuizItem = {
  prompt: string;
  greek?: string;
  options: string[];
  answer: number;
  explain: string;
};

export type LessonReading = {
  ref: string;
  intro: string;
  verses: { greek: string; english: string }[];
};

export type Lesson = {
  slug: string;
  trackId: TrackId;
  title: string;
  greekTitle: string;
  summary: string;
  minutes: number;
  kind: "orientation" | "phonology" | "morphology" | "syntax" | "reading" | "immersion" | "seminar";
  objectives: string[];
  videos: LessonVideo[];
  listening: ListenItem[];
  grammar: GrammarBlock[];
  vocabIds: string[];
  reading?: LessonReading;
  quiz: QuizItem[];
};

export type TrackId = "foundations" | "intermediate" | "advanced" | "scholar";

export type Track = {
  id: TrackId;
  name: string;
  greekName: string;
  tagline: string;
  description: string;
  accent: string;
  ring: string;
  chip: string;
};

export const TRACKS: Track[] = [
  {
    id: "foundations",
    name: "Foundations",
    greekName: "ΘΕΜΕΛΙΟΝ",
    tagline: "Alphabet → your first Greek sentence",
    description:
      "Learn to read, hear and pronounce Koine. Master the alphabet, the case system, the article, and the present tense — then read John 1:1 in the original.",
    accent: "from-amber-500 to-orange-600",
    ring: "text-amber-500",
    chip: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  },
  {
    id: "intermediate",
    name: "Intermediate",
    greekName: "ΟΔΟΣ",
    tagline: "The whole verbal system + third declension",
    description:
      "Every tense-form, voice and mood of the Greek verb, plus participles and infinitives — the two constructions that unlock real New Testament prose.",
    accent: "from-sky-500 to-indigo-600",
    ring: "text-sky-400",
    chip: "bg-sky-500/15 text-sky-300 border-sky-500/30",
  },
  {
    id: "advanced",
    name: "Advanced",
    greekName: "ΒΑΘΟΣ",
    tagline: "Syntax, aspect, discourse & fluent reading",
    description:
      "Move from decoding to reading. Exegetical syntax of the cases, verbal aspect theory, discourse grammar, and sustained immersion in the Greek text.",
    accent: "from-emerald-500 to-teal-600",
    ring: "text-emerald-400",
    chip: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  },
  {
    id: "scholar",
    name: "Scholar",
    greekName: "ΣΟΦΙΑ",
    tagline: "Textual criticism, LXX, papyri, research",
    description:
      "The working toolkit of a New Testament scholar: manuscripts and text-critical method, Septuagint Greek, documentary papyri, and the aspect debate at source level.",
    accent: "from-fuchsia-500 to-purple-600",
    ring: "text-fuchsia-400",
    chip: "bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-500/30",
  },
];

export const TRACK_BY_ID: Record<TrackId, Track> = Object.fromEntries(
  TRACKS.map((t) => [t.id, t]),
) as Record<TrackId, Track>;

export const LESSONS: Lesson[] = [
  // ══════════════════════ FOUNDATIONS ══════════════════════
  {
    slug: "why-greek",
    trackId: "foundations",
    title: "Why Greek? Orientation & How to Use This Course",
    greekTitle: "Ἀρχή",
    summary:
      "What Koine is, which pronunciation to adopt, and the study loop (watch → listen → drill → read) that will carry you from zero to scholar.",
    minutes: 18,
    kind: "orientation",
    objectives: [
      "Place Koine Greek historically between Classical Attic and Modern Greek",
      "Choose a pronunciation system and stay consistent",
      "Understand the four-step daily loop used by every lesson here",
    ],
    videos: [
      {
        id: "FjGP_fBAVeI",
        kind: "video",
        title: "Basics of Biblical Greek — Session 1: The Greek Language",
        channel: "Zondervan / Bill Mounce",
        note: "The standard opening lecture of the most widely used seminary grammar.",
      },
      {
        id: "tJRq89giHA8",
        kind: "video",
        title: "Erasmian vs. Modern: how a native Greek speaker says 'Koine'",
        channel: "The Professor with the Bow-Tie",
        note: "A quick, honest tour of the pronunciation debate before you commit.",
      },
      {
        id: "MM-aNAJXj8c",
        kind: "video",
        title: "Basics of Biblical Greek — Class Orientation",
        channel: "Bill Mounce",
        note: "How to structure a year of study without burning out.",
      },
    ],
    listening: [
      { greek: "Ἡ κοινὴ διάλεκτος", translit: "hē koinē dialektos", gloss: "the common dialect" },
      { greek: "χαῖρε", translit: "chaire", gloss: "greetings! (lit. rejoice)" },
      { greek: "εἰρήνη ὑμῖν", translit: "eirēnē hymin", gloss: "peace to you" },
      { greek: "ἀρχὴ σοφίας", translit: "archē sophias", gloss: "the beginning of wisdom" },
    ],
    grammar: [
      {
        heading: "What exactly is Koine?",
        body: [
          "Ἡ κοινὴ διάλεκτος — 'the common dialect' — is the Greek that spread across the Mediterranean after Alexander the Great (c. 330 BC) and remained the lingua franca until roughly AD 330.",
          "It is simpler than Classical Attic: the dual number is gone, the optative is dying, prepositions do more of the work that bare cases once did, and vocabulary is more regular.",
          "The New Testament (about 138,000 words), the Septuagint, Josephus, the Apostolic Fathers and thousands of everyday papyrus letters are all written in it. That last group matters: Koine was not a special 'Holy Ghost Greek'. It was the language of tax receipts and shopping lists.",
        ],
        tip: "Total NT vocabulary is ~5,400 words, but just 320 words account for roughly 80% of the text. That is why frequency-ordered vocabulary works so well.",
      },
      {
        heading: "Three pronunciations, one rule",
        body: [
          "Erasmian is the classroom convention in most English-speaking seminaries. It distinguishes every vowel letter artificially so that spelling is easy to hear — but no ancient person ever spoke it.",
          "Restored Koine (Buth, Kantor) reconstructs first-century Judean/Egyptian pronunciation from spelling mistakes in the papyri. It is historically defensible and increasingly common.",
          "Modern Greek pronunciation is what living Greeks use; it is very close to late Koine and gives you a real speech community.",
        ],
        table: {
          caption: "Same letters, three sound systems",
          headers: ["Letter", "Erasmian", "Restored Koine", "Modern"],
          rows: [
            ["η", "ay (as in 'they')", "ee (as in 'see')", "ee"],
            ["υ", "ü / oo", "ü → ee", "ee"],
            ["ει", "ay", "ee", "ee"],
            ["οι", "oy", "ü → ee", "ee"],
            ["β", "b", "v", "v"],
            ["δ", "d", "th (as in 'this')", "th (this)"],
          ],
        },
        tip: "Pick one and stay with it for at least a year. Consistency beats correctness for memory formation. This app's audio uses a modern/late-Koine voice, which is close to Restored Koine.",
      },
      {
        heading: "The loop",
        body: [
          "1. WATCH — a curated video explains the concept in 5–20 minutes.",
          "2. LISTEN — say every Greek form out loud with the audio drill. Greek was heard before it was parsed.",
          "3. DRILL — spaced-repetition vocabulary and parsing exercises keep the forms alive.",
          "4. READ — every lesson ends in real New Testament text, not invented sentences.",
        ],
        tip: "Twenty focused minutes daily beats three hours on Saturday. The streak counter on your dashboard exists for exactly this reason.",
      },
    ],
    vocabIds: ["ho", "kai", "theos", "logos", "en"],
    quiz: [
      {
        prompt: "Roughly how many distinct words make up 80% of the Greek New Testament?",
        options: ["About 320", "About 1,800", "About 5,400", "About 12,000"],
        answer: 0,
        explain:
          "Around 320 lemmas cover ~80% of the running text. Learning frequency-first is the single highest-leverage decision a beginner can make.",
      },
      {
        prompt: "Which statement best describes Erasmian pronunciation?",
        options: [
          "It is the reconstructed first-century pronunciation",
          "It is a teaching convention that separates vowels for clarity, not a historical accent",
          "It is identical to Modern Greek",
          "It was used by the apostle Paul",
        ],
        answer: 1,
        explain:
          "Erasmian maximises spelling transparency in the classroom. Restored Koine (Buth/Kantor) is the historically reconstructed option.",
      },
      {
        prompt: "Koine Greek is best described as…",
        options: [
          "A sacred dialect created for Scripture",
          "The literary Attic of Plato",
          "The common everyday Greek of the Hellenistic and Roman Mediterranean",
          "A medieval Byzantine invention",
        ],
        answer: 2,
        explain:
          "Adolf Deissmann's papyrus discoveries settled this: NT Greek is the ordinary language of ordinary people.",
      },
    ],
  },
  {
    slug: "alphabet",
    trackId: "foundations",
    title: "The Alphabet: Reading and Hearing Every Letter",
    greekTitle: "Τὸ ἀλφάβητον",
    summary:
      "All 24 letters, the final sigma, the seven vowels, and the diphthongs — written, sung and spoken until they are automatic.",
    minutes: 30,
    kind: "phonology",
    objectives: [
      "Write and name all 24 letters in order",
      "Distinguish the seven vowels and the eight common diphthongs",
      "Read unknown Greek words aloud without hesitation",
    ],
    videos: [
      {
        id: "94B26pJM2fg",
        kind: "video",
        title: "The Greek Alphabet (Koine-Era Pronunciation)",
        channel: "Tim McNinch",
        note: "Letter-by-letter with historically reconstructed first-century sounds.",
      },
      {
        id: "3DX0IiTst8s",
        kind: "video",
        title: "Biblical Greek Alphabet (Koine)",
        channel: "Greek For All",
        note: "Clear whiteboard walkthrough including how to write each letter.",
      },
      {
        id: "HxwawakLPxw",
        kind: "video",
        title: "Greek Alphabet Song",
        channel: "Daily Dose of Greek (Rob Plummer)",
        note: "Sing it three times and the order is yours for life.",
      },
      {
        id: "749JoaGOCcg",
        kind: "video",
        title: "The Greek Alphabet Song",
        channel: "Alpha with Angela",
        note: "An all-Greek immersion take on the same material.",
      },
    ],
    listening: [
      { greek: "ἄλφα βῆτα γάμμα δέλτα", gloss: "alpha beta gamma delta" },
      { greek: "ἒ ψιλόν ζῆτα ἦτα θῆτα", gloss: "epsilon zeta eta theta" },
      { greek: "ἰῶτα κάππα λάμβδα μῦ νῦ ξῖ", gloss: "iota kappa lambda mu nu xi" },
      { greek: "ὂ μικρόν πῖ ῥῶ σῖγμα ταῦ", gloss: "omicron pi rho sigma tau" },
      { greek: "ὖ ψιλόν φῖ χῖ ψῖ ὦ μέγα", gloss: "upsilon phi chi psi omega" },
      { greek: "ἄγγελος", translit: "angelos", gloss: "messenger, angel — note γγ = 'ng'" },
      { greek: "ἐγώ εἰμι", translit: "egō eimi", gloss: "I am" },
    ],
    grammar: [
      {
        heading: "The 24 letters",
        body: [
          "Greek is written left to right. Lowercase is what you will read 99% of the time; uppercase appears in manuscripts, inscriptions, and at the start of proper names and paragraphs in printed editions.",
          "Sigma has two lowercase forms: σ inside a word, ς at the end. Ἰησοῦς shows both patterns across its declension.",
        ],
        table: {
          caption: "The Greek alphabet with names and transliteration",
          headers: ["Upper", "Lower", "Name", "Translit"],
          rows: [
            ["Α", "α", "alpha", "a"],
            ["Β", "β", "bēta", "b / v"],
            ["Γ", "γ", "gamma", "g"],
            ["Δ", "δ", "delta", "d"],
            ["Ε", "ε", "epsilon", "e (short)"],
            ["Ζ", "ζ", "zēta", "z"],
            ["Η", "η", "ēta", "ē"],
            ["Θ", "θ", "thēta", "th"],
            ["Ι", "ι", "iōta", "i"],
            ["Κ", "κ", "kappa", "k"],
            ["Λ", "λ", "lambda", "l"],
            ["Μ", "μ", "mu", "m"],
            ["Ν", "ν", "nu", "n"],
            ["Ξ", "ξ", "xi", "x"],
            ["Ο", "ο", "omicron", "o (short)"],
            ["Π", "π", "pi", "p"],
            ["Ρ", "ρ", "rhō", "r"],
            ["Σ", "σ / ς", "sigma", "s"],
            ["Τ", "τ", "tau", "t"],
            ["Υ", "υ", "upsilon", "y / u"],
            ["Φ", "φ", "phi", "ph"],
            ["Χ", "χ", "chi", "ch"],
            ["Ψ", "ψ", "psi", "ps"],
            ["Ω", "ω", "ōmega", "ō"],
          ],
        },
      },
      {
        heading: "Vowels and diphthongs",
        body: [
          "Seven vowels: α ε η ι ο υ ω. Two of them are permanently short (ε, ο), two permanently long (η, ω), and three can be either (α, ι, υ).",
          "A diphthong is two vowels pronounced as one syllable. The second letter is always ι or υ.",
          "Improper diphthongs write the iota underneath (iota subscript): ᾳ ῃ ῳ. The iota is silent but grammatically decisive — it usually marks a dative singular.",
        ],
        table: {
          caption: "Common diphthongs",
          headers: ["Diphthong", "Erasmian", "Restored Koine", "Example"],
          rows: [
            ["αι", "ai (aisle)", "e (met)", "καί — and"],
            ["ει", "ei (eight)", "i (machine)", "εἰμί — I am"],
            ["οι", "oi (oil)", "ü → i", "οἶκος — house"],
            ["υι", "wee", "wi", "υἱός — son"],
            ["αυ", "ow (cow)", "av / af", "αὐτός — he"],
            [
              "ευ",
              "eu (feud)",
              "ev before vowels/voiced sounds; ef before voiceless sounds",
              "εὐαγγέλιον — ev-an-GHE-lee-on, gospel",
            ],
            ["ου", "oo (food)", "oo (food)", "οὐρανός — heaven"],
            ["ῃ / ᾳ / ῳ", "long vowel", "long vowel", "τῇ ἀρχῇ — in the beginning"],
          ],
        },
        tip: "γ before γ, κ, χ, ξ is pronounced 'n': ἄγγελος = ANG-gel-os, not AG-gel-os.",
      },
    ],
    vocabIds: ["theos", "logos", "kai", "en", "anthrwpos", "hemera"],
    reading: {
      ref: "John 1:1",
      intro: "You can already sound this out. Read it aloud three times before looking at the English.",
      verses: [
        {
          greek: "Ἐν ἀρχῇ ἦν ὁ λόγος, καὶ ὁ λόγος ἦν πρὸς τὸν θεόν, καὶ θεὸς ἦν ὁ λόγος.",
          english:
            "In the beginning was the Word, and the Word was with God, and the Word was God.",
        },
      ],
    },
    quiz: [
      {
        prompt: "How is γγ pronounced, as in ἄγγελος?",
        options: ["gg (hard)", "ng", "ny", "silent"],
        answer: 1,
        explain: "A gamma before γ, κ, χ or ξ becomes a nasal: ἄγγελος = ANG-ge-los.",
      },
      {
        prompt: "Which of these is NOT a diphthong?",
        options: ["ου", "ει", "ηα", "αυ"],
        answer: 2,
        explain: "The second vowel of a diphthong must be ι or υ. ηα is simply two separate vowels.",
      },
      {
        prompt: "What does the iota subscript in τῇ usually signal?",
        greek: "τῇ",
        options: ["Plural number", "Dative singular", "Aorist tense", "A question"],
        answer: 1,
        explain:
          "ᾳ ῃ ῳ almost always mark dative singular forms. Missing the little iota costs you the case.",
      },
      {
        prompt: "Which letter has two lowercase shapes?",
        options: ["Theta", "Sigma", "Omega", "Nu"],
        answer: 1,
        explain: "σ medially, ς finally — as in Ἰησοῦς / Ἰησοῦ.",
      },
    ],
  },
  {
    slug: "breathings-accents",
    trackId: "foundations",
    title: "Breathings, Accents, Punctuation & Syllables",
    greekTitle: "Πνεύματα καὶ τόνοι",
    summary:
      "The tiny marks that change meaning: rough vs. smooth breathing, the three accents, enclitics, and Greek punctuation.",
    minutes: 25,
    kind: "phonology",
    objectives: [
      "Read rough and smooth breathings correctly",
      "Name the three accents and know why they move",
      "Recognise the Greek question mark and the raised dot",
    ],
    videos: [
      {
        id: "eEQc-jQ9UgQ",
        kind: "video",
        title: "Accents, Breathing Marks and Punctuation",
        channel: "Greek For All",
        note: "The cleanest single explanation of all the diacritics.",
      },
      {
        id: "tSDH8yVfPLw",
        kind: "video",
        title: "Greek Breathing Marks, Accents, and Punctuation",
        channel: "Ken Schenck",
        note: "A seminary professor's concise treatment with worked examples.",
      },
      {
        id: "1WI64_mVzDU",
        kind: "video",
        title: "Greek Lesson 6: Accents",
        channel: "Murray Vasser",
        note: "Goes deeper into accent rules if you want the full system.",
      },
    ],
    listening: [
      { greek: "ὁ ἅγιος", translit: "ho hagios", gloss: "the holy one — rough breathing = h" },
      { greek: "ἐν ἀρχῇ", translit: "en archē", gloss: "in the beginning — smooth breathing, no h" },
      { greek: "εἷς / εἰς", translit: "heis / eis", gloss: "one / into — the breathing is the only difference" },
      { greek: "αὐτή / αὕτη", translit: "autē / hautē", gloss: "she / this woman — again, only the breathing" },
      { greek: "τίς ἐστιν οὗτος;", translit: "tis estin houtos?", gloss: "Who is this?" },
    ],
    grammar: [
      {
        heading: "Breathing marks",
        body: [
          "Every word that begins with a vowel, a diphthong, or ρ carries a breathing mark.",
          "Smooth breathing ( ᾿ ) adds nothing: ἐν = 'en'.",
          "Rough breathing ( ῾ ) adds an /h/: ὁ = 'ho', ἅγιος = 'hagios'. Initial ρ is always rough: ῥῆμα.",
          "On a diphthong the mark sits over the SECOND vowel: αὐτός, οὗτος.",
        ],
        tip: "Greek words borrowed into English preserve this: ὑπέρ → hyper, ὑπό → hypo, ὥρα → hour.",
      },
      {
        heading: "The three accents",
        body: [
          "Acute ( ´ ) — originally a rising pitch: λόγος.",
          "Grave ( ` ) — an acute on the final syllable flattens when another word follows: καὶ ὁ λόγος.",
          "Circumflex ( ῀ ) — rise then fall, only ever on a long vowel or diphthong: δοῦλος.",
          "Accents can only fall on one of the last three syllables: the ultima (last), penult (second-last), or antepenult (third-last).",
        ],
        table: {
          caption: "Accent placement matters",
          headers: ["Form", "Meaning"],
          rows: [
            ["ἄνθρωπος", "man (nominative) — accent on antepenult"],
            ["ἀνθρώπου", "of a man — long ultima pulls the accent forward"],
            ["τίς", "who? (interrogative — always acute, never grave)"],
            ["τις", "someone (indefinite enclitic — usually unaccented)"],
            ["ποῦ", "where?"],
            ["που", "somewhere"],
          ],
        },
        tip: "You do not need to master accent theory to read. You DO need to notice τίς vs. τις and αὐτή vs. αὕτη.",
      },
      {
        heading: "Punctuation",
        body: [
          "Comma ( , ) and period ( . ) work exactly as in English.",
          "The raised dot ( · ) is a colon or semicolon.",
          "The Greek question mark is a semicolon-looking ( ; ). τί ποιεῖς; = 'What are you doing?'",
          "None of this is in the original manuscripts — early codices are scriptio continua, all capitals, no spaces. Editors added it all.",
        ],
      },
    ],
    vocabIds: ["ho", "houtos", "tis", "tis-indef", "hagios"],
    quiz: [
      {
        prompt: "What does ; mean at the end of a Greek clause?",
        greek: "τί ποιεῖς;",
        options: ["Semicolon", "Question mark", "Exclamation", "Ellipsis"],
        answer: 1,
        explain: "The Greek erotimatiko looks like our semicolon but functions as a question mark.",
      },
      {
        prompt: "Which word means 'one' rather than 'into'?",
        options: ["εἰς", "εἷς", "ἐς", "ἴς"],
        answer: 1,
        explain: "εἷς has the rough breathing and circumflex = 'one'. εἰς with smooth breathing = 'into'.",
      },
      {
        prompt: "A circumflex accent can only sit on…",
        options: [
          "Any syllable",
          "A short vowel",
          "A long vowel or diphthong",
          "The first syllable of a word",
        ],
        answer: 2,
        explain: "The circumflex encodes a rise-then-fall in pitch, which needs a long nucleus.",
      },
    ],
  },
  {
    slug: "cases-nouns",
    trackId: "foundations",
    title: "Cases & the First and Second Declensions",
    greekTitle: "Πτώσεις",
    summary:
      "Greek marks a noun's job with its ending, not its position. Meet the five cases and the two easiest declension patterns.",
    minutes: 35,
    kind: "morphology",
    objectives: [
      "State the core function of each of the five cases",
      "Decline ἄνθρωπος, ἔργον, ὥρα, δόξα and γραφή",
      "Parse a noun as case–number–gender",
    ],
    videos: [
      {
        id: "qpfr7vYzuok",
        kind: "video",
        title: "Introduction to Greek Cases and Declensions",
        channel: "BiblicalGreek",
        note: "Start here: why Greek uses endings instead of word order.",
      },
      {
        id: "kQWBO2CRvrU",
        kind: "video",
        title: "Greek First and Second Declension",
        channel: "Ken Schenck",
        note: "Both paradigms side by side with the article.",
      },
      {
        id: "GJ5AAMQhrqM",
        kind: "video",
        title: "Amazing Greek 1st and 2nd Declension Nouns",
        channel: "Daily Dose of Greek",
        note: "A memory-hook song for the endings.",
      },
      {
        id: "8UaKpX49uzw",
        kind: "video",
        title: "Greek Noun Song 1: 1st and 2nd Declension Endings",
        channel: "Jonathan Rowe",
        note: "Optional second earworm — repetition is the point.",
      },
    ],
    listening: [
      { greek: "ὁ λόγος τοῦ θεοῦ", gloss: "the word of God (nom. + gen.)" },
      { greek: "τῷ λόγῳ τοῦ κυρίου", gloss: "by/in the word of the Lord (dat.)" },
      { greek: "βλέπω τὸν ἄνθρωπον", gloss: "I see the man (acc. object)" },
      { greek: "οἱ ἀδελφοὶ ἀκούουσιν", gloss: "the brothers hear (nom. pl.)" },
      { greek: "ἐν τῇ ἡμέρᾳ τῇ ἐσχάτῃ", gloss: "on the last day" },
      { greek: "ἡ δόξα τῆς βασιλείας", gloss: "the glory of the kingdom" },
    ],
    grammar: [
      {
        heading: "Five cases, five jobs",
        body: [
          "NOMINATIVE — the subject, or a predicate noun after εἰμί. ὁ λόγος ἦν θεός.",
          "GENITIVE — description, source, possession; usually 'of'. Also the case after many prepositions. ἡ βασιλεία τοῦ θεοῦ.",
          "DATIVE — the indirect object, the instrument, the location, the person affected; 'to/for/with/in/by'. τῷ λόγῳ.",
          "ACCUSATIVE — the direct object and extent. It answers 'how far, how long, whom'. εἰς τὸν κόσμον.",
          "VOCATIVE — direct address. κύριε! Often identical to the nominative in the plural.",
        ],
        tip: "Word order in Greek is for EMPHASIS, not grammar. θεὸς ἦν ὁ λόγος puts θεός first for weight — the article on λόγος still tells you which word is the subject.",
      },
      {
        heading: "Second declension (the -ος / -ον pattern)",
        body: [
          "Nouns whose lexical form ends in -ος are usually masculine; those ending in -ον are neuter.",
          "Neuter nouns are always identical in the nominative and accusative — a huge help when parsing.",
        ],
        table: {
          caption: "ἄνθρωπος (m.) and ἔργον (n.)",
          headers: ["Case", "Masc. sg.", "Masc. pl.", "Neut. sg.", "Neut. pl."],
          rows: [
            ["Nom.", "ὁ ἄνθρωπος", "οἱ ἄνθρωποι", "τὸ ἔργον", "τὰ ἔργα"],
            ["Gen.", "τοῦ ἀνθρώπου", "τῶν ἀνθρώπων", "τοῦ ἔργου", "τῶν ἔργων"],
            ["Dat.", "τῷ ἀνθρώπῳ", "τοῖς ἀνθρώποις", "τῷ ἔργῳ", "τοῖς ἔργοις"],
            ["Acc.", "τὸν ἄνθρωπον", "τοὺς ἀνθρώπους", "τὸ ἔργον", "τὰ ἔργα"],
            ["Voc.", "ἄνθρωπε", "ἄνθρωποι", "ἔργον", "ἔργα"],
          ],
        },
      },
      {
        heading: "First declension (the -α / -η pattern)",
        body: [
          "Overwhelmingly feminine. Three sub-patterns depend on the letter before the ending:",
          "α-pure — after ε, ι or ρ the alpha stays throughout: ἡμέρα, ἡμέρας, ἡμέρᾳ, ἡμέραν.",
          "η — after most other consonants: γραφή, γραφῆς, γραφῇ, γραφήν.",
          "α-impure — after σ, ζ, ξ, ψ or a double consonant the α switches to η in the genitive and dative singular: δόξα, δόξης, δόξῃ, δόξαν.",
        ],
        table: {
          caption: "First declension plural is identical for all three types",
          headers: ["Case", "α-pure ἡμέρα", "η γραφή", "α-impure δόξα", "Plural ending"],
          rows: [
            ["Nom.", "ἡμέρα", "γραφή", "δόξα", "-αι"],
            ["Gen.", "ἡμέρας", "γραφῆς", "δόξης", "-ῶν"],
            ["Dat.", "ἡμέρᾳ", "γραφῇ", "δόξῃ", "-αις"],
            ["Acc.", "ἡμέραν", "γραφήν", "δόξαν", "-ας"],
          ],
        },
        tip: "Learn nouns with their article: ἡ ἡμέρα, ὁ λόγος, τὸ ἔργον. The article carries the gender for free.",
      },
    ],
    vocabIds: [
      "anthrwpos",
      "logos",
      "ergon",
      "hemera",
      "doxa",
      "basileia",
      "adelphos",
      "oikos",
      "kardia",
      "agape",
      "hodos",
      "teknon",
    ],
    reading: {
      ref: "Mark 1:1",
      intro: "Five nouns, four of them genitive. Track the chain.",
      verses: [
        {
          greek: "Ἀρχὴ τοῦ εὐαγγελίου Ἰησοῦ Χριστοῦ υἱοῦ θεοῦ.",
          english: "The beginning of the gospel of Jesus Christ, the Son of God.",
        },
      ],
    },
    quiz: [
      {
        prompt: "Parse τῷ ἀνθρώπῳ.",
        greek: "τῷ ἀνθρώπῳ",
        options: [
          "Dative singular masculine",
          "Genitive plural masculine",
          "Accusative singular masculine",
          "Nominative plural masculine",
        ],
        answer: 0,
        explain: "-ῳ with iota subscript and the article τῷ = dative singular.",
      },
      {
        prompt: "Why is τὰ ἔργα ambiguous on its own?",
        greek: "τὰ ἔργα",
        options: [
          "It could be masculine or feminine",
          "Neuter nominative and accusative plural are identical",
          "It could be singular or plural",
          "It has no accent",
        ],
        answer: 1,
        explain:
          "Neuter nouns never distinguish nominative from accusative. Context and the verb tell you which it is.",
      },
      {
        prompt: "Which case would you use for 'the kingdom OF God'?",
        options: ["Nominative", "Genitive", "Dative", "Accusative"],
        answer: 1,
        explain: "ἡ βασιλεία τοῦ θεοῦ — the genitive τοῦ θεοῦ describes/qualifies βασιλεία.",
      },
      {
        prompt: "δόξα is 'α-impure'. What is its genitive singular?",
        options: ["δόξας", "δόξης", "δόξαν", "δόξῃ"],
        answer: 1,
        explain: "After ξ the alpha shifts to eta in the genitive and dative singular: δόξης, δόξῃ.",
      },
    ],
  },
  {
    slug: "article-adjectives",
    trackId: "foundations",
    title: "The Article and Adjectives",
    greekTitle: "Τὸ ἄρθρον",
    summary:
      "The most common word in the New Testament, and the three positions an adjective can occupy — each with a different meaning.",
    minutes: 30,
    kind: "morphology",
    objectives: [
      "Recite the full 24-form article chart",
      "Distinguish attributive, predicate and substantival position",
      "Explain why an anarthrous noun is not automatically indefinite",
    ],
    videos: [
      {
        id: "049A9mWp8Y0",
        kind: "video",
        title: "The Basics of the Greek Definite Article",
        channel: "Prof. Elder",
        note: "Forms plus the functions that actually matter for exegesis.",
      },
      {
        id: "h_1V8BL5MUg",
        kind: "video",
        title: "The Definite Article Song",
        channel: "Danny Zacharias",
        note: "24 forms in about a minute. Sing it in the car.",
      },
      {
        id: "p2mXBg17Dkg",
        kind: "video",
        title: "Introduction to Definite Articles and Adjectives",
        channel: "Tyler Stewart",
        note: "How adjective position changes translation.",
      },
    ],
    listening: [
      { greek: "ὁ ἀγαθὸς ἄνθρωπος", gloss: "the good man (attributive)" },
      { greek: "ὁ ἄνθρωπος ὁ ἀγαθός", gloss: "the good man (second attributive — more emphatic)" },
      { greek: "ὁ ἄνθρωπος ἀγαθός", gloss: "the man IS good (predicate)" },
      { greek: "οἱ ἅγιοι", gloss: "the holy ones = the saints (substantival)" },
      { greek: "τὸ ἀγαθόν", gloss: "the good thing / that which is good" },
    ],
    grammar: [
      {
        heading: "The article: 19,870 occurrences",
        body: [
          "Greek has no indefinite article ('a'). It has one definite article that agrees with its noun in gender, number and case.",
          "Once you know the article you effectively know the 2nd/1st declension endings — the article mirrors them.",
        ],
        table: {
          caption: "The complete article",
          headers: ["Case", "Masc. sg", "Fem. sg", "Neut. sg", "Masc. pl", "Fem. pl", "Neut. pl"],
          rows: [
            ["Nom.", "ὁ", "ἡ", "τό", "οἱ", "αἱ", "τά"],
            ["Gen.", "τοῦ", "τῆς", "τοῦ", "τῶν", "τῶν", "τῶν"],
            ["Dat.", "τῷ", "τῇ", "τῷ", "τοῖς", "ταῖς", "τοῖς"],
            ["Acc.", "τόν", "τήν", "τό", "τούς", "τάς", "τά"],
          ],
        },
        tip: "The article can turn ANY word or phrase into a noun: τὸ ἀγαθόν 'the good', οἱ μετ' αὐτοῦ 'those with him', τὸ ἀποθανεῖν 'the act of dying'.",
      },
      {
        heading: "Three adjective positions",
        body: [
          "ATTRIBUTIVE — the adjective is inside the article's 'bubble': ὁ ἀγαθὸς ἄνθρωπος or ὁ ἄνθρωπος ὁ ἀγαθός. Translate 'the good man'.",
          "PREDICATE — the adjective is outside the bubble: ἀγαθὸς ὁ ἄνθρωπος or ὁ ἄνθρωπος ἀγαθός. Supply 'is': 'the man is good'.",
          "SUBSTANTIVAL — article + adjective with no noun: οἱ ἅγιοι 'the saints', ὁ πονηρός 'the evil one'.",
        ],
        tip: "This one rule solves hundreds of translation questions. Ask: is the adjective immediately preceded by an article? If yes, attributive. If no (and the noun is articular), predicate.",
      },
      {
        heading: "Anarthrous ≠ indefinite",
        body: [
          "A noun without the article may be indefinite ('a god'), qualitative ('divine in nature'), or definite by other means (proper nouns, prepositional phrases, genitive constructions).",
          "θεὸς ἦν ὁ λόγος (John 1:1c) is the classic case. ὁ λόγος has the article and is therefore the subject; θεός is an anarthrous pre-verbal predicate nominative, which Colwell/Harner-type analysis treats as primarily qualitative: the Word shared fully in the nature of God.",
        ],
      },
    ],
    vocabIds: ["ho", "hagios", "agathos", "kalos", "megas", "pas", "polys", "allos", "prwtos", "nekros"],
    reading: {
      ref: "1 John 1:5",
      intro: "Watch the predicate construction and the emphatic negative.",
      verses: [
        {
          greek:
            "καὶ αὕτη ἐστὶν ἡ ἀγγελία ἣν ἀκηκόαμεν ἀπ᾽ αὐτοῦ καὶ ἀναγγέλλομεν ὑμῖν, ὅτι ὁ θεὸς φῶς ἐστιν καὶ σκοτία ἐν αὐτῷ οὐκ ἔστιν οὐδεμία.",
          english:
            "And this is the message we have heard from him and announce to you: that God is light, and in him there is no darkness at all.",
        },
      ],
    },
    quiz: [
      {
        prompt: "How should ὁ ἄνθρωπος ἀγαθός be translated?",
        greek: "ὁ ἄνθρωπος ἀγαθός",
        options: ["the good man", "the man is good", "a good man", "good men"],
        answer: 1,
        explain: "No article before ἀγαθός while the noun is articular = predicate position: supply 'is'.",
      },
      {
        prompt: "What does οἱ ἅγιοι mean on its own?",
        greek: "οἱ ἅγιοι",
        options: ["the holy men are", "the saints / holy ones", "holy is he", "of the saints"],
        answer: 1,
        explain: "Article + adjective with no noun = substantival. Very common in Paul.",
      },
      {
        prompt: "Which article form is genitive plural (any gender)?",
        options: ["τοῖς", "τῶν", "τούς", "τάς"],
        answer: 1,
        explain: "τῶν serves masculine, feminine and neuter genitive plural alike.",
      },
    ],
  },
  {
    slug: "present-indicative",
    trackId: "foundations",
    title: "Verbs I: Present Active Indicative",
    greekTitle: "Ἐνεστὼς χρόνος",
    summary:
      "Your first conjugation. Person, number, tense, voice and mood — and why Greek verbs need no pronoun.",
    minutes: 32,
    kind: "morphology",
    objectives: [
      "Conjugate λύω and πιστεύω in the present active indicative",
      "Parse a verb in five slots: tense–voice–mood–person–number",
      "Translate simple verbal sentences without an expressed subject",
    ],
    videos: [
      {
        id: "tKFlGT8lpEw",
        kind: "video",
        title: "Present Active Indicative Verbs",
        channel: "Prof. Elder",
        note: "Endings, stem, and connecting vowel explained slowly.",
      },
      {
        id: "n4vPy0x7lbg",
        kind: "video",
        title: "Koine Greek: Present Active Indicative Verbs",
        channel: "Greek For All",
        note: "A second angle with plenty of worked examples.",
      },
      {
        id: "B1suAd0Bhos",
        kind: "video",
        title: "'Everyday' Active Indicative Verb Endings Song",
        channel: "Daily Dose of Greek",
        note: "The endings set to a tune you will not be able to forget.",
      },
    ],
    listening: [
      { greek: "πιστεύω, πιστεύεις, πιστεύει", gloss: "I believe, you believe, he/she believes" },
      { greek: "πιστεύομεν, πιστεύετε, πιστεύουσιν", gloss: "we, you (pl.), they believe" },
      { greek: "ἀκούω τὴν φωνήν", gloss: "I hear the voice" },
      { greek: "γράφει ὁ ἀδελφός", gloss: "the brother is writing" },
      { greek: "οὐ βλέπομεν τὸν κύριον", gloss: "we do not see the Lord" },
      { greek: "τί ζητεῖτε;", gloss: "What are you seeking?" },
    ],
    grammar: [
      {
        heading: "Five slots of parsing",
        body: [
          "Every finite Greek verb answers five questions: Tense-form? Voice? Mood? Person? Number?",
          "λύομεν = present, active, indicative, 1st person, plural: 'we loose / we are loosing'.",
          "The ending carries person and number, so ἡμεῖς 'we' is optional and, when present, emphatic.",
        ],
        table: {
          caption: "Present active indicative of λύω (I loose)",
          headers: ["Person", "Singular", "Translation", "Plural", "Translation"],
          rows: [
            ["1st", "λύω", "I loose", "λύομεν", "we loose"],
            ["2nd", "λύεις", "you loose", "λύετε", "you (pl.) loose"],
            ["3rd", "λύει", "he/she/it looses", "λύουσι(ν)", "they loose"],
          ],
        },
        tip: "The final ν on λύουσι(ν) is 'movable nu' — added before a vowel or at a pause. It carries no meaning.",
      },
      {
        heading: "Aspect, not just time",
        body: [
          "The present tense-form in Greek primarily encodes IMPERFECTIVE aspect: the action is viewed as unfolding, in progress, from the inside.",
          "In the indicative it usually also implies present time, so λύει can be 'he looses', 'he is loosing', or 'he keeps loosing'.",
          "Outside the indicative (participles, infinitives, subjunctives) the present carries aspect only — no time at all. This becomes crucial in the Intermediate track.",
        ],
      },
      {
        heading: "Negation and questions",
        body: [
          "οὐ (οὐκ before a vowel, οὐχ before rough breathing) negates the indicative: οὐ πιστεύω.",
          "μή negates everything else (subjunctive, imperative, participle, infinitive).",
          "A question expecting 'yes' begins with οὐ; a question expecting 'no' begins with μή. This subtlety is invisible in most English translations.",
        ],
      },
    ],
    vocabIds: [
      "pisteuw",
      "akouw",
      "blepw",
      "legw",
      "gpraphw",
      "lambanw",
      "gnwskw",
      "euriskw",
      "didaskw",
      "baptizw",
      "ou",
      "me",
    ],
    reading: {
      ref: "John 1:29",
      intro: "One present indicative, one imperative, one substantival participle. Find the verbs first.",
      verses: [
        {
          greek:
            "Τῇ ἐπαύριον βλέπει τὸν Ἰησοῦν ἐρχόμενον πρὸς αὐτόν, καὶ λέγει· Ἴδε ὁ ἀμνὸς τοῦ θεοῦ ὁ αἴρων τὴν ἁμαρτίαν τοῦ κόσμου.",
          english:
            "The next day he sees Jesus coming toward him and says: Look, the Lamb of God who takes away the sin of the world!",
        },
      ],
    },
    quiz: [
      {
        prompt: "Parse ἀκούουσιν.",
        greek: "ἀκούουσιν",
        options: [
          "Present active indicative 3rd plural",
          "Present active indicative 2nd plural",
          "Present active indicative 1st plural",
          "Aorist active indicative 3rd plural",
        ],
        answer: 0,
        explain: "-ουσι(ν) is the 3rd person plural present active ending: 'they hear'.",
      },
      {
        prompt: "Which negative particle goes with the indicative mood?",
        options: ["μή", "οὐ", "οὐδέ", "μήτε"],
        answer: 1,
        explain: "οὐ (οὐκ / οὐχ) negates indicatives; μή negates the other moods.",
      },
      {
        prompt: "Why does Greek not need to write ἡμεῖς with λύομεν?",
        options: [
          "Because Greek has no pronouns",
          "Because the -μεν ending already encodes 1st person plural",
          "Because the article supplies it",
          "Because it is understood from the accent",
        ],
        answer: 1,
        explain:
          "Personal endings are obligatory; an explicit pronoun is therefore emphatic or contrastive.",
      },
    ],
  },
  {
    slug: "eimi-prepositions",
    trackId: "foundations",
    title: "εἰμί, Prepositions & Your First Sentences",
    greekTitle: "Εἰμί καὶ αἱ προθέσεις",
    summary:
      "The verb 'to be' and the preposition system — the glue that turns vocabulary into readable sentences.",
    minutes: 30,
    kind: "syntax",
    objectives: [
      "Conjugate εἰμί in the present and imperfect",
      "Match each preposition with the case(s) it governs",
      "Read a full verse without a lexicon",
    ],
    videos: [
      {
        id: "JcmbCwMhQes",
        kind: "video",
        title: "Koine Greek Prepositions",
        channel: "TAR2 Studios",
        note: "The spatial diagram that makes prepositions click.",
      },
      {
        id: "xmw-ev7tgbA",
        kind: "video",
        title: "Greek Prepositions",
        channel: "The Depraved Apologist",
        note: "Case-by-case meanings with NT examples.",
      },
      {
        id: "Cus1ts4TLb4",
        kind: "video",
        title: "Lesson 5 — Pronouns and the verb 'to be' (all in Greek)",
        channel: "Alpha with Angela",
        note: "Full immersion: no English at all. Watch after the two above.",
      },
      {
        id: "W9Mw4xxSh1U",
        kind: "video",
        title: "Lesson 24 — Prepositional phrases (all in Greek)",
        channel: "Alpha with Angela",
        note: "Hear prepositions used naturally in context.",
      },
    ],
    listening: [
      { greek: "εἰμί, εἶ, ἐστίν", gloss: "I am, you are, he/she/it is" },
      { greek: "ἐσμέν, ἐστέ, εἰσίν", gloss: "we are, you (pl.) are, they are" },
      { greek: "ἐγώ εἰμι ὁ ἄρτος τῆς ζωῆς", gloss: "I am the bread of life" },
      { greek: "ἐν τῷ οἴκῳ", gloss: "in the house" },
      { greek: "εἰς τὸν οἶκον", gloss: "into the house" },
      { greek: "ἐκ τοῦ οἴκου", gloss: "out of the house" },
      { greek: "μετὰ τῶν ἀδελφῶν", gloss: "with the brothers" },
      { greek: "διὰ τοῦ Ἰησοῦ Χριστοῦ", gloss: "through Jesus Christ" },
    ],
    grammar: [
      {
        heading: "εἰμί — the equative verb",
        body: [
          "εἰμί never takes a direct object. What follows is a predicate NOMINATIVE, not an accusative.",
          "It is enclitic in most forms, meaning it usually throws its accent onto the preceding word.",
        ],
        table: {
          caption: "εἰμί: present and imperfect",
          headers: ["Person", "Present sg", "Present pl", "Imperfect sg", "Imperfect pl"],
          rows: [
            ["1st", "εἰμί (I am)", "ἐσμέν", "ἤμην (I was)", "ἦμεν"],
            ["2nd", "εἶ", "ἐστέ", "ἦς", "ἦτε"],
            ["3rd", "ἐστί(ν)", "εἰσί(ν)", "ἦν", "ἦσαν"],
          ],
        },
        tip: "ἦν in John 1:1 is imperfect — continuous existence in the past. John did not write ἐγένετο ('came into being'), which he saves for verse 3 and for created things.",
      },
      {
        heading: "Prepositions are case-driven",
        body: [
          "A Greek preposition's meaning depends on the case of its object. διά + genitive = 'through'; διά + accusative = 'because of'.",
          "Learn each preposition as a small family of meanings, one per case.",
        ],
        table: {
          caption: "The core prepositions",
          headers: ["Preposition", "+ Genitive", "+ Dative", "+ Accusative"],
          rows: [
            ["ἐν", "—", "in, on, among, by", "—"],
            ["εἰς", "—", "—", "into, to, for"],
            ["ἐκ / ἐξ", "out of, from", "—", "—"],
            ["ἀπό", "from, away from", "—", "—"],
            ["πρός", "(rare)", "at, near", "to, toward, with"],
            ["διά", "through", "—", "because of"],
            ["κατά", "down from, against", "—", "according to"],
            ["μετά", "with", "—", "after"],
            ["περί", "concerning, about", "—", "around"],
            ["ὑπό", "by (agent)", "—", "under"],
            ["ὑπέρ", "on behalf of", "—", "above, beyond"],
            ["παρά", "from (a person)", "beside, with", "alongside"],
            ["σύν", "—", "with", "—"],
            ["ἐπί", "on, over", "at, on", "on, against"],
          ],
        },
        tip: "Prepositions also become verb prefixes and keep their force: ἐκ + βάλλω = ἐκβάλλω 'I throw out'.",
      },
    ],
    vocabIds: ["eimi", "en", "eis", "ek", "apo", "pros", "dia", "kata", "meta", "peri", "hypo", "hyper", "syn", "epi"],
    reading: {
      ref: "John 1:1-3",
      intro:
        "Now read the prologue with everything you know: article, cases, prepositions, imperfect of εἰμί.",
      verses: [
        {
          greek: "Ἐν ἀρχῇ ἦν ὁ λόγος, καὶ ὁ λόγος ἦν πρὸς τὸν θεόν, καὶ θεὸς ἦν ὁ λόγος.",
          english: "In the beginning was the Word, and the Word was with God, and the Word was God.",
        },
        { greek: "οὗτος ἦν ἐν ἀρχῇ πρὸς τὸν θεόν.", english: "He was in the beginning with God." },
        {
          greek: "πάντα δι᾽ αὐτοῦ ἐγένετο, καὶ χωρὶς αὐτοῦ ἐγένετο οὐδὲ ἕν ὃ γέγονεν.",
          english:
            "All things came into being through him, and apart from him not one thing came into being that has come into being.",
        },
      ],
    },
    quiz: [
      {
        prompt: "διὰ τὸν λόγον means…",
        greek: "διὰ τὸν λόγον",
        options: ["through the word", "because of the word", "with the word", "against the word"],
        answer: 1,
        explain: "διά + accusative = cause/reason. διά + genitive would be 'through'.",
      },
      {
        prompt: "Which case does ἐν always take?",
        options: ["Genitive", "Dative", "Accusative", "Any of the three"],
        answer: 1,
        explain: "ἐν is exclusively a dative preposition in Koine.",
      },
      {
        prompt: "What is significant about ἦν in John 1:1?",
        greek: "ἦν",
        options: [
          "It is aorist, marking a point of origin",
          "It is imperfect, describing continuous existence rather than coming-into-being",
          "It is a participle",
          "It is future",
        ],
        answer: 1,
        explain:
          "John contrasts ἦν (imperfect of εἰμί) for the Logos with ἐγένετο (aorist of γίνομαι) for created things.",
      },
    ],
  },
  {
    slug: "immersion-stories",
    trackId: "foundations",
    title: "Immersion Lab: Your First Greek Stories",
    greekTitle: "Ἱστορίαι",
    summary:
      "Comprehensible input. Short narratives told entirely in Greek at a beginner's pace — the single fastest way to build intuition.",
    minutes: 25,
    kind: "immersion",
    objectives: [
      "Follow a simple Greek narrative without translating word by word",
      "Answer Greek questions in Greek",
      "Begin thinking in Greek phrases rather than English equivalents",
    ],
    videos: [
      {
        id: "2uH8-jimBXE",
        kind: "video",
        title: "Story 2 — Tὰ κακὰ παιδία (The Bad Children)",
        channel: "Alpha with Angela",
        note: "Slow, illustrated, 100% Greek. Do not translate — just watch.",
      },
      {
        id: "U-RTQYTEY6I",
        kind: "video",
        title: "Story 5 — They ate from the tree in Paradise",
        channel: "Alpha with Angela",
        note: "Genesis narrative in beginner Koine with on-screen text.",
      },
      {
        id: "B2chp9XHEOs",
        kind: "video",
        title: "EASY Biblical Greek Cartoon — The Wise & Foolish Builders",
        channel: "Beta with Brett",
        note: "Animated parable with simple Koine narration.",
      },
      {
        id: "1RPRnQ-d1PA",
        kind: "video",
        title: "Koine Greek NT Stories 1: Mary and Joseph",
        channel: "Dustin Learns Koine",
        note: "Narrative retelling using only beginner vocabulary.",
      },
      {
        id: "PLO3VwXPRtV3yHbCsWoGCxEkBsDoXNkpMq",
        kind: "playlist",
        title: "Biblical Greek — Lessons in Order (full free course)",
        channel: "Alpha with Angela",
        note: "The complete natural-method sequence. Bookmark and work through it in parallel.",
      },
    ],
    listening: [
      { greek: "τίς ἐστιν οὗτος;", gloss: "Who is this?" },
      { greek: "οὗτός ἐστιν ὁ ἀδελφός μου.", gloss: "This is my brother." },
      { greek: "ποῦ ἐστιν τὸ παιδίον;", gloss: "Where is the child?" },
      { greek: "τὸ παιδίον ἐστὶν ἐν τῷ οἴκῳ.", gloss: "The child is in the house." },
      { greek: "τί ποιεῖ ὁ ἄνθρωπος;", gloss: "What is the man doing?" },
      { greek: "ὁ ἄνθρωπος γράφει βιβλίον.", gloss: "The man is writing a book." },
      { greek: "ναί, ἀληθῶς λέγεις.", gloss: "Yes, you speak truly." },
      { greek: "οὐχί, οὐκ οἶδα.", gloss: "No, I do not know." },
    ],
    grammar: [
      {
        heading: "Why comprehensible input works",
        body: [
          "Grammar-translation gives you a decoder ring. Input gives you a language. You need both, but most students get far too little input.",
          "The rule: watch material where you understand roughly 80–90% without effort. If you are translating in your head, the material is too hard.",
          "Do not aim for perfect comprehension. Aim for repeated, pleasant exposure. Re-watch the same story three times over a week rather than three new stories once.",
        ],
        tip: "Shadowing: play a sentence, pause, and repeat it out loud, imitating the rhythm. Five minutes of shadowing a day transforms your reading fluency.",
      },
      {
        heading: "Classroom Greek you can start using",
        body: [
          "χαῖρε / χαίρετε — hello (sg./pl.)",
          "τί ἐστιν τοῦτο; — What is this?",
          "οὐ γινώσκω / οὐκ οἶδα — I don't know",
          "πάλιν, παρακαλῶ — again, please",
          "καλῶς — well done / good",
          "βραδέως, παρακαλῶ — slowly, please",
        ],
      },
    ],
    vocabIds: ["tis", "houtos", "ekei", "nyn", "houtws", "poiew", "erchomai", "ginomai", "thelw"],
    quiz: [
      {
        prompt: "What is the target comprehension level for good input material?",
        options: ["30-50%", "80-90%", "100%", "It does not matter"],
        answer: 1,
        explain:
          "Comprehensible input means i+1: mostly known, slightly stretching. Below ~80% it becomes noise.",
      },
      {
        prompt: "Translate: ποῦ ἐστιν τὸ παιδίον;",
        greek: "ποῦ ἐστιν τὸ παιδίον;",
        options: ["Who is the child?", "Where is the child?", "What is the child?", "Whose is the child?"],
        answer: 1,
        explain: "ποῦ = where. Note the Greek question mark ( ; ).",
      },
    ],
  },

  // ══════════════════════ INTERMEDIATE ══════════════════════
  {
    slug: "imperfect-future",
    trackId: "intermediate",
    title: "Verbs II: Imperfect and Future",
    greekTitle: "Παρατατικὸς καὶ μέλλων",
    summary:
      "The augment, the secondary endings, and the sigma of the future — plus what happens when σ meets a consonant.",
    minutes: 32,
    kind: "morphology",
    objectives: [
      "Recognise the augment as a past-time marker in the indicative",
      "Form the future by inserting σ and applying consonant contraction",
      "Distinguish imperfective past (imperfect) from perfective past (aorist)",
    ],
    videos: [
      {
        id: "xGBuPuayk8M",
        kind: "video",
        title: "Koine Greek: Imperfect Active Verbs",
        channel: "Greek For All",
        note: "The augment and secondary endings, worked slowly.",
      },
      {
        id: "PLMqCPZpkjEcQw-WeAOxBqu3s4GBzX_HbF",
        kind: "playlist",
        title: "Basics of Biblical Greek — complete lecture series",
        channel: "Bill Mounce",
        note: "Chapters 15–20 cover the imperfect and future. Free, chapter by chapter.",
      },
      {
        id: "PLPe-EXRYJg2iob0nrBggwIrr56Y1k2WZ2",
        kind: "playlist",
        title: "Learn to Read New Testament Greek — full course",
        channel: "David Alan Black",
        note: "An alternative complete video course if Mounce's pacing does not suit you.",
      },
    ],
    listening: [
      { greek: "ἔλυον, ἔλυες, ἔλυεν", gloss: "I was loosing, you were loosing, he was loosing" },
      { greek: "ἐλύομεν, ἐλύετε, ἔλυον", gloss: "we / you (pl.) / they were loosing" },
      { greek: "λύσω, λύσεις, λύσει", gloss: "I will loose, you will loose, he will loose" },
      { greek: "ἐδίδασκεν αὐτοὺς ἐν ταῖς συναγωγαῖς", gloss: "he was teaching them in the synagogues" },
      { greek: "πιστεύσουσιν εἰς αὐτόν", gloss: "they will believe in him" },
    ],
    grammar: [
      {
        heading: "The augment",
        body: [
          "Past-time indicative verbs prefix an augment. For stems beginning with a consonant it is ἐ-: λύω → ἔλυον.",
          "For stems beginning with a vowel the vowel LENGTHENS: ἀκούω → ἤκουον; ἐγείρω → ἤγειρον; ὁράω → ἑώρων.",
          "In compound verbs the augment goes between prefix and stem: ἐκβάλλω → ἐξέβαλλον; ἀποστέλλω → ἀπέστελλον.",
        ],
        table: {
          caption: "Imperfect active of λύω — secondary endings",
          headers: ["Person", "Singular", "Plural"],
          rows: [
            ["1st", "ἔλυον (I was loosing)", "ἐλύομεν"],
            ["2nd", "ἔλυες", "ἐλύετε"],
            ["3rd", "ἔλυε(ν)", "ἔλυον"],
          ],
        },
        tip: "Note the built-in ambiguity: ἔλυον is both 1st singular and 3rd plural. Context decides.",
      },
      {
        heading: "The future: σ between stem and ending",
        body: [
          "Future active = stem + σ + primary endings: λύ-σ-ω, λύ-σ-εις, λύ-σ-ει.",
          "When the stem ends in a consonant, σ triggers predictable contraction — this is the single most useful sound rule in Greek.",
        ],
        table: {
          caption: "Consonant + σ contractions",
          headers: ["Stem ends in", "Plus σ becomes", "Example"],
          rows: [
            ["π, β, φ (labials)", "ψ", "βλέπω → βλέψω"],
            ["κ, γ, χ (velars)", "ξ", "ἄγω → ἄξω"],
            ["τ, δ, θ (dentals)", "σ (dental drops)", "πείθω → πείσω"],
            ["ζ", "σ", "βαπτίζω → βαπτίσω"],
          ],
        },
        tip: "Liquid verbs (stems in λ μ ν ρ) build the future with -εσ- which then contracts: μένω → μενῶ, ἀποστέλλω → ἀποστελῶ. Watch for the circumflex.",
      },
      {
        heading: "Imperfect vs. aorist: aspect, not duration",
        body: [
          "Both are past-referring in the indicative. The difference is viewpoint.",
          "Imperfect = imperfective aspect: the writer places you INSIDE the event, watching it unfold. Mark loves this for background and for repeated action.",
          "Aorist = perfective aspect: the writer views the event as a whole from OUTSIDE, a single point on the timeline. This is the default narrative tense.",
          "The imperfect is therefore often the marked, foregrounding choice — it slows the camera down.",
        ],
      },
    ],
    vocabIds: ["menw", "apostellw", "egeirw", "krinw", "sozw", "thelw", "kalew", "zetew"],
    reading: {
      ref: "Mark 1:21-22",
      intro:
        "Three finite imperfects appear in two verses: ἐδίδασκεν, ἐξεπλήσσοντο, and ἦν. The last joins διδάσκων to form the periphrastic imperfect ἦν διδάσκων. Notice how Mark uses these imperfective forms to slow the camera and set a scene.",
      verses: [
        {
          greek:
            "Καὶ εἰσπορεύονται εἰς Καφαρναούμ. καὶ εὐθὺς τοῖς σάββασιν εἰσελθὼν εἰς τὴν συναγωγὴν ἐδίδασκεν.",
          english:
            "And they go into Capernaum; and immediately on the Sabbath he entered the synagogue and began teaching.",
        },
        {
          greek:
            "καὶ ἐξεπλήσσοντο ἐπὶ τῇ διδαχῇ αὐτοῦ, ἦν γὰρ διδάσκων αὐτοὺς ὡς ἐξουσίαν ἔχων καὶ οὐχ ὡς οἱ γραμματεῖς.",
          english:
            "And they were astounded at his teaching, for he was teaching them as one having authority, and not as the scribes.",
        },
      ],
    },
    quiz: [
      {
        prompt: "What is the imperfect of ἀκούω, 3rd singular?",
        options: ["ἀκούει", "ἤκουεν", "ἐάκουεν", "ἀκούσει"],
        answer: 1,
        explain: "Initial α lengthens to η for the augment: ἤκουεν 'he was hearing'.",
      },
      {
        prompt: "βλέπω + σ (future) gives…",
        options: ["βλέπσω", "βλέξω", "βλέψω", "βλέσω"],
        answer: 2,
        explain: "A labial (π β φ) plus σ becomes ψ.",
      },
      {
        prompt: "Where does the augment go in ἐκβάλλω?",
        options: [
          "Before the whole word: ἐἐκβάλλον",
          "Between prefix and stem: ἐξέβαλλον",
          "At the end",
          "Compound verbs take no augment",
        ],
        answer: 1,
        explain: "The augment attaches to the verbal root, and ἐκ assimilates to ἐξ before a vowel.",
      },
    ],
  },
  {
    slug: "aorist",
    trackId: "intermediate",
    title: "Verbs III: The Aorist (First and Second)",
    greekTitle: "Ἀόριστος",
    summary:
      "The workhorse of Greek narrative. Sigmatic first aorists, stem-changing second aorists, and why 'aorist ≠ past'.",
    minutes: 35,
    kind: "morphology",
    objectives: [
      "Identify first and second aorist forms on sight",
      "Explain perfective aspect and the 'undefined' name ἀ-όριστος",
      "Avoid the classic 'once-for-all aorist' exegetical fallacy",
    ],
    videos: [
      {
        id: "jiqfVg8TxGk",
        kind: "video",
        title: "Introduction to the Aorist Tense and Aspect",
        channel: "Tyler Stewart",
        note: "Forms plus a careful, non-overreaching account of meaning.",
      },
      {
        id: "JdEAufuV24s",
        kind: "video",
        title: "Introduction to the Aorist in Ancient Greek",
        channel: "Jeremy F. Hultin (Yale)",
        note: "A university-level treatment worth watching twice.",
      },
      {
        id: "HSkSoz-9TPY",
        kind: "video",
        title: "The Aorist Tense — an introduction",
        channel: "Learn New Testament Greek",
        note: "Compact drill-oriented recap.",
      },
    ],
    listening: [
      { greek: "ἔλυσα, ἔλυσας, ἔλυσεν", gloss: "I loosed, you loosed, he loosed" },
      { greek: "ἐλύσαμεν, ἐλύσατε, ἔλυσαν", gloss: "we / you (pl.) / they loosed" },
      { greek: "εἶπον, ἔλαβον, ἦλθον, εἶδον", gloss: "I said, I took, I came, I saw (2nd aorists)" },
      { greek: "καὶ ὁ λόγος σὰρξ ἐγένετο", gloss: "and the Word became flesh" },
      { greek: "ἐπίστευσαν εἰς αὐτὸν οἱ μαθηταὶ αὐτοῦ", gloss: "his disciples believed in him" },
    ],
    grammar: [
      {
        heading: "First aorist: augment + stem + σα + secondary endings",
        body: [
          "The tell-tale sign is -σα-. ἔ-λυ-σα, ἐ-πίστευ-σα, ἐ-βάπτι-σα.",
          "The same consonant + σ rules from the future apply: ἔγραψα, ἔδοξα, ἔπεισα.",
          "Liquid verbs drop the σ and lengthen instead: ἀποστέλλω → ἀπέστειλα, μένω → ἔμεινα, κρίνω → ἔκρινα.",
        ],
        table: {
          caption: "First aorist active of λύω",
          headers: ["Person", "Singular", "Plural"],
          rows: [
            ["1st", "ἔλυσα", "ἐλύσαμεν"],
            ["2nd", "ἔλυσας", "ἐλύσατε"],
            ["3rd", "ἔλυσε(ν)", "ἔλυσαν"],
          ],
        },
      },
      {
        heading: "Second aorist: a different stem, the imperfect's endings",
        body: [
          "Second aorists have no σα. They change the verb STEM and then use the same secondary endings as the imperfect.",
          "The only way to tell ἔβαλλον (imperfect) from ἔβαλον (2nd aorist) is the double lambda. This is why you memorise principal parts.",
        ],
        table: {
          caption: "High-frequency second aorists you must know cold",
          headers: ["Present", "2nd Aorist", "Meaning"],
          rows: [
            ["λέγω", "εἶπον", "I said"],
            ["ἔρχομαι", "ἦλθον", "I came / went"],
            ["λαμβάνω", "ἔλαβον", "I took"],
            ["ὁράω", "εἶδον", "I saw"],
            ["ἐσθίω", "ἔφαγον", "I ate"],
            ["γίνομαι", "ἐγενόμην", "I became"],
            ["βάλλω", "ἔβαλον", "I threw"],
            ["εὑρίσκω", "εὗρον", "I found"],
            ["γινώσκω", "ἔγνων", "I knew"],
            ["φέρω", "ἤνεγκα", "I carried"],
          ],
        },
        tip: "There is NO difference in meaning between a first and a second aorist. It is purely morphological, like English 'walked' vs. 'ran'.",
      },
      {
        heading: "What the aorist actually means",
        body: [
          "ἀ-όριστος = 'un-bounded, undefined'. The aorist is the default, unmarked way of referring to an action as a complete whole.",
          "It does NOT mean 'once for all', 'punctiliar', or 'instantaneous'. ἐβασίλευσεν can cover a forty-year reign.",
          "Outside the indicative the aorist has no time reference at all: an aorist participle is not 'past', it is simply perfective.",
        ],
        tip: "Classic fallacy to avoid: preaching that an aorist imperative means 'do it once and for all'. Aspect ≠ Aktionsart. See Carson, Exegetical Fallacies, ch. 2.",
      },
    ],
    vocabIds: ["ginomai", "erchomai", "lambanw", "euriskw", "legw", "horaw", "exerchomai", "eiserchomai", "oida"],
    reading: {
      ref: "John 1:14",
      intro: "Two aorists and a perfect. Ask what viewpoint each one gives.",
      verses: [
        {
          greek:
            "Καὶ ὁ λόγος σὰρξ ἐγένετο καὶ ἐσκήνωσεν ἐν ἡμῖν, καὶ ἐθεασάμεθα τὴν δόξαν αὐτοῦ, δόξαν ὡς μονογενοῦς παρὰ πατρός, πλήρης χάριτος καὶ ἀληθείας.",
          english:
            "And the Word became flesh and pitched his tent among us, and we beheld his glory, glory as of an only Son from a Father, full of grace and truth.",
        },
      ],
    },
    quiz: [
      {
        prompt: "ἔβαλον vs. ἔβαλλον — which is the aorist?",
        options: ["ἔβαλλον", "ἔβαλον", "Both", "Neither"],
        answer: 1,
        explain: "Single λ = second aorist ('threw'); double λλ = imperfect ('was throwing').",
      },
      {
        prompt: "Which statement about the aorist is TRUE?",
        options: [
          "It always means a once-for-all action",
          "It always refers to past time, in every mood",
          "It presents an action as a complete whole, without commenting on duration",
          "It is the same as the perfect",
        ],
        answer: 2,
        explain:
          "Perfective aspect = external viewpoint. Duration is a lexical and contextual matter, not a tense-form matter.",
      },
      {
        prompt: "What is the aorist of ὁράω?",
        options: ["ὥρασα", "εἶδον", "ἑώρων", "ὄψομαι"],
        answer: 1,
        explain: "ὁράω is suppletive: aorist εἶδον, future ὄψομαι, perfect ἑώρακα.",
      },
    ],
  },
  {
    slug: "middle-passive",
    trackId: "intermediate",
    title: "Voice: Middle, Passive & the Death of 'Deponency'",
    greekTitle: "Διαθέσεις",
    summary:
      "Greek's three-voice system, the θη-aorist, and why modern grammarians have abandoned the category 'deponent verb'.",
    minutes: 30,
    kind: "morphology",
    objectives: [
      "Recognise middle/passive endings in every tense",
      "Understand subject-affectedness as the core of the middle voice",
      "Handle ἀπεκρίθη, ἐγενήθη and similar forms confidently",
    ],
    videos: [
      {
        id: "wQov4fIAI3g",
        kind: "video",
        title: "What is the middle voice in Greek?",
        channel: "Biblical Mastery Academy",
        note: "Corrects the standard 'I do it for myself' oversimplification.",
      },
      {
        id: "Y3RNtMf6ERE",
        kind: "video",
        title: "Deponent verbs: why we should stop talking about them",
        channel: "Biblical Mastery Academy",
        note: "The current scholarly consensus, explained simply.",
      },
      {
        id: "HZ18lHADl-k",
        kind: "video",
        title: "Passive and Middle Voices",
        channel: "Ian W. Scott",
        note: "Form-focused walkthrough of the endings.",
      },
      {
        id: "NUq-8hvNgqU",
        kind: "video",
        title: "Present Middle/Passive Indicative Endings Memory Device",
        channel: "Daily Dose of Greek",
        note: "A mnemonic that sticks.",
      },
    ],
    listening: [
      { greek: "λύομαι, λύῃ, λύεται", gloss: "I am loosed / loose myself, you…, he…" },
      { greek: "λυόμεθα, λύεσθε, λύονται", gloss: "we, you (pl.), they (middle/passive)" },
      { greek: "ἐβαπτίσθη ὑπὸ Ἰωάννου", gloss: "he was baptised by John" },
      { greek: "ἀπεκρίθη αὐτῷ ὁ Ἰησοῦς", gloss: "Jesus answered him" },
      { greek: "ἐγενήθη ὡσεὶ νεκρός", gloss: "he became like a dead man" },
    ],
    grammar: [
      {
        heading: "Three voices",
        body: [
          "ACTIVE — the subject performs: λύω, 'I loose'.",
          "PASSIVE — the subject receives: λύομαι, 'I am being loosed'. Agent expressed by ὑπό + genitive; means by ἐν or the bare dative.",
          "MIDDLE — the subject is INVOLVED IN or AFFECTED BY the action in some special way. English has no equivalent, which is why translations flatten it.",
        ],
        table: {
          caption: "Present middle/passive indicative (identical forms)",
          headers: ["Person", "Singular", "Plural"],
          rows: [
            ["1st", "λύομαι", "λυόμεθα"],
            ["2nd", "λύῃ", "λύεσθε"],
            ["3rd", "λύεται", "λύονται"],
          ],
        },
        tip: "In the present, imperfect and perfect the middle and passive are IDENTICAL in form. Only the aorist and future distinguish them (θη forms).",
      },
      {
        heading: "The θη-forms",
        body: [
          "Aorist passive inserts -θη-: ἐ-λύ-θη-ν, ἐ-λύ-θη-ς, ἐ-λύ-θη. Future passive adds -θησ-: λυ-θήσ-ομαι.",
          "But many θη-forms are not passive in meaning at all: ἀπεκρίθη 'he answered', ἐφοβήθη 'he was afraid', ἐπορεύθη 'he journeyed'. These are middle in sense.",
          "Modern analysis therefore treats -θη- as a MIDDLE marker that later specialised toward passive, not as an inherently passive morpheme.",
        ],
      },
      {
        heading: "Why 'deponent' is being retired",
        body: [
          "The old story: some verbs 'laid aside' (deponere) their active forms and are middle in form but active in meaning.",
          "The problem: verbs like ἔρχομαι, γίνομαι, ἀποκρίνομαι, δέχομαι, ἅπτομαι are all subject-affected — coming, becoming, replying, receiving, touching. The middle form is exactly right for their semantics.",
          "Better practice: call them 'middle-only' or 'middle-form' verbs and ask what subject-affectedness contributes, rather than declaring the voice meaningless.",
        ],
        tip: "Rutger Allan, Suzanne Kemmer, Jonathan Pennington and Constantine Campbell all converge here. Expect deponency to be absent from newer grammars.",
      },
    ],
    vocabIds: ["ginomai", "erchomai", "apokrinomai", "dynamai", "sozw", "egeirw", "baptizw", "hypo"],
    reading: {
      ref: "Mark 1:9-11",
      intro: "Passive, middle and active side by side in Jesus' baptism.",
      verses: [
        {
          greek:
            "Καὶ ἐγένετο ἐν ἐκείναις ταῖς ἡμέραις ἦλθεν Ἰησοῦς ἀπὸ Ναζαρὲτ τῆς Γαλιλαίας καὶ ἐβαπτίσθη εἰς τὸν Ἰορδάνην ὑπὸ Ἰωάννου.",
          english:
            "And it happened in those days that Jesus came from Nazareth of Galilee and was baptised in the Jordan by John.",
        },
        {
          greek:
            "καὶ εὐθὺς ἀναβαίνων ἐκ τοῦ ὕδατος εἶδεν σχιζομένους τοὺς οὐρανοὺς καὶ τὸ πνεῦμα ὡς περιστερὰν καταβαῖνον εἰς αὐτόν.",
          english:
            "And immediately, coming up out of the water, he saw the heavens being torn open and the Spirit descending on him like a dove.",
        },
      ],
    },
    quiz: [
      {
        prompt: "In the present tense, how do you tell middle from passive?",
        options: [
          "By the ending",
          "By the augment",
          "You cannot — the forms are identical; context decides",
          "By the accent",
        ],
        answer: 2,
        explain:
          "Present, imperfect and perfect have one middle/passive form set. Only the aorist and future split them.",
      },
      {
        prompt: "ἀπεκρίθη is best understood as…",
        greek: "ἀπεκρίθη",
        options: [
          "A true passive: 'he was answered'",
          "A θη-form that is middle in sense: 'he answered'",
          "An active aorist",
          "A perfect",
        ],
        answer: 1,
        explain: "A θη-form with middle semantics — the subject is affected by/engaged in the replying.",
      },
      {
        prompt: "How is the agent of a passive verb normally expressed?",
        options: ["ἐν + dative", "ὑπό + genitive", "εἰς + accusative", "διά + accusative"],
        answer: 1,
        explain: "ὑπό + genitive = personal agent. ἐν + dative or bare dative = impersonal means.",
      },
    ],
  },
  {
    slug: "third-declension",
    trackId: "intermediate",
    title: "Third Declension Nouns",
    greekTitle: "Τρίτη κλίσις",
    summary:
      "The 'hard' declension is actually one set of endings glued to a stem you find in the genitive. Learn the trick and it collapses.",
    minutes: 30,
    kind: "morphology",
    objectives: [
      "Derive the stem of any third-declension noun from its genitive singular",
      "Apply the σ-contraction rules to the nominative and dative plural",
      "Decline πνεῦμα, σάρξ, πίστις and βασιλεύς",
    ],
    videos: [
      {
        id: "MsQyv-6Df-8",
        kind: "video",
        title: "Biblical Greek: The Third Declension",
        channel: "Jonathan Rehfeldt",
        note: "The clearest systematic presentation of the stem-finding method.",
      },
      {
        id: "jhtsC77wiKU",
        kind: "video",
        title: "3rd Declension Emergency Helps",
        channel: "Bite Size Seminary",
        note: "Fast troubleshooting for forms that look impossible.",
      },
      {
        id: "O8RzxDtpsg0",
        kind: "video",
        title: "The Third Declension — Mounce BBG Chapter 10",
        channel: "Rob on the ROCK",
        note: "Aligned with the Mounce textbook if you are using it.",
      },
    ],
    listening: [
      { greek: "τὸ πνεῦμα τοῦ θεοῦ", gloss: "the Spirit of God" },
      { greek: "ἐν τῷ ὀνόματι τοῦ κυρίου", gloss: "in the name of the Lord" },
      { greek: "ὁ πατὴρ καὶ ἡ μήτηρ", gloss: "the father and the mother" },
      { greek: "διὰ πίστεως", gloss: "through faith" },
      { greek: "κατὰ σάρκα", gloss: "according to the flesh" },
      { greek: "ὁ βασιλεὺς τῶν Ἰουδαίων", gloss: "the king of the Jews" },
    ],
    grammar: [
      {
        heading: "The one rule that unlocks it",
        body: [
          "The nominative singular of a third-declension noun is often disguised. The GENITIVE singular is not.",
          "Take the genitive, drop -ος, and you have the true stem. Then add the endings.",
          "σάρξ, σαρκός → stem σαρκ-. πνεῦμα, πνεύματος → stem πνευματ-. πίστις, πίστεως → stem πιστ(ε)-.",
        ],
        table: {
          caption: "Third declension endings",
          headers: ["Case", "M/F sg", "M/F pl", "Neuter sg", "Neuter pl"],
          rows: [
            ["Nom.", "-ς or none", "-ες", "— (bare stem)", "-α"],
            ["Gen.", "-ος", "-ων", "-ος", "-ων"],
            ["Dat.", "-ι", "-σι(ν)", "-ι", "-σι(ν)"],
            ["Acc.", "-α or -ν", "-ας", "— (bare stem)", "-α"],
          ],
        },
      },
      {
        heading: "What σ does to the stem",
        body: [
          "Nominative singular and dative plural both add σ, and consonants react exactly as they do in the future tense.",
          "σαρκ + σ → σάρξ; σαρκ + σι → σαρξί(ν). ἐλπιδ + σ → ἐλπίς; ἐλπιδ + σι → ἐλπίσι(ν).",
          "Nasal and liquid stems simply drop before σ: ποιμεν + σι → ποιμέσι(ν).",
        ],
        table: {
          caption: "Four model nouns fully declined (singular / plural)",
          headers: ["Case", "πνεῦμα (n.)", "σάρξ (f.)", "πίστις (f.)", "βασιλεύς (m.)"],
          rows: [
            ["Nom. sg", "πνεῦμα", "σάρξ", "πίστις", "βασιλεύς"],
            ["Gen. sg", "πνεύματος", "σαρκός", "πίστεως", "βασιλέως"],
            ["Dat. sg", "πνεύματι", "σαρκί", "πίστει", "βασιλεῖ"],
            ["Acc. sg", "πνεῦμα", "σάρκα", "πίστιν", "βασιλέα"],
            ["Nom. pl", "πνεύματα", "σάρκες", "πίστεις", "βασιλεῖς"],
            ["Gen. pl", "πνευμάτων", "σαρκῶν", "πίστεων", "βασιλέων"],
            ["Dat. pl", "πνεύμασι(ν)", "σαρξί(ν)", "πίστεσι(ν)", "βασιλεῦσι(ν)"],
            ["Acc. pl", "πνεύματα", "σάρκας", "πίστεις", "βασιλεῖς"],
          ],
        },
        tip: "-ις/-εως nouns are all feminine abstract nouns (πίστις, πόλις, κρίσις, ἀνάστασις, γνῶσις). Note the odd genitive in -εως, which never affects the accent position.",
      },
    ],
    vocabIds: [
      "pneuma",
      "onoma",
      "pater",
      "meter",
      "aner",
      "gyne",
      "pistis",
      "polis",
      "sarx",
      "charis",
      "aiwn",
      "basileus",
      "hydwr",
      "phws",
      "soma",
      "hrema",
      "thelema",
      "archiereus",
    ],
    reading: {
      ref: "Ephesians 2:8-9",
      intro: "Four third-declension forms. Find each one and give its case.",
      verses: [
        {
          greek:
            "Τῇ γὰρ χάριτί ἐστε σεσῳσμένοι διὰ πίστεως· καὶ τοῦτο οὐκ ἐξ ὑμῶν, θεοῦ τὸ δῶρον·",
          english:
            "For by grace you have been saved through faith; and this is not from yourselves, it is the gift of God —",
        },
        { greek: "οὐκ ἐξ ἔργων, ἵνα μή τις καυχήσηται.", english: "not from works, so that no one may boast." },
      ],
    },
    quiz: [
      {
        prompt: "The genitive of σῶμα is σώματος. What is the dative plural?",
        options: ["σώμασι(ν)", "σωμάτοις", "σώματσι", "σωμάσιν"],
        answer: 0,
        explain: "Stem σωματ- + σι → the dental drops before σ: σώμασι(ν).",
      },
      {
        prompt: "How do you find a third-declension noun's stem?",
        options: [
          "Drop -ς from the nominative",
          "Drop -ος from the genitive singular",
          "Drop -ι from the dative",
          "It has to be memorised individually",
        ],
        answer: 1,
        explain: "This is why lexicons list the genitive: πίστις, -εως; σάρξ, σαρκός.",
      },
      {
        prompt: "πίστεως is which case?",
        greek: "πίστεως",
        options: ["Nominative singular", "Genitive singular", "Dative plural", "Accusative plural"],
        answer: 1,
        explain: "-εως is the genitive singular of the -ις class of third-declension nouns.",
      },
    ],
  },
  {
    slug: "participles",
    trackId: "intermediate",
    title: "Participles: The Heart of Greek Prose",
    greekTitle: "Μετοχή",
    summary:
      "Verbal adjectives. Adverbial, adjectival, substantival and periphrastic uses — plus the genitive absolute.",
    minutes: 45,
    kind: "syntax",
    objectives: [
      "Form present, aorist and perfect participles in all voices",
      "Classify a participle's syntactic function before translating it",
      "Read a genitive absolute correctly",
    ],
    videos: [
      {
        id: "0U7wu74GfvI",
        kind: "video",
        title: "Introduction to Participles",
        channel: "Jonathan Rehfeldt",
        note: "Systematic: forms first, then functions.",
      },
      {
        id: "1UHt0Nau3CQ",
        kind: "video",
        title: "How Greek Participles Work",
        channel: "Ken Schenck",
        note: "The conceptual model — a verb wearing adjective clothing.",
      },
      {
        id: "QjUM1bsuaqI",
        kind: "video",
        title: "Basics of Biblical Greek — Chapter 26 Overview (Participles)",
        channel: "Bill Mounce",
        note: "The textbook treatment, with translation strategy.",
      },
      {
        id: "Md040y1PE-I",
        kind: "video",
        title: "Reading the Greek NT with Participles — Matthew 8",
        channel: "Beta with Brett",
        note: "Apply it immediately to real text.",
      },
    ],
    listening: [
      { greek: "ὁ πιστεύων εἰς τὸν υἱὸν ἔχει ζωὴν αἰώνιον", gloss: "the one believing in the Son has eternal life" },
      { greek: "ἀκούσαντες δὲ ἐβαπτίσθησαν", gloss: "and having heard, they were baptised" },
      { greek: "λέγοντος αὐτοῦ ταῦτα", gloss: "while he was saying these things (genitive absolute)" },
      { greek: "ἦν διδάσκων", gloss: "he was teaching (periphrastic)" },
      { greek: "γεγραμμένον ἐστίν", gloss: "it stands written" },
    ],
    grammar: [
      {
        heading: "A participle is a verbal adjective",
        body: [
          "As a VERB it has tense-form (aspect) and voice, and it can take objects and adverbial modifiers.",
          "As an ADJECTIVE it has gender, number and case, and it agrees with the word it modifies.",
          "Parse a participle in six slots: tense–voice–PARTICIPLE–case–number–gender. λέγων = present active participle nominative singular masculine.",
        ],
        table: {
          caption: "Participle morpheme signposts",
          headers: ["Form", "Marker", "Masc. nom. sg", "Fem. nom. sg", "Neut. nom. sg"],
          rows: [
            ["Present active", "-ντ-", "λύων", "λύουσα", "λῦον"],
            ["Present mid/pass", "-μεν-", "λυόμενος", "λυομένη", "λυόμενον"],
            ["Aorist active", "-σαντ-", "λύσας", "λύσασα", "λῦσαν"],
            ["2nd aorist active", "-οντ- (aor. stem)", "λαβών", "λαβοῦσα", "λαβόν"],
            ["Aorist passive", "-θεντ-", "λυθείς", "λυθεῖσα", "λυθέν"],
            ["Perfect active", "-κοτ-", "λελυκώς", "λελυκυῖα", "λελυκός"],
            ["Perfect mid/pass", "reduplication + -μεν-", "λελυμένος", "λελυμένη", "λελυμένον"],
          ],
        },
        tip: "-μεν- almost always signals a middle/passive participle. -ντ- almost always signals an active one. Spot the morpheme before you spot the word.",
      },
      {
        heading: "Four functions",
        body: [
          "ADVERBIAL (circumstantial) — anarthrous, agrees with the subject, describes the circumstances of the main verb: temporal ('when/after'), causal ('because'), conditional ('if'), concessive ('although'), means ('by'), or attendant circumstance ('and').",
          "ADJECTIVAL — articular and attributive to a noun: ὁ ἄνθρωπος ὁ λέγων, 'the man who is speaking'.",
          "SUBSTANTIVAL — articular with no noun: ὁ πιστεύων, 'the one who believes'. Extremely common in John.",
          "PERIPHRASTIC — εἰμί + participle forming a compound verb: ἦν διδάσκων, 'he was teaching'.",
        ],
        tip: "Relative TIME rule: an aorist participle usually describes action ANTECEDENT to the main verb; a present participle describes action CONTEMPORANEOUS with it. This is relative, not absolute, time.",
      },
      {
        heading: "The genitive absolute",
        body: [
          "A noun/pronoun in the genitive + a participle in the genitive, grammatically unconnected to the main clause.",
          "λέγοντος αὐτοῦ ταῦτα, πολλοὶ ἐπίστευσαν = 'While he was saying these things, many believed.'",
          "Signal: a genitive participle whose subject is NOT the subject of the main verb. Translate as a subordinate temporal clause.",
        ],
      },
    ],
    vocabIds: ["pisteuw", "legw", "erchomai", "poiew", "lalew", "menw", "horaw", "akouw", "gpraphw"],
    reading: {
      ref: "Matthew 28:18-20",
      intro:
        "One imperative (μαθητεύσατε) surrounded by three participles. Classify each participle before translating.",
      verses: [
        {
          greek:
            "καὶ προσελθὼν ὁ Ἰησοῦς ἐλάλησεν αὐτοῖς λέγων· Ἐδόθη μοι πᾶσα ἐξουσία ἐν οὐρανῷ καὶ ἐπὶ τῆς γῆς.",
          english:
            "And Jesus came and spoke to them, saying: All authority in heaven and on earth has been given to me.",
        },
        {
          greek:
            "πορευθέντες οὖν μαθητεύσατε πάντα τὰ ἔθνη, βαπτίζοντες αὐτοὺς εἰς τὸ ὄνομα τοῦ πατρὸς καὶ τοῦ υἱοῦ καὶ τοῦ ἁγίου πνεύματος,",
          english:
            "Therefore, having gone, make disciples of all nations, baptising them in the name of the Father and of the Son and of the Holy Spirit,",
        },
        {
          greek:
            "διδάσκοντες αὐτοὺς τηρεῖν πάντα ὅσα ἐνετειλάμην ὑμῖν· καὶ ἰδοὺ ἐγὼ μεθ᾽ ὑμῶν εἰμι πάσας τὰς ἡμέρας ἕως τῆς συντελείας τοῦ αἰῶνος.",
          english:
            "teaching them to observe all that I commanded you; and behold, I am with you all the days until the end of the age.",
        },
      ],
    },
    quiz: [
      {
        prompt: "Parse ἀκούσαντες.",
        greek: "ἀκούσαντες",
        options: [
          "Aorist active participle nominative plural masculine",
          "Present active participle nominative singular masculine",
          "Aorist passive participle accusative plural",
          "Perfect middle participle genitive plural",
        ],
        answer: 0,
        explain: "-σαντ- = aorist active participle; -ες = nominative plural masculine.",
      },
      {
        prompt: "ὁ πιστεύων is which use of the participle?",
        greek: "ὁ πιστεύων",
        options: ["Adverbial", "Periphrastic", "Substantival", "Genitive absolute"],
        answer: 2,
        explain: "Article + participle with no noun = substantival: 'the one who believes'.",
      },
      {
        prompt: "What marks a genitive absolute?",
        options: [
          "A genitive noun and genitive participle unconnected to the main clause",
          "Any genitive participle",
          "A participle with the article",
          "εἰμί plus a participle",
        ],
        answer: 0,
        explain:
          "The construction stands grammatically 'loosed' (absolutus) from the rest of the sentence.",
      },
      {
        prompt: "An aorist participle normally describes action that is…",
        options: [
          "Always in the past",
          "Simultaneous with the main verb",
          "Antecedent to the main verb (relative time)",
          "Future relative to the main verb",
        ],
        answer: 2,
        explain:
          "Participles encode relative time. Aorist = usually prior; present = usually contemporaneous.",
      },
    ],
  },
  {
    slug: "infinitives-subjunctive",
    trackId: "intermediate",
    title: "Infinitives, Subjunctive & Imperative",
    greekTitle: "Ἀπαρέμφατον καὶ ὑποτακτική",
    summary:
      "The non-indicative moods: purpose, result, prohibition, exhortation, and the articular infinitive.",
    minutes: 40,
    kind: "syntax",
    objectives: [
      "Recognise all infinitive endings and the articular infinitive constructions",
      "Use ἵνα, ὅπως, ἐάν and the hortatory subjunctive",
      "Explain the aspectual force of present vs. aorist prohibitions",
    ],
    videos: [
      {
        id: "R1-BRoTk6cs",
        kind: "video",
        title: "Biblical Greek: Infinitives",
        channel: "Jonathan Rehfeldt",
        note: "Forms and the full range of uses.",
      },
      {
        id: "a7EikhE8sKI",
        kind: "video",
        title: "Koine Greek Infinitive: Grammar and Uses",
        channel: "Prof. Elder",
        note: "Especially good on the articular infinitive with prepositions.",
      },
      {
        id: "GyFgQGCdFxk",
        kind: "video",
        title: "Introduction to the Subjunctive",
        channel: "Tyler Stewart",
        note: "The lengthened connecting vowel and the main uses.",
      },
      {
        id: "bd4T8H-gR7Q",
        kind: "video",
        title: "Are subjunctives the easiest verb forms to recognise?",
        channel: "Biblical Mastery Academy",
        note: "A recognition shortcut you will use constantly.",
      },
      {
        id: "HHx_LLaPDts",
        kind: "video",
        title: "The Imperative Mood",
        channel: "Greek for Everyone",
        note: "Commands, prohibitions and their aspect.",
      },
    ],
    listening: [
      { greek: "θέλω πιστεῦσαι", gloss: "I want to believe" },
      { greek: "ἵνα πιστεύσητε", gloss: "in order that you may believe" },
      { greek: "ἐὰν ὁμολογῶμεν τὰς ἁμαρτίας ἡμῶν", gloss: "if we confess our sins" },
      { greek: "μὴ φοβοῦ", gloss: "stop being afraid / do not fear" },
      { greek: "ἀκολούθει μοι", gloss: "follow me!" },
      { greek: "ἐν τῷ σπείρειν αὐτόν", gloss: "while he was sowing (articular infinitive)" },
      { greek: "ἁγιασθήτω τὸ ὄνομά σου", gloss: "let your name be hallowed" },
    ],
    grammar: [
      {
        heading: "Infinitive: a verbal noun",
        body: [
          "It has tense-form (aspect) and voice, but no person or number. It is neuter singular for the purposes of the article.",
          "Present active -ειν (λύειν); aorist active -σαι (λῦσαι); 2nd aorist -εῖν (λαβεῖν); aorist passive -θῆναι (λυθῆναι); perfect active -κέναι; middle/passive -εσθαι / -σασθαι.",
        ],
        table: {
          caption: "Articular infinitive with prepositions",
          headers: ["Construction", "Force", "Example"],
          rows: [
            ["διὰ τό + inf.", "cause: 'because'", "διὰ τὸ μὴ ἔχειν ῥίζαν"],
            ["εἰς τό / πρὸς τό + inf.", "purpose: 'in order to'", "εἰς τὸ εἶναι αὐτὸν πρωτότοκον"],
            ["ἐν τῷ + inf.", "time: 'while / as'", "ἐν τῷ σπείρειν αὐτόν"],
            ["μετὰ τό + inf.", "time: 'after'", "μετὰ τὸ ἐγερθῆναί με"],
            ["πρὸ τοῦ / πρὶν + inf.", "time: 'before'", "πρὸ τοῦ σε Φίλιππον φωνῆσαι"],
            ["τοῦ + inf.", "purpose or result", "τοῦ ἀπολέσαι αὐτό"],
          ],
        },
        tip: "The subject of an infinitive goes in the ACCUSATIVE — the 'accusative of respect'. ἐν τῷ σπείρειν αὐτόν = 'in the sowing with respect to him' = 'while he was sowing'.",
      },
      {
        heading: "Subjunctive: the mood of projection",
        body: [
          "Recognition trick: the connecting vowel lengthens. ο → ω, ε → η. λύω/λύῃς/λύῃ, λύωμεν/λύητε/λύωσι(ν).",
          "There is no augment in the aorist subjunctive: λύσω (aor. subj.) vs. ἔλυσα (aor. ind.).",
          "Main uses: purpose/content with ἵνα or ὅπως; third-class condition with ἐάν; hortatory ('let us…') in the 1st plural; deliberative questions; emphatic negation with οὐ μή + aorist subjunctive.",
        ],
      },
      {
        heading: "Imperative and prohibition aspect",
        body: [
          "Second person: present -ε/-ετε, aorist -σον/-σατε. Third person: present -έτω/-έτωσαν, aorist -σάτω/-σάτωσαν — translate 'let him…'.",
          "PROHIBITIONS: μή + present imperative typically means 'stop doing / do not continue'; μή + aorist SUBJUNCTIVE means 'do not start / do not ever'.",
          "μὴ φοβοῦ (present) to a frightened person = 'stop being afraid'. μὴ φοβηθῇς (aorist subj.) = 'do not be afraid (at all)'.",
        ],
        tip: "Be careful: this distinction is a tendency, not a law. Aspect is the author's chosen viewpoint, and context can override the default.",
      },
    ],
    vocabIds: ["hina", "ean", "ei", "me", "thelw", "dynamai", "poiew", "aphiemi", "menw"],
    reading: {
      ref: "1 John 1:9 & John 20:31",
      intro: "A third-class condition, then a purpose clause with ἵνα.",
      verses: [
        {
          greek:
            "ἐὰν ὁμολογῶμεν τὰς ἁμαρτίας ἡμῶν, πιστός ἐστιν καὶ δίκαιος ἵνα ἀφῇ ἡμῖν τὰς ἁμαρτίας καὶ καθαρίσῃ ἡμᾶς ἀπὸ πάσης ἀδικίας.",
          english:
            "If we confess our sins, he is faithful and just so that he may forgive us our sins and cleanse us from all unrighteousness.",
        },
        {
          greek:
            "ταῦτα δὲ γέγραπται ἵνα πιστεύ[σ]ητε ὅτι Ἰησοῦς ἐστιν ὁ χριστὸς ὁ υἱὸς τοῦ θεοῦ, καὶ ἵνα πιστεύοντες ζωὴν ἔχητε ἐν τῷ ὀνόματι αὐτοῦ.",
          english:
            "But these things have been written so that you may believe that Jesus is the Christ, the Son of God, and that believing you may have life in his name.",
        },
      ],
    },
    quiz: [
      {
        prompt: "What always follows ἵνα?",
        options: ["Indicative", "Subjunctive", "Imperative", "Infinitive"],
        answer: 1,
        explain:
          "ἵνα takes the subjunctive (very rare future indicative exceptions). It marks purpose or content.",
      },
      {
        prompt: "ἐν τῷ σπείρειν αὐτόν means…",
        greek: "ἐν τῷ σπείρειν αὐτόν",
        options: [
          "because he sowed",
          "while he was sowing",
          "in order that he might sow",
          "after he sowed",
        ],
        answer: 1,
        explain: "ἐν τῷ + infinitive = contemporaneous time; αὐτόν is the accusative subject.",
      },
      {
        prompt: "μὴ φοβοῦ (present imperative) most naturally means…",
        greek: "μὴ φοβοῦ",
        options: [
          "Never be afraid at any time",
          "Stop being afraid",
          "You will not be afraid",
          "He should not be afraid",
        ],
        answer: 1,
        explain:
          "A present prohibition typically addresses action already in progress: 'stop / do not continue'.",
      },
      {
        prompt: "How do you spot an aorist subjunctive versus an aorist indicative?",
        options: [
          "The subjunctive has no augment and has a lengthened vowel",
          "The subjunctive has an extra σ",
          "They are identical",
          "The indicative has no augment",
        ],
        answer: 0,
        explain: "ἔλυσα (indicative, augmented) vs. λύσω (subjunctive, unaugmented, lengthened vowel).",
      },
    ],
  },
  {
    slug: "perfect-mi-contract",
    trackId: "intermediate",
    title: "Perfect Tense, Contract Verbs & μι-Verbs",
    greekTitle: "Παρακείμενος",
    summary:
      "The last three morphological hurdles: reduplication, vowel contraction, and the athematic conjugation.",
    minutes: 40,
    kind: "morphology",
    objectives: [
      "Identify reduplication and the κ of the perfect active",
      "Apply the contraction rules for -άω, -έω and -όω verbs",
      "Conjugate δίδωμι, τίθημι and ἵστημι in the present and aorist",
    ],
    videos: [
      {
        id: "g0ARkyl5URY",
        kind: "video",
        title: "Biblical Greek: The Perfect Tense",
        channel: "Jonathan Rehfeldt",
        note: "Forms plus the aspectual meaning debate in brief.",
      },
      {
        id: "7O2dgEyHfn8",
        kind: "video",
        title: "Introduction to the Perfect Tense",
        channel: "Tyler Stewart",
        note: "Excellent on γέγραπται and other high-frequency perfects.",
      },
      {
        id: "eQo4alDko8I",
        kind: "video",
        title: "Biblical Greek: Contract Verbs",
        channel: "Jonathan Rehfeldt",
        note: "The three contract families and their rules.",
      },
      {
        id: "E0GE6RxVZow",
        kind: "video",
        title: "Introduction to Contract Verbs",
        channel: "Tyler Stewart",
        note: "A second pass — contraction rewards repetition.",
      },
    ],
    listening: [
      { greek: "γέγραπται", gloss: "it stands written" },
      { greek: "πεπίστευκα", gloss: "I have believed (and still do)" },
      { greek: "τετέλεσται", gloss: "it has been finished" },
      { greek: "ἀγαπῶ, ἀγαπᾷς, ἀγαπᾷ", gloss: "I love, you love, he loves (α-contract)" },
      { greek: "ποιῶ, ποιεῖς, ποιεῖ", gloss: "I do, you do, he does (ε-contract)" },
      { greek: "πληρῶ, πληροῖς, πληροῖ", gloss: "I fill, you fill, he fills (ο-contract)" },
      { greek: "δίδωμι, δίδως, δίδωσιν", gloss: "I give, you give, he gives" },
    ],
    grammar: [
      {
        heading: "The perfect: reduplication + κα",
        body: [
          "Reduplication repeats the initial consonant with ε: λύω → λέλυκα, πιστεύω → πεπίστευκα, γράφω → γέγραφα.",
          "Aspirated consonants reduplicate with their unaspirated partner: θ→τ, φ→π, χ→κ. θνῄσκω → τέθνηκα.",
          "Verbs beginning with a vowel or two consonants reduplicate by lengthening instead: ἀκούω → ἀκήκοα (Attic reduplication); γινώσκω → ἔγνωκα.",
          "Perfect middle/passive has reduplication but NO κ and takes endings directly on the stem: γέγραπται, τετέλεσται, σεσῳσμένοι.",
        ],
        tip: "Traditional description: 'a past action with abiding present results'. Porter and Campbell instead call it STATIVE aspect — the focus is the state of the subject. Either way, the perfect is heavily marked and always exegetically significant.",
      },
      {
        heading: "Contract verbs",
        body: [
          "Lexical forms ending -άω, -έω, -όω contract the stem vowel with the connecting vowel in the present and imperfect only. All other tenses lengthen the vowel and behave normally (ἀγαπήσω, ἐποίησα, πεπλήρωκα).",
        ],
        table: {
          caption: "Contraction rules",
          headers: ["Combination", "α-contract", "ε-contract", "ο-contract"],
          rows: [
            ["+ ω", "ω (ἀγαπῶ)", "ω (ποιῶ)", "ω (πληρῶ)"],
            ["+ εις", "ᾳς (ἀγαπᾷς)", "εις (ποιεῖς)", "οις (πληροῖς)"],
            ["+ ει", "ᾳ (ἀγαπᾷ)", "ει (ποιεῖ)", "οι (πληροῖ)"],
            ["+ ομεν", "ωμεν (ἀγαπῶμεν)", "οῦμεν (ποιοῦμεν)", "οῦμεν (πληροῦμεν)"],
            ["+ ετε", "ᾶτε (ἀγαπᾶτε)", "εῖτε (ποιεῖτε)", "οῦτε (πληροῦτε)"],
            ["+ ουσι", "ῶσι (ἀγαπῶσι)", "οῦσι (ποιοῦσι)", "οῦσι (πληροῦσι)"],
          ],
        },
        tip: "Shortcut: if you see a circumflex on the ending of a present-tense verb, suspect a contract verb.",
      },
      {
        heading: "μι-verbs (athematic)",
        body: [
          "About a dozen very common verbs conjugate without a connecting vowel and reduplicate their present stem with ι: δίδωμι (δο-), τίθημι (θε-), ἵστημι (στα-), δείκνυμι, ἀφίημι, ἀπόλλυμι.",
          "Present active singular: -μι, -ς, -σι(ν). Plural: -μεν, -τε, -ασι(ν).",
          "The aorist is often κ-aorist: ἔδωκα, ἔθηκα, ἀφῆκα.",
          "ἵστημι is doubly tricky: transitive in some tenses ('I set') and intransitive in others ('I stand'). ἔστην = 'I stood'; ἕστηκα = 'I stand / am standing'.",
        ],
        table: {
          caption: "δίδωμι and τίθημι, present active indicative",
          headers: ["Person", "δίδωμι", "τίθημι", "ἵστημι"],
          rows: [
            ["1 sg", "δίδωμι", "τίθημι", "ἵστημι"],
            ["2 sg", "δίδως", "τίθης", "ἵστης"],
            ["3 sg", "δίδωσι(ν)", "τίθησι(ν)", "ἵστησι(ν)"],
            ["1 pl", "δίδομεν", "τίθεμεν", "ἵσταμεν"],
            ["2 pl", "δίδοτε", "τίθετε", "ἵστατε"],
            ["3 pl", "διδόασι(ν)", "τιθέασι(ν)", "ἱστᾶσι(ν)"],
          ],
        },
      },
    ],
    vocabIds: ["didwmi", "tithemi", "histemi", "aphiemi", "apollymi", "agapaw", "poiew", "lalew", "plerow", "kalew", "zetew", "horaw"],
    reading: {
      ref: "John 19:30 & Romans 5:5",
      intro: "Two perfects that carry enormous theological weight.",
      verses: [
        {
          greek:
            "ὅτε οὖν ἔλαβεν τὸ ὄξος ὁ Ἰησοῦς εἶπεν· Τετέλεσται, καὶ κλίνας τὴν κεφαλὴν παρέδωκεν τὸ πνεῦμα.",
          english:
            "When therefore Jesus had received the sour wine he said, 'It is finished', and bowing his head he handed over the spirit.",
        },
        {
          greek:
            "ἡ δὲ ἐλπὶς οὐ καταισχύνει, ὅτι ἡ ἀγάπη τοῦ θεοῦ ἐκκέχυται ἐν ταῖς καρδίαις ἡμῶν διὰ πνεύματος ἁγίου τοῦ δοθέντος ἡμῖν.",
          english:
            "And hope does not put to shame, because the love of God has been poured out in our hearts through the Holy Spirit who was given to us.",
        },
      ],
    },
    quiz: [
      {
        prompt: "γέγραπται is which tense and voice?",
        greek: "γέγραπται",
        options: [
          "Aorist active",
          "Perfect middle/passive indicative 3rd singular",
          "Present passive",
          "Pluperfect active",
        ],
        answer: 1,
        explain:
          "Reduplication γε- + no κ + -ται = perfect middle/passive, 3rd singular: 'it stands written'.",
      },
      {
        prompt: "ποιέω + ει contracts to…",
        options: ["ποιῇ", "ποιεῖ", "ποιοῖ", "ποιᾷ"],
        answer: 1,
        explain: "ε + ει = ει. Hence ποιεῖ with the circumflex signalling contraction.",
      },
      {
        prompt: "What is distinctive about μι-verbs?",
        options: [
          "They have no aorist",
          "They add no connecting (thematic) vowel and reduplicate the present stem with ι",
          "They are always passive",
          "They only occur in the Septuagint",
        ],
        answer: 1,
        explain: "δί-δω-μι, τί-θη-μι, ἵ-στη-μι: athematic conjugation with iota reduplication.",
      },
    ],
  },

  // ══════════════════════ ADVANCED ══════════════════════
  {
    slug: "case-syntax",
    trackId: "advanced",
    title: "Exegetical Syntax of the Cases",
    greekTitle: "Συντακτικόν",
    summary:
      "Wallace-level case categories: subjective vs. objective genitive, dative of means vs. sphere, and how to argue for a reading.",
    minutes: 45,
    kind: "seminar",
    objectives: [
      "Name and defend a specific syntactic label for any case in a text",
      "Weigh subjective against objective genitive in πίστις Χριστοῦ",
      "Use case syntax as evidence in an exegetical argument",
    ],
    videos: [
      {
        id: "gxwg_Q45YJo",
        kind: "video",
        title: "Greek Grammar Beyond the Basics — The Article, Lecture 2",
        channel: "Zondervan / Daniel B. Wallace",
        note: "Wallace himself, teaching from the standard intermediate grammar.",
      },
      {
        id: "prq8T5ZnHvs",
        kind: "video",
        title: "Syntax 3: The Genitive",
        channel: "David Hutchison",
        note: "A systematic run through the genitive categories.",
      },
      {
        id: "lTIkviODa-c",
        kind: "video",
        title: "The Genitive (Biblical Greek Grammar Basics)",
        channel: "Biblical Greek",
        note: "Compact reference-style overview.",
      },
      {
        id: "T3UEMC7V1qE",
        kind: "video",
        title: "Should you be using Wallace's Greek Grammar Beyond the Basics?",
        channel: "Biblical Mastery Academy",
        note: "How to use — and how not to over-use — syntactic taxonomies.",
      },
      {
        id: "CmahXPfpj_w",
        kind: "video",
        title: "Double Accusative Construction in Biblical Greek",
        channel: "Daily Dose of Greek",
        note: "A short, concrete syntactic case study.",
      },
    ],
    listening: [
      { greek: "ἡ ἀγάπη τοῦ Χριστοῦ συνέχει ἡμᾶς", gloss: "the love of Christ compels us (subj. or obj. genitive?)" },
      { greek: "διὰ πίστεως Ἰησοῦ Χριστοῦ", gloss: "through faith in / the faithfulness of Jesus Christ" },
      { greek: "τῇ γὰρ χάριτί ἐστε σεσῳσμένοι", gloss: "for by grace you have been saved (dative of means)" },
      { greek: "ἐν Χριστῷ Ἰησοῦ", gloss: "in Christ Jesus (dative of sphere)" },
      { greek: "ἡμέρας καὶ νυκτός", gloss: "by day and by night (genitive of time within which)" },
    ],
    grammar: [
      {
        heading: "The genitive: 33 categories, five questions",
        body: [
          "Rather than memorising Wallace's full taxonomy, ask five diagnostic questions of any genitive:",
          "1. Is the head noun a verbal noun (ἀγάπη, πίστις, γνῶσις)? If so, subjective vs. objective genitive is live.",
          "2. Could 'of' be replaced by 'characterised by' (attributive genitive: σῶμα τῆς ἁμαρτίας = 'sinful body')?",
          "3. Is it partitive ('some of')? τινες τῶν γραμματέων.",
          "4. Is it appositional ('which is')? ὁ ναὸς τοῦ σώματος αὐτοῦ = 'the temple, namely his body'.",
          "5. Is it governed by a preposition, verb, or adjective that simply requires the genitive? Then stop labelling.",
        ],
        table: {
          caption: "High-value genitive categories",
          headers: ["Category", "Test", "Example"],
          rows: [
            ["Subjective", "Head noun's action DONE BY the genitive", "ἡ ἀγάπη τοῦ θεοῦ = God's love for us"],
            ["Objective", "Head noun's action DONE TO the genitive", "ὁ ζῆλος τοῦ οἴκου = zeal for your house"],
            ["Plenary", "Both at once, deliberately", "πίστις Χριστοῦ (arguably)"],
            ["Attributive", "Genitive functions as an adjective", "ὁ οἰκονόμος τῆς ἀδικίας = the dishonest manager"],
            ["Partitive", "Whole of which head is a part", "τὸ τρίτον τῆς γῆς"],
            ["Source", "'out of / from'", "ἡ δικαιοσύνη ἐκ θεοῦ"],
            ["Apposition", "'namely'", "τὸ σημεῖον τῆς περιτομῆς"],
            ["Time", "Kind of time within which", "νυκτός = during the night"],
          ],
        },
      },
      {
        heading: "The dative: three super-categories",
        body: [
          "PURE DATIVE (to/for) — indirect object, dative of advantage/disadvantage, possession, reference.",
          "INSTRUMENTAL (by/with) — means, manner, agency, cause, association.",
          "LOCATIVE (in/at/on) — sphere, time when.",
          "Ephesians 2:8 τῇ χάριτι is instrumental (means): 'by grace'. Romans 8:1 ἐν Χριστῷ is locative (sphere).",
        ],
        tip: "Do not multiply labels. A label is only worth defending if a different label would change the translation or the theology.",
      },
      {
        heading: "Case study: πίστις Χριστοῦ",
        body: [
          "Objective reading: 'faith IN Christ' — the traditional Protestant rendering (Dunn, Moo). Christ is the object of the believer's faith.",
          "Subjective reading: 'the faithfulness OF Christ' — Christ's own covenant faithfulness is the ground of justification (Hays, Campbell, Wright).",
          "Evidence for subjective: elsewhere πίστις + personal genitive is normally subjective (Rom 4:16 πίστις Ἀβραάμ); and Rom 3:22 would otherwise be redundant with εἰς πάντας τοὺς πιστεύοντας.",
          "Evidence for objective: Paul uses πιστεύω εἰς Χριστόν explicitly and often; and Gal 2:16 juxtaposes the phrase with a finite verb of believing.",
          "Your job as an exegete is not to pick a side from a chart but to weigh usage, context and argument flow — and to say which way the evidence leans and why.",
        ],
      },
    ],
    vocabIds: ["pistis", "charis", "dikaiosyne", "agape", "sarx", "pneuma", "diatheke", "koinwnia"],
    reading: {
      ref: "Romans 3:21-24",
      intro: "Label every genitive and dative in these verses, then defend two of your labels.",
      verses: [
        {
          greek:
            "Νυνὶ δὲ χωρὶς νόμου δικαιοσύνη θεοῦ πεφανέρωται, μαρτυρουμένη ὑπὸ τοῦ νόμου καὶ τῶν προφητῶν,",
          english:
            "But now, apart from law, the righteousness of God has been revealed, being witnessed to by the Law and the Prophets —",
        },
        {
          greek:
            "δικαιοσύνη δὲ θεοῦ διὰ πίστεως Ἰησοῦ Χριστοῦ, εἰς πάντας τοὺς πιστεύοντας· οὐ γάρ ἐστιν διαστολή,",
          english:
            "a righteousness of God through faith in / the faithfulness of Jesus Christ, for all who believe. For there is no distinction,",
        },
        {
          greek:
            "δικαιούμενοι δωρεὰν τῇ αὐτοῦ χάριτι διὰ τῆς ἀπολυτρώσεως τῆς ἐν Χριστῷ Ἰησοῦ·",
          english:
            "being justified freely by his grace through the redemption that is in Christ Jesus;",
        },
      ],
    },
    quiz: [
      {
        prompt: "In ὁ ζῆλος τοῦ οἴκου σου ('zeal for your house'), τοῦ οἴκου is…",
        options: ["Subjective genitive", "Objective genitive", "Partitive genitive", "Genitive of source"],
        answer: 1,
        explain: "The house RECEIVES the zeal; it is the object of the verbal idea in ζῆλος.",
      },
      {
        prompt: "τῇ χάριτι in Ephesians 2:8 is best labelled…",
        greek: "τῇ γὰρ χάριτί ἐστε σεσῳσμένοι",
        options: [
          "Dative of sphere",
          "Dative of means/instrument",
          "Dative of possession",
          "Dative of time",
        ],
        answer: 1,
        explain: "Grace is the instrument by which salvation is accomplished: 'by grace'.",
      },
      {
        prompt: "Which is the strongest grammatical argument FOR the subjective reading of πίστις Χριστοῦ?",
        options: [
          "It sounds more Christ-centred",
          "πίστις + personal genitive elsewhere in Paul is normally subjective (e.g. πίστις Ἀβραάμ)",
          "The genitive can never be objective",
          "Because Luther said so",
        ],
        answer: 1,
        explain:
          "Analogical usage within the same author is the strongest kind of grammatical evidence.",
      },
    ],
  },
  {
    slug: "verbal-aspect",
    trackId: "advanced",
    title: "Verbal Aspect Theory",
    greekTitle: "Ἡ θεωρία τοῦ ποιοῦ τῆς ἐνεργείας",
    summary:
      "The most important development in Greek grammar in a century: Porter, Fanning and Campbell on what tense-forms actually encode.",
    minutes: 50,
    kind: "seminar",
    objectives: [
      "Define aspect, Aktionsart and tense precisely and distinguish them",
      "Summarise the Porter / Fanning / Campbell positions and their disagreements",
      "Apply aspect prominence to narrative and discourse",
    ],
    videos: [
      {
        id: "HLdoIz34_XU",
        kind: "video",
        title: "Verbal Aspect Made Easy!",
        channel: "Kairos Classroom",
        note: "Start here for the clearest on-ramp.",
      },
      {
        id: "b0-v8Dd1zsE",
        kind: "video",
        title: "Three Views of Verbal Aspect: Fanning, Porter, and Campbell",
        channel: "Jonathan Wolters",
        note: "A genuinely even-handed comparison of the three schools.",
      },
      {
        id: "qKxigbiuki0",
        kind: "video",
        title: "Con Campbell — Tense and Aspect",
        channel: "Southeastern Seminary",
        note: "A leading advocate presenting his own case.",
      },
      {
        id: "OERYu4UWXms",
        kind: "video",
        title: "NT Greek, Verbal Aspect Theory & Interpreting the Bible",
        channel: "Theology in the Raw (with Constantine Campbell)",
        note: "Long-form conversation on why this matters for preaching.",
      },
      {
        id: "z305WD-fpj8",
        kind: "video",
        title: "Clarification on Verbal Aspect",
        channel: "Daniel Brueske",
        note: "Cleans up the most common misunderstandings.",
      },
    ],
    listening: [
      { greek: "ἔρχεται ὁ ἰσχυρότερός μου", gloss: "the one stronger than I is coming (historic present)" },
      { greek: "καὶ λέγει αὐτοῖς", gloss: "and he says to them (present in past narrative)" },
      { greek: "τετέλεσται", gloss: "it stands finished (perfect — stative/heightened proximity)" },
      { greek: "ἐβασίλευσεν ὁ θάνατος", gloss: "death reigned (aorist over a long span)" },
      { greek: "ἐδίδασκεν αὐτούς", gloss: "he was teaching them (imperfect — background)" },
    ],
    grammar: [
      {
        heading: "Three terms you must keep apart",
        body: [
          "TENSE — grammaticalised time reference. Contested in Greek: Porter denies the Greek verb encodes time at all; Fanning and most traditional grammarians retain time in the indicative.",
          "ASPECT — the author's chosen VIEWPOINT on the action, encoded in the tense-form. Perfective (external, whole), imperfective (internal, unfolding), stative/perfect (state).",
          "AKTIONSART — the objective kind of action, determined by lexeme + context + adverbials, not by morphology. Punctiliar, iterative, ingressive, gnomic, etc.",
          "The cardinal error is to read Aktionsart directly off a tense-form. 'Aorist means once-for-all' collapses aspect into Aktionsart.",
        ],
        table: {
          caption: "Aspect map of the Greek tense-forms",
          headers: ["Tense-form", "Aspect", "Traditional time", "Discourse function (narrative)"],
          rows: [
            ["Aorist", "Perfective", "Past", "Mainline / backbone events"],
            ["Present", "Imperfective", "Present", "Foreground; historic present = highlighting"],
            ["Imperfect", "Imperfective", "Past", "Background, offline description"],
            ["Perfect", "Stative (or heightened proximity)", "Past act, present state", "Frontground — maximum prominence"],
            ["Pluperfect", "Stative + remoteness", "Past state", "Deep background"],
            ["Future", "Expectation (not truly aspectual)", "Future", "Projection"],
          ],
        },
      },
      {
        heading: "The three positions in brief",
        body: [
          "STANLEY PORTER (1989): Greek tense-forms are entirely non-temporal, even in the indicative. Time is supplied by deixis and context. Three aspects: perfective (aorist), imperfective (present/imperfect), stative (perfect/pluperfect). Aspect creates discourse PROMINENCE: background–foreground–frontground.",
          "BUIST FANNING (1990): Aspect is primary but time is genuinely grammaticalised in the indicative. Aktionsart arises from the interaction of aspect with lexis and context, and Fanning maps that interaction in detail.",
          "CONSTANTINE CAMPBELL (2007–08): Accepts non-temporal tense-forms but replaces 'stative aspect' for the perfect with imperfective aspect plus HEIGHTENED PROXIMITY. Uses spatial values (remoteness/proximity) rather than time.",
          "Where they agree — and this is the consensus that matters — aspect, not time, is the semantic core of the Greek verb; and no single English tense reliably renders a Greek tense-form.",
        ],
        tip: "For your bookshelf: Porter, Verbal Aspect in the Greek of the New Testament; Fanning, Verbal Aspect in New Testament Greek; Campbell, Basics of Verbal Aspect; Runge & Fresch (eds.), The Greek Verb Revisited (2016) — the best state-of-the-question volume.",
      },
      {
        heading: "Using aspect in exegesis",
        body: [
          "Mark's historic presents (ἔρχεται, λέγει) are not sloppy style; they spotlight a new scene or a key speech.",
          "A cluster of imperfects slows the narrative and paints scenery (Mark 1:21-22).",
          "A perfect in the middle of aorists is a flare: τετέλεσται, γέγραπται, ἀπόλωλεν.",
          "Ask not 'what time is this?' but 'why did the author choose this viewpoint here, when another was available?'",
        ],
      },
    ],
    vocabIds: ["erchomai", "legw", "ginomai", "menw", "oida", "histemi", "plerwma", "parousia"],
    reading: {
      ref: "Mark 1:1-8 (aspect audit)",
      intro:
        "Mark the tense-form of every verb. Then explain the shift from aorist to present at verse 7.",
      verses: [
        {
          greek: "Ἀρχὴ τοῦ εὐαγγελίου Ἰησοῦ Χριστοῦ υἱοῦ θεοῦ. Καθὼς γέγραπται ἐν τῷ Ἠσαΐᾳ τῷ προφήτῃ·",
          english:
            "The beginning of the gospel of Jesus Christ, the Son of God. As it stands written in Isaiah the prophet:",
        },
        {
          greek:
            "ἐγένετο Ἰωάννης ὁ βαπτίζων ἐν τῇ ἐρήμῳ καὶ κηρύσσων βάπτισμα μετανοίας εἰς ἄφεσιν ἁμαρτιῶν.",
          english:
            "John the baptiser appeared in the wilderness, proclaiming a baptism of repentance for the forgiveness of sins.",
        },
        {
          greek:
            "καὶ ἐκήρυσσεν λέγων· Ἔρχεται ὁ ἰσχυρότερός μου ὀπίσω μου, οὗ οὐκ εἰμὶ ἱκανὸς κύψας λῦσαι τὸν ἱμάντα τῶν ὑποδημάτων αὐτοῦ.",
          english:
            "And he was preaching, saying: The one stronger than I is coming after me, of whom I am not worthy to stoop down and untie the strap of his sandals.",
        },
      ],
    },
    quiz: [
      {
        prompt: "Which pair is correctly matched?",
        options: [
          "Aspect = objective kind of action",
          "Aktionsart = grammaticalised viewpoint",
          "Aspect = author's chosen viewpoint encoded in the tense-form",
          "Tense = lexical meaning of the verb",
        ],
        answer: 2,
        explain:
          "Aspect is semantic and grammaticalised; Aktionsart is pragmatic and emerges from lexis plus context.",
      },
      {
        prompt: "What does Porter claim that Fanning denies?",
        options: [
          "That aspect exists in Greek",
          "That Greek tense-forms do not grammaticalise time even in the indicative",
          "That the aorist is perfective",
          "That the present is imperfective",
        ],
        answer: 1,
        explain:
          "Porter's non-temporality thesis is the sharpest point of disagreement; Fanning retains time in the indicative.",
      },
      {
        prompt: "How does Campbell reanalyse the perfect?",
        options: [
          "As perfective aspect with remoteness",
          "As imperfective aspect with heightened proximity",
          "As a pure past tense",
          "As having no aspect",
        ],
        answer: 1,
        explain:
          "Campbell replaces Porter's 'stative aspect' with imperfective aspect plus a spatial value of heightened proximity.",
      },
      {
        prompt: "Mark's historic present (ἔρχεται in a past narrative) most likely functions to…",
        options: [
          "Indicate present time",
          "Show the author's poor Greek",
          "Highlight a new scene or important speech",
          "Mark a passive voice",
        ],
        answer: 2,
        explain:
          "In narrative, the imperfective present against an aorist backbone raises prominence — a discourse device, not a temporal claim.",
      },
    ],
  },
  {
    slug: "discourse-grammar",
    trackId: "advanced",
    title: "Discourse Grammar & Word Order",
    greekTitle: "Λόγου ἀνάλυσις",
    summary:
      "Above the sentence: information structure, connectives, forward-pointing devices, and why Greek word order is meaningful after all.",
    minutes: 45,
    kind: "seminar",
    objectives: [
      "Analyse marked word order as topic and focus",
      "Read δέ, γάρ, οὖν, καί and ἀλλά as processing instructions",
      "Identify forward-pointing references and thematic highlighting",
    ],
    videos: [
      {
        id: "UAs0dkeVNmo",
        kind: "video",
        title: "Steven Runge — Word Order",
        channel: "Southeastern Seminary",
        note: "The author of Discourse Grammar of the Greek New Testament on his central topic.",
      },
      {
        id: "fPRUSLbFR8M",
        kind: "video",
        title: "Stephen Levinsohn — Discourse Analysis",
        channel: "Southeastern Seminary",
        note: "The SIL functional tradition that underlies most of this work.",
      },
      {
        id: "8rEUkFzHq38",
        kind: "video",
        title: "Greek III, Session 16: Discourse Analysis",
        channel: "Dave Mathewson / BiblicaleLearning",
        note: "A full seminary session applying the method to text.",
      },
      {
        id: "ckcogSXbn7E",
        kind: "video",
        title: "Discourse Analysis Simplified: An Introduction",
        channel: "Pastor Tanner Biblical Studies",
        note: "A practical, preacher-facing summary.",
      },
    ],
    listening: [
      { greek: "ὑμεῖς δὲ τίνα με λέγετε εἶναι;", gloss: "But YOU — who do you say that I am? (fronted pronoun = focus)" },
      { greek: "θεὸς ἦν ὁ λόγος", gloss: "God was the Word (fronted predicate = emphasis)" },
      { greek: "τοῦτο δέ ἐστιν τὸ θέλημα", gloss: "and THIS is the will (forward-pointing reference)" },
      { greek: "ἐγὼ δὲ λέγω ὑμῖν", gloss: "but I say to you (contrastive topic)" },
    ],
    grammar: [
      {
        heading: "Default and marked order",
        body: [
          "The pragmatically neutral order in Koine narrative is Verb–Subject–Object, though the verb-initial default is weaker in the epistles.",
          "Anything moved to the FRONT of its clause is doing pragmatic work. Runge distinguishes two front-of-clause positions:",
          "TOPIC (P1) — establishes or switches the frame: 'as for X…'. Often a temporal or spatial phrase, or a switched subject.",
          "FOCUS (P2) — the most salient new information, placed immediately before the verb.",
          "θεὸς ἦν ὁ λόγος fronts the predicate nominative: the emphasis falls on the divine nature that the Logos possesses.",
        ],
        tip: "Never say 'the Greek emphasises X' without saying WHAT the unmarked alternative would have been. Emphasis is a choice against a default.",
      },
      {
        heading: "Connectives as processing instructions",
        body: [
          "καί — continuity, no constraint: 'and the next thing'. In Mark it strings the backbone together.",
          "δέ — a development marker: a new step, often a new subject or scene. NOT primarily 'but'.",
          "γάρ — strengthening/explanation: what follows supports what precedes. Backgrounded material.",
          "οὖν — inferential development: resumes the mainline after an interruption, or draws a conclusion.",
          "ἀλλά — a genuine correction or replacement of the preceding element.",
          "τότε, ἰδού, καὶ ἐγένετο — attention-getters and scene-shift markers.",
          "ASYNDETON (no connective at all) is itself marked: it often signals a list, a sharp break, or high emotion.",
        ],
      },
      {
        heading: "Devices worth hunting for",
        body: [
          "Forward-pointing reference: a cataphoric pronoun or 'this' that creates suspense — αὕτη ἐστὶν ἡ ἐντολή…",
          "Redundant quotative frames (ἀποκριθεὶς εἶπεν) slow the pace and elevate the speech that follows.",
          "Overspecification: naming a participant who is already clear from context signals a new discourse unit.",
          "Tail–head linkage: repeating the last verb of one sentence at the start of the next to chain events.",
          "Point/counterpoint sets: μέν … δέ, οὐ … ἀλλά.",
        ],
        tip: "Reference works: Runge, Discourse Grammar of the Greek New Testament (2010); Levinsohn, Discourse Features of New Testament Greek (2nd ed.); Black & Runge, Linguistics and NT Greek.",
      },
    ],
    vocabIds: ["de", "gar", "oun", "alla", "kai", "men", "hoti", "hws", "hina"],
    reading: {
      ref: "Mark 8:27-30",
      intro:
        "Track every connective, and explain the fronted ὑμεῖς in v. 29. Why does Mark switch from καί to δέ?",
      verses: [
        {
          greek:
            "Καὶ ἐξῆλθεν ὁ Ἰησοῦς καὶ οἱ μαθηταὶ αὐτοῦ εἰς τὰς κώμας Καισαρείας τῆς Φιλίππου· καὶ ἐν τῇ ὁδῷ ἐπηρώτα τοὺς μαθητὰς αὐτοῦ λέγων αὐτοῖς· Τίνα με λέγουσιν οἱ ἄνθρωποι εἶναι;",
          english:
            "And Jesus went out, and his disciples, into the villages of Caesarea Philippi; and on the way he was questioning his disciples, saying to them: Who do people say that I am?",
        },
        {
          greek:
            "οἱ δὲ εἶπαν αὐτῷ λέγοντες ὅτι Ἰωάννην τὸν βαπτιστήν, καὶ ἄλλοι Ἠλίαν, ἄλλοι δὲ ὅτι εἷς τῶν προφητῶν.",
          english:
            "And they told him, saying, 'John the Baptist; and others, Elijah; but others, one of the prophets.'",
        },
        {
          greek:
            "καὶ αὐτὸς ἐπηρώτα αὐτούς· Ὑμεῖς δὲ τίνα με λέγετε εἶναι; ἀποκριθεὶς ὁ Πέτρος λέγει αὐτῷ· Σὺ εἶ ὁ χριστός.",
          english:
            "And he was asking them: But you — who do you say that I am? Peter answered and said to him: You are the Christ.",
        },
      ],
    },
    quiz: [
      {
        prompt: "In Runge's framework, δέ primarily signals…",
        options: [
          "Strong contrast ('but')",
          "A new development or step in the discourse",
          "Explanation of what precedes",
          "A conclusion",
        ],
        answer: 1,
        explain:
          "δέ is a development marker. Contrast, when present, comes from the content, not from δέ itself.",
      },
      {
        prompt: "Why is ὑμεῖς written out in Ὑμεῖς δὲ τίνα με λέγετε εἶναι;",
        greek: "Ὑμεῖς δὲ τίνα με λέγετε εἶναι;",
        options: [
          "Greek requires the pronoun",
          "It is redundant and meaningless",
          "It is fronted for contrastive focus: 'YOU, as opposed to the crowds'",
          "It marks the accusative",
        ],
        answer: 2,
        explain:
          "The ending already gives 2nd plural, so the explicit fronted pronoun must be pragmatic — here contrastive.",
      },
      {
        prompt: "γάρ typically introduces material that is…",
        options: [
          "Mainline narrative events",
          "Backgrounded support or explanation for what precedes",
          "A correction of what precedes",
          "A new scene",
        ],
        answer: 1,
        explain: "γάρ constrains the reader to take the following as strengthening the prior claim.",
      },
    ],
  },
  {
    slug: "fluent-reading",
    trackId: "advanced",
    title: "Fluency Lab: Reading Whole Chapters",
    greekTitle: "Ἀνάγνωσις",
    summary:
      "Stop translating, start reading. Extensive reading protocol, audio-first practice, and full chapters of the Greek New Testament on film.",
    minutes: 60,
    kind: "immersion",
    objectives: [
      "Read a full NT chapter in Greek without an interlinear",
      "Use audio-first reading to break the translation habit",
      "Build a sustainable daily reading plan",
    ],
    videos: [
      {
        id: "DjoNWOwXVqM",
        kind: "video",
        title: "The Gospel of Mark in Koine Greek — LUMO Project, Chapter 1",
        channel: "KoineGreek.com (Benjamin Kantor)",
        note: "The whole Gospel filmed, dubbed in reconstructed Koine, with Greek captions. The single best immersion resource that exists.",
      },
      {
        id: "ht0NBqeRxB0",
        kind: "video",
        title: "Mark in Koine Greek — LUMO Project, Chapter 4",
        channel: "KoineGreek.com",
        note: "Parables chapter. Watch with captions, then again without.",
      },
      {
        id: "6hi_Prv3XxQ",
        kind: "video",
        title: "Mark in Koine Greek — LUMO Project, Chapter 5",
        channel: "KoineGreek.com",
        note: "Narrative-dense; excellent for aorist/imperfect alternation.",
      },
      {
        id: "PL92xKgmKTQBIZTse1Q-T9mj_AuXW9LlcV",
        kind: "playlist",
        title: "The New Testament in Greek, read by Maurice Robinson",
        channel: "Byzantine Text",
        note: "Complete audio NT in a scholarly reading. Ideal for listening while commuting.",
      },
      {
        id: "PLk3PwQOcbBq2U2r7xsulg8e2Lvs0_QFU5",
        kind: "playlist",
        title: "The Greek New Testament (Majority Text) — full audio",
        channel: "Anton Tasos Channel",
        note: "Modern Greek pronunciation, natural pace — closest to how a Greek speaker hears the text.",
      },
      {
        id: "6ZTUKBSmqGk",
        kind: "video",
        title: "Conversing in NT Koine Greek (introductions)",
        channel: "Beta with Brett",
        note: "Production practice — try answering out loud.",
      },
    ],
    listening: [
      { greek: "ἀναγινώσκω τὸ εὐαγγέλιον καθ᾽ ἡμέραν", gloss: "I read the gospel every day" },
      { greek: "οὐ μεταφράζω, ἀλλὰ ἀναγινώσκω", gloss: "I do not translate, but I read" },
      { greek: "πάλιν καὶ πάλιν", gloss: "again and again" },
      { greek: "μακάριοι οἱ πτωχοὶ τῷ πνεύματι", gloss: "blessed are the poor in spirit" },
      { greek: "ὁ ἔχων ὦτα ἀκουέτω", gloss: "let the one who has ears hear" },
    ],
    grammar: [
      {
        heading: "The extensive reading protocol",
        body: [
          "INTENSIVE reading (parse everything, consult lexicons) builds knowledge. EXTENSIVE reading (large amounts, fast, tolerating ambiguity) builds fluency. You need roughly 20% intensive, 80% extensive.",
          "Choose material where you know 95%+ of the words. That is 1 John, John's Gospel, Mark, then the Synoptics. Save Hebrews, Luke-Acts and 2 Peter for later.",
          "Read a chapter without stopping. Then re-read it. Only on the third pass look anything up.",
          "Never sub-vocalise in English. If you catch yourself translating, slow down and re-read the Greek aloud.",
        ],
        table: {
          caption: "A graded reading path through the New Testament",
          headers: ["Stage", "Books", "Why"],
          rows: [
            ["1", "1 John, 2 John, 3 John", "Tiny vocabulary, endless repetition, simple syntax"],
            ["2", "John's Gospel", "Same limited vocabulary over long narrative"],
            ["3", "Mark", "Simple, paratactic, fast-moving narrative"],
            ["4", "Matthew, Revelation", "Semitic-influenced but straightforward Greek"],
            ["5", "Galatians, 1 Thessalonians, Philippians", "Manageable Pauline argument"],
            ["6", "Romans, 1-2 Corinthians", "Dense theological argument"],
            ["7", "Luke-Acts, Hebrews, 1-2 Peter, Jude", "Literary, complex, rich vocabulary"],
          ],
        },
      },
      {
        heading: "Audio-first practice",
        body: [
          "1. LISTEN to the chapter twice with no text. Note what you catch.",
          "2. LISTEN while following the Greek text with your eye.",
          "3. READ ALOUD along with the recording, matching pace and phrasing.",
          "4. READ ALONE, aloud, at speaking speed.",
          "This is the single most effective exercise for turning a slow decoder into a reader. Twenty minutes a day for three months produces a visible change.",
        ],
        tip: "Where to get audio: KoineGreek.com (Kantor, restored Koine, free MP3s of the whole NT and much of the LXX), the Maurice Robinson Byzantine readings, and the Anton Tasos Majority Text recordings — all linked in the Media Library.",
      },
    ],
    vocabIds: ["euangelion", "anastasis", "mystērion", "koinwnia", "presbyteros", "splanchnizomai", "aiwnios", "dikaios"],
    reading: {
      ref: "1 John 1:1-4",
      intro:
        "The classic first chapter for extensive reading. Read all four verses aloud without stopping, twice.",
      verses: [
        {
          greek:
            "Ὃ ἦν ἀπ᾽ ἀρχῆς, ὃ ἀκηκόαμεν, ὃ ἑωράκαμεν τοῖς ὀφθαλμοῖς ἡμῶν, ὃ ἐθεασάμεθα καὶ αἱ χεῖρες ἡμῶν ἐψηλάφησαν, περὶ τοῦ λόγου τῆς ζωῆς—",
          english:
            "What was from the beginning, what we have heard, what we have seen with our eyes, what we looked at and our hands touched, concerning the word of life—",
        },
        {
          greek:
            "καὶ ἡ ζωὴ ἐφανερώθη, καὶ ἑωράκαμεν καὶ μαρτυροῦμεν καὶ ἀπαγγέλλομεν ὑμῖν τὴν ζωὴν τὴν αἰώνιον ἥτις ἦν πρὸς τὸν πατέρα καὶ ἐφανερώθη ἡμῖν—",
          english:
            "and the life was revealed, and we have seen and testify and announce to you the eternal life which was with the Father and was revealed to us—",
        },
        {
          greek:
            "ὃ ἑωράκαμεν καὶ ἀκηκόαμεν ἀπαγγέλλομεν καὶ ὑμῖν, ἵνα καὶ ὑμεῖς κοινωνίαν ἔχητε μεθ᾽ ἡμῶν. καὶ ἡ κοινωνία δὲ ἡ ἡμετέρα μετὰ τοῦ πατρὸς καὶ μετὰ τοῦ υἱοῦ αὐτοῦ Ἰησοῦ Χριστοῦ.",
          english:
            "what we have seen and heard we announce also to you, so that you too may have fellowship with us; and indeed our fellowship is with the Father and with his Son Jesus Christ.",
        },
        {
          greek: "καὶ ταῦτα γράφομεν ἡμεῖς ἵνα ἡ χαρὰ ἡμῶν ᾖ πεπληρωμένη.",
          english: "And we write these things so that our joy may be complete.",
        },
      ],
    },
    quiz: [
      {
        prompt: "Which book is the standard recommendation for a first extensive read?",
        options: ["Hebrews", "1 John", "Luke", "2 Peter"],
        answer: 1,
        explain:
          "1 John has a tiny vocabulary and simple, highly repetitive syntax — ideal for building reading momentum.",
      },
      {
        prompt: "What is the correct ratio of intensive to extensive reading for fluency?",
        options: ["100% intensive", "roughly 20% intensive / 80% extensive", "50/50", "100% extensive"],
        answer: 1,
        explain:
          "Detailed parsing builds knowledge, but volume builds fluency. Most students are heavily over-weighted toward intensive work.",
      },
      {
        prompt: "In the audio-first protocol, what is step 1?",
        options: [
          "Parse every verb",
          "Listen to the chapter twice with no text in front of you",
          "Translate into English",
          "Memorise the vocabulary",
        ],
        answer: 1,
        explain: "Ear before eye. It forces you to process Greek as language rather than as a code.",
      },
    ],
  },

  // ══════════════════════ SCHOLAR ══════════════════════
  {
    slug: "textual-criticism",
    trackId: "scholar",
    title: "New Testament Textual Criticism",
    greekTitle: "Κριτικὴ τοῦ κειμένου",
    summary:
      "Manuscripts, text-types, the critical apparatus of NA28/UBS5, and reasoned eclecticism in practice.",
    minutes: 60,
    kind: "seminar",
    objectives: [
      "Read a Nestle-Aland apparatus entry",
      "Apply internal and external criteria to a real variant",
      "Explain the major witnesses and their relative weight",
    ],
    videos: [
      {
        id: "Doi8JxJOtgE",
        kind: "video",
        title: "The Basics of New Testament Textual Criticism",
        channel: "Daniel Wallace / Houseform Apologetics",
        note: "The best single introduction from a leading practitioner.",
      },
      {
        id: "AC4uHecMjgY",
        kind: "video",
        title: "Introduction to New Testament Textual Criticism",
        channel: "Daniel B. Wallace",
        note: "Longer lecture format covering the manuscript evidence in detail.",
      },
      {
        id: "IrsXiij6Uag",
        kind: "video",
        title: "NT Textual Criticism, Session 1: Manuscripts",
        channel: "Mark Jennings / BiblicaleLearning",
        note: "A full seminary course opener on the physical evidence.",
      },
      {
        id: "WRHjZCKRIu4",
        kind: "video",
        title: "Ehrman vs. Wallace — Can We Trust the Text of the NT?",
        channel: "Debate",
        note: "Hear the strongest sceptical and confident cases argued against each other.",
      },
      {
        id: "hfUxfD9H5hc",
        kind: "video",
        title: "The Oxyrhynchus Papyri — Early Christian Manuscripts",
        channel: "Wrestling with God",
        note: "Where the papyri came from and why they changed everything.",
      },
    ],
    listening: [
      { greek: "μονογενὴς θεός / ὁ μονογενὴς υἱός", gloss: "only-begotten God / the only Son (John 1:18 variant)" },
      { greek: "ἐν Ἐφέσῳ", gloss: "in Ephesus (absent from P46, א*, B in Eph 1:1)" },
      { greek: "τὸ κατὰ Μᾶρκον εὐαγγέλιον", gloss: "the Gospel according to Mark" },
      { greek: "ἀντίγραφον", gloss: "a copy, transcript" },
      { greek: "γραφεύς", gloss: "a scribe" },
    ],
    grammar: [
      {
        heading: "The witnesses",
        body: [
          "PAPYRI (𝔓) — around 140, mostly Egyptian, the earliest evidence. 𝔓52 (John, c. 125), 𝔓46 (Paul, c. 200), 𝔓66 and 𝔓75 (John, c. 200).",
          "MAJUSCULES / uncials — c. 320 parchment codices in capitals. א (Sinaiticus, 4th c.), B (Vaticanus, 4th c.), A (Alexandrinus, 5th c.), D (Bezae, 5th c.), W (Washingtonianus).",
          "MINUSCULES — c. 2,900 cursive manuscripts from the 9th century on; mostly Byzantine, but family 1 and family 13 preserve early readings.",
          "LECTIONARIES (c. 2,500), plus versions (Latin, Syriac, Coptic) and patristic citations.",
        ],
        table: {
          caption: "Text-types and their character",
          headers: ["Text-type", "Chief witnesses", "Character"],
          rows: [
            ["Alexandrian", "𝔓75, 𝔓66, א, B, 33", "Shorter, harder readings; generally earliest and best"],
            ["Western", "D, Old Latin, Syriac", "Expansive, paraphrastic, especially in Acts"],
            ["Byzantine", "A (Gospels), majority of minuscules, K, Π", "Smooth, conflated, full; the base of the Textus Receptus"],
            ["Caesarean (disputed)", "Θ, f1, f13, 𝔓45", "Mixed; existence increasingly questioned"],
          ],
        },
      },
      {
        heading: "Reasoned eclecticism",
        body: [
          "EXTERNAL evidence — date, geographical distribution, and genealogical relationships of the witnesses. Manuscripts are weighed, not counted.",
          "INTERNAL evidence, transcriptional: lectio brevior potior (prefer the shorter reading); lectio difficilior potior (prefer the harder reading); prefer the reading that best explains the rise of the others.",
          "INTERNAL evidence, intrinsic: which reading best fits the author's style, vocabulary and theology, and the immediate context?",
          "The Coherence-Based Genealogical Method (CBGM), used for the Catholic Epistles and Acts in NA28, adds a computational layer that models textual flow between witnesses rather than assuming fixed text-types.",
        ],
        tip: "The apparatus grades: in the UBS text, {A} = certain, {B} = almost certain, {C} = difficult to decide, {D} = very high degree of doubt. Metzger's Textual Commentary explains the committee's reasoning case by case.",
      },
      {
        heading: "Three variants worth knowing cold",
        body: [
          "MARK 16:9-20 — absent from א and B, unknown to Eusebius and Jerome, with a different vocabulary and style. Almost certainly not original; note also the 'shorter ending'.",
          "JOHN 7:53–8:11 — the pericope adulterae. Absent from all early Greek witnesses, floats to different locations in the manuscripts that do have it. Likely an authentic oral tradition, not original to John.",
          "JOHN 1:18 — μονογενὴς θεός (𝔓66, 𝔓75, א, B) vs. ὁ μονογενὴς υἱός (A, C3, Byz). The Alexandrian reading is harder and better attested; it is also christologically weightier.",
          "1 JOHN 5:7-8 — the Comma Johanneum. In no Greek manuscript before the 14th century. Erasmus included it under pressure; it is not original.",
        ],
      },
    ],
    vocabIds: ["gpraphw", "logos", "hrema", "onoma", "hypostasis", "apolytrwsis"],
    reading: {
      ref: "John 1:18 (variant analysis)",
      intro: "Compare the two readings and argue for one using external and internal criteria.",
      verses: [
        {
          greek:
            "θεὸν οὐδεὶς ἑώρακεν πώποτε· μονογενὴς θεὸς ὁ ὢν εἰς τὸν κόλπον τοῦ πατρὸς ἐκεῖνος ἐξηγήσατο.",
          english:
            "No one has ever seen God; the only-begotten God, who is in the bosom of the Father, that one has made him known. (Alexandrian reading)",
        },
        {
          greek:
            "θεὸν οὐδεὶς ἑώρακεν πώποτε· ὁ μονογενὴς υἱὸς ὁ ὢν εἰς τὸν κόλπον τοῦ πατρὸς ἐκεῖνος ἐξηγήσατο.",
          english:
            "No one has ever seen God; the only-begotten Son, who is in the bosom of the Father, that one has made him known. (Byzantine reading)",
        },
      ],
    },
    quiz: [
      {
        prompt: "Which manuscripts are the two great 4th-century majuscules?",
        options: [
          "𝔓52 and 𝔓46",
          "א (Sinaiticus) and B (Vaticanus)",
          "D (Bezae) and W",
          "A (Alexandrinus) and Θ",
        ],
        answer: 1,
        explain: "Codex Sinaiticus and Codex Vaticanus are the pillars of the Alexandrian text.",
      },
      {
        prompt: "'Lectio difficilior potior' means…",
        options: [
          "Prefer the longer reading",
          "Prefer the reading in the most manuscripts",
          "Prefer the harder reading",
          "Prefer the Byzantine reading",
        ],
        answer: 2,
        explain:
          "Scribes smoothed difficulties; they rarely created them. The harder reading better explains the others.",
      },
      {
        prompt: "What is the CBGM?",
        options: [
          "A Byzantine manuscript family",
          "The Coherence-Based Genealogical Method, a computational model of textual flow used in NA28",
          "A lectionary system",
          "A palaeographic dating technique",
        ],
        answer: 1,
        explain:
          "Developed at Münster; applied to the Catholic Epistles and Acts, it partially supersedes fixed text-type reasoning.",
      },
      {
        prompt: "The Comma Johanneum (1 John 5:7-8) appears in Greek manuscripts…",
        options: [
          "From the 2nd century",
          "Not before the 14th century",
          "In all Alexandrian witnesses",
          "Only in papyri",
        ],
        answer: 1,
        explain:
          "It entered the Greek tradition very late, via the Latin, and reached print through Erasmus' third edition.",
      },
    ],
  },
  {
    slug: "septuagint",
    trackId: "scholar",
    title: "Septuagint Greek & Translation Technique",
    greekTitle: "Ἡ τῶν ἑβδομήκοντα",
    summary:
      "The Bible of the early church. Hebrew interference, translation technique, and why LXX vocabulary is the key to NT theology.",
    minutes: 55,
    kind: "seminar",
    objectives: [
      "Describe the origins and diversity of the Septuagint corpus",
      "Recognise Hebraisms and calques in translation Greek",
      "Trace an NT term back through its LXX usage",
    ],
    videos: [
      {
        id: "mOdIDAsmapQ",
        kind: "video",
        title: "The Septuagint is the most important Bible you've never heard of",
        channel: "Wes Huff",
        note: "An excellent, accessible orientation to the corpus and its importance.",
      },
      {
        id: "Snvb7qNhNCM",
        kind: "video",
        title: "Dr. Jean Maurais on the Relevance of the Septuagint",
        channel: "TWU Wevers Institute for Septuagint Studies",
        note: "Current academic Septuagint studies from a leading research centre.",
      },
      {
        id: "WnmkVgi4fXA",
        kind: "video",
        title: "Reading the Septuagint and Greek NT in a Year",
        channel: "Biblingo (with Matthew Thomas)",
        note: "Practical strategy for adding LXX reading to your routine.",
      },
      {
        id: "PLk3PwQOcbBq2oyQnxXx3XvWUnPQFKdmVe",
        kind: "playlist",
        title: "The Psalms in Greek — full audio",
        channel: "Anton Tasos Channel",
        note: "The LXX Psalter read aloud. Ideal daily listening.",
      },
    ],
    listening: [
      { greek: "ἐν ἀρχῇ ἐποίησεν ὁ θεὸς τὸν οὐρανὸν καὶ τὴν γῆν", gloss: "In the beginning God made the heaven and the earth (Gen 1:1 LXX)" },
      { greek: "κύριος ποιμαίνει με καὶ οὐδέν με ὑστερήσει", gloss: "The Lord shepherds me and I shall lack nothing (Ps 22:1 LXX)" },
      { greek: "ἰδοὺ ἡ παρθένος ἐν γαστρὶ ἕξει", gloss: "Behold, the virgin shall conceive (Isa 7:14 LXX)" },
      { greek: "καὶ ἐγένετο", gloss: "and it came to pass (καί + ἐγένετο = Hebrew wayehi)" },
    ],
    grammar: [
      {
        heading: "What the Septuagint is (and is not)",
        body: [
          "Not one book and not one translation. The Pentateuch was rendered in Alexandria c. 250 BC; the other books followed over two centuries with wildly varying technique.",
          "The Letter of Aristeas gives the legend of seventy-two translators; the historical kernel is Ptolemaic royal patronage of a Greek Torah for the Alexandrian Jewish community.",
          "Later revisions bring the Greek closer to a proto-Masoretic Hebrew: kaige-Theodotion, Aquila (hyper-literal), Symmachus (idiomatic). Origen's Hexapla arranged these in six columns.",
          "Text-critically, the LXX sometimes preserves an older Hebrew Vorlage than the MT — dramatically so in Jeremiah, which is about one-eighth shorter in Greek.",
        ],
      },
      {
        heading: "Translation Greek: reading through the Hebrew",
        body: [
          "Translators often mirrored Hebrew syntax word for word, producing Greek that is grammatical but unidiomatic.",
          "καὶ ἐγένετο + finite verb renders wayehi. It is not natural Greek; Luke imitates it deliberately to sound scriptural.",
          "ἐν χειρί ('by the hand of') for beyad; πρόσωπον ('face') for panim in prepositional phrases; ἀνθρωπος ἀνθρωπος for the Hebrew distributive 'each man'.",
          "Cognate dative for the Hebrew infinitive absolute: θανάτῳ ἀποθανεῖσθε, 'you shall surely die' (lit. 'by death you shall die').",
          "ἰδού renders hinneh far more often than natural Greek would use it.",
        ],
        tip: "This is why NT Greek sometimes 'feels' Semitic. Much of it is not Aramaic interference but Septuagintal register — deliberate biblical style.",
      },
      {
        heading: "Vocabulary bridges",
        body: [
          "The LXX is the semantic bridge between Hebrew theology and Greek words. NT authors inherited a ready-made theological lexicon.",
        ],
        table: {
          caption: "Key LXX renderings that shape the New Testament",
          headers: ["Greek", "Hebrew", "Significance"],
          rows: [
            ["κύριος", "יהוה / אדני", "Applying κύριος to Jesus invokes the divine name"],
            ["διαθήκη", "בְּרִית", "'Covenant', not the ordinary Greek 'will/testament'"],
            ["δικαιοσύνη", "צְדָקָה", "Relational covenant faithfulness, not just Greek 'justice'"],
            ["ἱλαστήριον", "כַּפֹּרֶת", "The mercy seat — decisive for Romans 3:25"],
            ["δόξα", "כָּבוֹד", "Weighty divine presence, not Greek 'opinion/reputation'"],
            ["ἐκκλησία", "קָהָל", "The assembly of Israel, hence 'church'"],
            ["σάρξ", "בָּשָׂר", "Embodied creaturely humanity"],
            ["ἁμαρτία", "חַטָּאת", "Both 'sin' and 'sin-offering' — cf. 2 Cor 5:21"],
          ],
        },
        tip: "Working tools: Rahlfs-Hanhart, Septuaginta (the standard hand edition); the Göttingen critical editions; NETS (English translation); Muraoka's Greek-English Lexicon of the Septuagint.",
      },
    ],
    vocabIds: ["kyrios", "diatheke", "dikaiosyne", "hilasterion", "doxa", "ekklesia", "sarx", "hamartia", "nomos"],
    reading: {
      ref: "Psalm 22(23):1-4 LXX",
      intro:
        "Read the Greek Psalter. Note ποιμαίνει for 'is my shepherd' and the Hebraic parataxis throughout.",
      verses: [
        {
          greek: "Κύριος ποιμαίνει με, καὶ οὐδέν με ὑστερήσει.",
          english: "The Lord shepherds me, and I shall lack nothing.",
        },
        {
          greek: "εἰς τόπον χλόης, ἐκεῖ με κατεσκήνωσεν, ἐπὶ ὕδατος ἀναπαύσεως ἐξέθρεψέν με,",
          english: "In a verdant place, there he encamped me; by water of rest he reared me;",
        },
        {
          greek: "τὴν ψυχήν μου ἐπέστρεψεν. ὡδήγησέν με ἐπὶ τρίβους δικαιοσύνης ἕνεκεν τοῦ ὀνόματος αὐτοῦ.",
          english:
            "he restored my soul. He led me on paths of righteousness for the sake of his name.",
        },
        {
          greek:
            "ἐὰν γὰρ καὶ πορευθῶ ἐν μέσῳ σκιᾶς θανάτου, οὐ φοβηθήσομαι κακά, ὅτι σὺ μετ᾽ ἐμοῦ εἶ·",
          english:
            "For even if I walk in the midst of the shadow of death, I will not fear evils, because you are with me.",
        },
      ],
    },
    quiz: [
      {
        prompt: "Which Hebrew word does κύριος most often render in the LXX?",
        options: ["elohim", "the Tetragrammaton YHWH", "adam", "ruach"],
        answer: 1,
        explain:
          "This is why NT confessions of Jesus as κύριος carry such force — the divine name stands behind the word.",
      },
      {
        prompt: "καὶ ἐγένετο followed by a finite verb is…",
        options: [
          "Elegant Attic Greek",
          "A Hebraism rendering wayehi, imitated by Luke for scriptural style",
          "A scribal error",
          "A Latinism",
        ],
        answer: 1,
        explain: "Translation Greek preserved the Hebrew narrative formula; Luke adopts it deliberately.",
      },
      {
        prompt: "Which LXX book is substantially shorter than the Masoretic Text?",
        options: ["Genesis", "Isaiah", "Jeremiah", "Psalms"],
        answer: 2,
        explain:
          "LXX Jeremiah is about one-eighth shorter and differently arranged, and Qumran evidence supports a shorter Hebrew Vorlage.",
      },
      {
        prompt: "ἱλαστήριον in the LXX translates…",
        options: ["the altar", "the mercy seat (kapporet)", "the tabernacle", "the sacrifice"],
        answer: 1,
        explain: "This LXX background drives the interpretation of Romans 3:25.",
      },
    ],
  },
  {
    slug: "papyri-register",
    trackId: "scholar",
    title: "Documentary Papyri, Register & Historical Linguistics",
    greekTitle: "Πάπυροι",
    summary:
      "Deissmann's revolution, the sociolinguistics of Koine, epigraphy, and how spelling errors reconstruct pronunciation.",
    minutes: 50,
    kind: "seminar",
    objectives: [
      "Explain how documentary papyri reshaped NT lexicography",
      "Distinguish literary, documentary and sub-literary registers",
      "Use orthographic variation as phonological evidence",
    ],
    videos: [
      {
        id: "hfUxfD9H5hc",
        kind: "video",
        title: "The Oxyrhynchus Papyri",
        channel: "Wrestling with God",
        note: "The rubbish heaps of Oxyrhynchus and what came out of them.",
      },
      {
        id: "tJrGaOF-bOw",
        kind: "video",
        title: "First Greek lesson with Prof. Christophe Rico (Polis Institute)",
        channel: "poliskoine",
        note: "How a research institute teaches Koine as a living spoken language.",
      },
      {
        id: "OlA5EtpGiM4",
        kind: "video",
        title: "Greek Verbal Aspect and Discourse Analysis in NT Exegesis",
        channel: "Jonathan Wolters",
        note: "Method at the intersection of linguistics and exegesis.",
      },
      {
        id: "94B26pJM2fg",
        kind: "video",
        title: "The Greek Alphabet in Koine-Era Pronunciation",
        channel: "Tim McNinch",
        note: "Revisit with scholarly ears: every claim here rests on papyrological evidence.",
      },
    ],
    listening: [
      { greek: "ἐρρῶσθαί σε εὔχομαι", gloss: "I pray that you are well (standard papyrus letter closing)" },
      { greek: "χαίρειν", gloss: "greetings (letter opening infinitive)" },
      { greek: "πρὸ μὲν πάντων εὔχομαί σε ὑγιαίνειν", gloss: "before all things I pray you are in health" },
      { greek: "ἀσπάζομαι τοὺς φιλοῦντας ἡμᾶς", gloss: "I greet those who love us" },
    ],
    grammar: [
      {
        heading: "Deissmann's revolution",
        body: [
          "Before 1895 scholars widely believed NT Greek was a unique 'Holy Ghost language' — neither Classical nor Modern.",
          "Adolf Deissmann, reading newly published Egyptian papyri, found NT 'biblical' words all over tax receipts, private letters, contracts and magical texts.",
          "Words once thought uniquely Christian turned out to be ordinary: ἀγάπη, ἀρραβών (deposit/down payment), λειτουργία (public service), πρεσβύτερος (village elder), παρουσία (royal visit).",
          "Consequence: the New Testament is written in the living vernacular of the eastern Mediterranean. Moulton and Milligan's Vocabulary of the Greek Testament systematised the evidence.",
        ],
        tip: "παρουσία in the papyri denotes the formal arrival of a king or governor, complete with delegations and a new coin issue. That is the image behind 1 Thessalonians 4.",
      },
      {
        heading: "Register: not all Koine is the same",
        body: [
          "LITERARY / Atticising — Josephus, Philo, Plutarch, Hebrews, and Luke's preface (Luke 1:1-4) with its periodic sentence.",
          "STANDARD Koine — most of the NT, Epictetus, the LXX Pentateuch.",
          "SUB-LITERARY / vernacular — private letters, receipts, Revelation's solecisms, Mark's parataxis.",
          "The register shifts even within a single book: Luke 1:1-4 is polished Greek, Luke 1:5ff. immediately drops into Septuagintal style. The change is a deliberate literary signal.",
        ],
        table: {
          caption: "Register markers",
          headers: ["Feature", "Higher register", "Lower register"],
          rows: [
            ["Sentence structure", "Hypotaxis, periodic", "Parataxis with καί"],
            ["Optative mood", "Present (esp. Luke, Paul's μὴ γένοιτο)", "Absent"],
            ["Vocabulary", "Attic revivals, rare compounds", "Diminutives, everyday terms"],
            ["Particles", "μέν … δέ, τε, γε", "καί, δέ only"],
            ["Genitive absolute", "Frequent and varied", "Rare"],
          ],
        },
      },
      {
        heading: "Spelling mistakes as evidence",
        body: [
          "Phonological reconstruction of Koine rests on itacistic confusion in non-literary documents. If a scribe writes ὑμεῖς for ἡμεῖς, those forms sounded alike to him.",
          "By the 1st century AD, η, ι, ει, and often υ and οι had merged or were merging toward /i/ — itacism.",
          "αι had monophthongised to /e/, merging with ε; hence the endless -εται/-ετε confusion in manuscripts.",
          "β, δ, γ had begun to spirantise toward /v/, /ð/, /ɣ/.",
          "Benjamin Kantor's The Pronunciation of New Testament Greek (2023) assembles this evidence systematically, drawing also on transcriptions into Hebrew, Latin and Coptic.",
        ],
        tip: "This is why ἡμεῖς/ὑμεῖς variants are so common in the apparatus — and why the pronunciation debate is a text-critical question, not just a pedagogical one.",
      },
    ],
    vocabIds: ["parousia", "koinwnia", "presbyteros", "epiousios", "mystērion", "kenow", "hypostasis", "plerwma"],
    reading: {
      ref: "Luke 1:1-4 (register analysis)",
      intro:
        "The most self-consciously literary sentence in the New Testament: a single Greek period with hypotaxis, an optative-free but carefully balanced structure, and classicising vocabulary.",
      verses: [
        {
          greek:
            "Ἐπειδήπερ πολλοὶ ἐπεχείρησαν ἀνατάξασθαι διήγησιν περὶ τῶν πεπληροφορημένων ἐν ἡμῖν πραγμάτων,",
          english:
            "Inasmuch as many have undertaken to compile a narrative of the things fulfilled among us,",
        },
        {
          greek:
            "καθὼς παρέδοσαν ἡμῖν οἱ ἀπ᾽ ἀρχῆς αὐτόπται καὶ ὑπηρέται γενόμενοι τοῦ λόγου,",
          english:
            "just as those who from the beginning were eyewitnesses and servants of the word delivered them to us,",
        },
        {
          greek:
            "ἔδοξε κἀμοὶ παρηκολουθηκότι ἄνωθεν πᾶσιν ἀκριβῶς καθεξῆς σοι γράψαι, κράτιστε Θεόφιλε,",
          english:
            "it seemed good to me also, having followed all things closely from the beginning, to write to you in an orderly sequence, most excellent Theophilus,",
        },
        {
          greek: "ἵνα ἐπιγνῷς περὶ ὧν κατηχήθης λόγων τὴν ἀσφάλειαν.",
          english:
            "so that you may know the certainty concerning the things about which you have been instructed.",
        },
      ],
    },
    quiz: [
      {
        prompt: "What did Deissmann demonstrate?",
        options: [
          "That NT Greek is a unique sacred dialect",
          "That NT vocabulary is largely the ordinary Greek of the documentary papyri",
          "That the NT was originally written in Aramaic",
          "That the LXX is a late forgery",
        ],
        answer: 1,
        explain:
          "Light from the Ancient East (1908) placed NT Greek firmly in the everyday Hellenistic world.",
      },
      {
        prompt: "'Itacism' refers to…",
        options: [
          "The loss of the dual number",
          "The merger of several vowels and diphthongs toward the /i/ sound",
          "The use of Latin loanwords",
          "A style of uncial handwriting",
        ],
        answer: 1,
        explain:
          "η, ι, ει, υ, οι converge on /i/ — which produces the ἡμεῖς/ὑμεῖς confusion throughout the manuscript tradition.",
      },
      {
        prompt: "In the papyri, παρουσία most characteristically denotes…",
        options: [
          "A funeral",
          "The official visit or arrival of a king or high official",
          "A marketplace",
          "A legal contract",
        ],
        answer: 1,
        explain:
          "The royal-visitation background illuminates the NT use of παρουσία for Christ's coming.",
      },
      {
        prompt: "Luke 1:1-4 differs from Luke 1:5ff. in that it is…",
        options: [
          "Written in Aramaic",
          "A single literary period in a high classicising register, before shifting to Septuagintal style",
          "In the optative mood throughout",
          "A quotation from the LXX",
        ],
        answer: 1,
        explain:
          "The deliberate register shift signals Luke's historiographical credentials, then his biblical subject matter.",
      },
    ],
  },
  {
    slug: "research-toolkit",
    trackId: "scholar",
    title: "The Research Toolkit & Writing Greek Exegesis",
    greekTitle: "Ἐξήγησις",
    summary:
      "Lexicons, grammars, databases and method: how to move from a Greek text to a defensible exegetical argument.",
    minutes: 50,
    kind: "seminar",
    objectives: [
      "Use BDAG, LSJ, TDNT and Muraoka appropriately and critically",
      "Execute a full exegetical workflow on a passage",
      "Avoid the standard word-study fallacies",
    ],
    videos: [
      {
        id: "Z_KrA5bRmL0",
        kind: "video",
        title: "Which Greek grammar should I get?",
        channel: "Biblical Mastery Academy",
        note: "An honest map of the grammar landscape from beginner to reference level.",
      },
      {
        id: "T3UEMC7V1qE",
        kind: "video",
        title: "Should you be using Wallace's Greek Grammar Beyond the Basics?",
        channel: "Biblical Mastery Academy",
        note: "How to use a syntax reference without over-labelling.",
      },
      {
        id: "7okFjIeaMmk",
        kind: "video",
        title: "Discourse Features of the Bible — a conversation with Steve Runge",
        channel: "Logos Bible Coach",
        note: "How discourse tools fit into the research workflow.",
      },
      {
        id: "OERYu4UWXms",
        kind: "video",
        title: "Verbal Aspect Theory & Interpreting the Bible",
        channel: "Theology in the Raw (Constantine Campbell)",
        note: "Scholarship translated into interpretive practice.",
      },
    ],
    listening: [
      { greek: "ἐξηγήσατο", gloss: "he expounded / made known — the root of 'exegesis'" },
      { greek: "ὀρθοτομοῦντα τὸν λόγον τῆς ἀληθείας", gloss: "rightly handling the word of truth" },
      { greek: "ἐρευνᾶτε τὰς γραφάς", gloss: "search the Scriptures" },
      { greek: "τί λέγει ἡ γραφή;", gloss: "What does the Scripture say?" },
    ],
    grammar: [
      {
        heading: "The reference shelf",
        body: [
          "LEXICONS — BDAG (Bauer-Danker) is the standard for the NT and early Christian literature. LSJ covers all of ancient Greek and is essential for classical usage. Muraoka is the best LXX lexicon. Louw-Nida organises by semantic domain, which is invaluable for synonym work.",
          "GRAMMARS — Wallace, Greek Grammar Beyond the Basics (syntax taxonomy); BDF (Blass-Debrunner-Funk, comparative and historical); Robertson's monumental 1914 Grammar; Runge (discourse); Porter, Idioms; Moulton-Howard-Turner.",
          "DATABASES — the morphologically tagged SBLGNT and NA28, Perseus, the Duke Databank of Documentary Papyri (papyri.info), the Thesaurus Linguae Graecae, and Logos/Accordance for syntax searching.",
          "TEXTS — NA28/UBS5, the SBLGNT (free and openly licensed), THGNT (Tyndale House), Rahlfs-Hanhart for the LXX.",
        ],
        tip: "TDNT (Kittel) is a magnificent but dangerous resource. Barr's Semantics of Biblical Language (1961) dismantled its habit of reading theology into etymology. Use it for history of ideas, not for lexical semantics.",
      },
      {
        heading: "Word-study fallacies to avoid",
        body: [
          "ROOT FALLACY — assuming a word's meaning is built from its parts. ἐκκλησία does not mean 'the called-out ones'; it means 'assembly'.",
          "SEMANTIC ANACHRONISM — reading a later meaning back. δύναμις does not mean 'dynamite'.",
          "ILLEGITIMATE TOTALITY TRANSFER — importing every possible sense of a word into a single occurrence.",
          "SELECTIVE EVIDENCE — citing only the usages that support your reading.",
          "APPEAL TO UNKNOWN OR UNLIKELY MEANINGS — reviving a sense attested once in Homer for a first-century text.",
          "See D. A. Carson, Exegetical Fallacies, and Moisés Silva, Biblical Words and Their Meaning.",
        ],
      },
      {
        heading: "An exegetical workflow that works",
        body: [
          "1. TEXT — establish the text. Check the apparatus; note and evaluate significant variants.",
          "2. TRANSLATE — make your own wooden translation before consulting any English version.",
          "3. STRUCTURE — diagram or block-outline the passage. Identify the main clause and everything subordinate to it.",
          "4. GRAMMAR — resolve syntactic ambiguities: cases, participles, infinitives, conjunctions. Label only what matters.",
          "5. DISCOURSE — locate the passage in its paragraph and its argument. Track connectives, participant reference, prominence.",
          "6. LEXIS — do focused word studies on genuinely disputed terms, prioritising the same author, then the NT, then the LXX, then contemporary Koine.",
          "7. CONTEXT — historical, cultural, literary and canonical setting.",
          "8. SYNTHESIS — state the author's point in one sentence. If you cannot, you are not finished.",
          "9. DIALOGUE — only now read the commentaries, and note where and why you differ.",
        ],
        tip: "Write your provisional conclusion at step 8 BEFORE opening a commentary. Otherwise you will merely reproduce someone else's exegesis with Greek decoration.",
      },
    ],
    vocabIds: ["logos", "hrema", "gpraphw", "gnwskw", "dikaiosyne", "hypostasis", "plerwma", "mystērion", "epiousios"],
    reading: {
      ref: "Philippians 2:5-8",
      intro:
        "The hardest short passage in the NT. Run the full workflow: text, structure, ἁρπαγμόν, ἐκένωσεν, the participles, μορφή vs. σχῆμα.",
      verses: [
        {
          greek: "τοῦτο φρονεῖτε ἐν ὑμῖν ὃ καὶ ἐν Χριστῷ Ἰησοῦ,",
          english: "Have this mind among yourselves, which is also in Christ Jesus,",
        },
        {
          greek:
            "ὃς ἐν μορφῇ θεοῦ ὑπάρχων οὐχ ἁρπαγμὸν ἡγήσατο τὸ εἶναι ἴσα θεῷ,",
          english:
            "who, existing in the form of God, did not consider equality with God something to be exploited,",
        },
        {
          greek:
            "ἀλλὰ ἑαυτὸν ἐκένωσεν μορφὴν δούλου λαβών, ἐν ὁμοιώματι ἀνθρώπων γενόμενος· καὶ σχήματι εὑρεθεὶς ὡς ἄνθρωπος",
          english:
            "but emptied himself, taking the form of a slave, coming to be in the likeness of humanity; and being found in appearance as a human being,",
        },
        {
          greek:
            "ἐταπείνωσεν ἑαυτὸν γενόμενος ὑπήκοος μέχρι θανάτου, θανάτου δὲ σταυροῦ.",
          english:
            "he humbled himself, becoming obedient to the point of death — even death on a cross.",
        },
      ],
    },
    quiz: [
      {
        prompt: "Which lexicon is the standard for New Testament Greek?",
        options: ["LSJ", "BDAG", "Muraoka", "TDNT"],
        answer: 1,
        explain:
          "BDAG is the NT standard; LSJ covers all ancient Greek; Muraoka is for the LXX; TDNT is a theological dictionary, not a lexicon.",
      },
      {
        prompt: "Claiming ἐκκλησία means 'the called-out ones' commits which fallacy?",
        options: [
          "Semantic anachronism",
          "The root/etymological fallacy",
          "Illegitimate totality transfer",
          "Selective evidence",
        ],
        answer: 1,
        explain:
          "Meaning is determined by usage, not by morphological components. In Koine, ἐκκλησία is simply 'assembly'.",
      },
      {
        prompt: "At which step should you first consult commentaries?",
        options: ["Step 1, to orient yourself", "Immediately after translating", "Last, after forming your own synthesis", "Never"],
        answer: 2,
        explain:
          "Commentaries are dialogue partners, not starting points. Form your own reading first, then test it.",
      },
      {
        prompt: "Which work most decisively critiqued TDNT's method?",
        options: [
          "Wallace, Greek Grammar Beyond the Basics",
          "Barr, The Semantics of Biblical Language",
          "Metzger, Textual Commentary",
          "Runge, Discourse Grammar",
        ],
        answer: 1,
        explain:
          "James Barr's 1961 critique of 'illegitimate totality transfer' and etymologising reshaped biblical lexical semantics.",
      },
    ],
  },
];

export const LESSONS_BY_SLUG: Record<string, Lesson> = Object.fromEntries(
  LESSONS.map((lesson) => [lesson.slug, lesson]),
);

export function lessonsForTrack(trackId: TrackId): Lesson[] {
  return LESSONS.filter((lesson) => lesson.trackId === trackId);
}

export function lessonIndex(slug: string): number {
  return LESSONS.findIndex((lesson) => lesson.slug === slug);
}
