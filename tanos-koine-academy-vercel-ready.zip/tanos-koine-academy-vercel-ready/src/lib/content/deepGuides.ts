export type DeepExample = {
  greek: string;
  translit?: string;
  literal: string;
  natural: string;
  breakdown: string;
};

export type EnglishVsGreek = {
  english: string;
  greek: string;
  whyItMatters: string;
};

export type DeepSection = {
  id: string;
  title: string;
  subtitle?: string;
  body: string[];
  englishVsGreek?: EnglishVsGreek[];
  examples?: DeepExample[];
  thinkLikeGreek?: string[];
  commonPitfalls?: string[];
  memoryTrick?: string;
};

export type DeepGuide = {
  slug: string;
  intro: string;
  sections: DeepSection[];
};

export const DEEP_GUIDES: Record<string, DeepGuide> = {
  "why-greek": {
    slug: "why-greek",
    intro:
      "Before we write a single letter, you need to feel why learning Koine is like reclaiming a room in your own house. The New Testament was not translated into Greek — it was composed in it.",
    sections: [
      {
        id: "house",
        title: "English is already half-Greek — you just don't know it",
        subtitle: "Your mental lexicon is a Greek warehouse",
        body: [
          "Say out loud: theology, philosophy, psychology, biography, photograph, telephone, microscope. Every one of those is Greek, literally glued together from Greek words you are about to learn: θεός 'God', λόγος 'word/reason', φιλέω 'I love', ψυχή 'soul', βίος 'life', γράφω 'I write', φῶς 'light', τῆλε 'far', μικρός 'small', σκοπέω 'I look'.",
          "In English we treat these as long intimidating words. In Greek they are little Lego sentences. When you learn θεός and λόγος you are not memorizing 'theology' — you are finally understanding a word you already own. This is the central psychological trick: you are not learning a foreign language, you are excavating the basement of your own.",
          "Koine is not Classical Attic with extra incense. It is the Greek that a fish-seller in Ephesus used to argue about the price of tuna, the Greek a mother used to write to her son stationed in Syria, the Greek of divorce certificates, tax receipts and love letters. The papyri prove it. The apostles wrote like everyone else, because they wanted everyone else to understand.",
        ],
        englishVsGreek: [
          {
            english: "We say 'Theology is hard'",
            greek: "ἡ θεολογία ἐστὶν χαλεπή",
            whyItMatters:
              "Exactly the same structure: subject + 'is' + adjective. Greek feels strange only until you notice the cognate θεολογία sitting in your English sentence.",
          },
          {
            english: "'Bible' is a Greek word",
            greek: "τὰ βιβλία = the books (plural of βιβλίον, a papyrus roll)",
            whyItMatters:
              "Even the word 'Bible' is not translated; it IS Greek. You are already inside the language.",
          },
        ],
        examples: [
          {
            greek: "θεὸς ἀγάπη ἐστίν",
            literal: "God love is",
            natural: "God is love",
            breakdown:
              "Word-for-word matches 1 John 4:8. No extra grammar. εἰμί 'to be' behaves exactly like English 'is'. This is your first complete theological sentence in the original.",
          },
        ],
        thinkLikeGreek: [
          "Next time you see -logy in English, stop and decode: zoo-logy = λόγος about ζῷον 'animal'. Make it a game for one day.",
          "Write your name in Greek letters using the chart, even if the spelling is imperfect. Motor memory beats visual memory.",
        ],
        memoryTrick: "Koine = κοινή = 'common'. The koinē is the coin everyone shares. If English is the global koinē today, Greek was the koinē of Jesus' world.",
      },
      {
        id: "pronunciation",
        title: "How to pick a pronunciation and not go crazy",
        body: [
          "There are three accents in the room. Erasmian is a classroom tool: it artificially keeps η as 'ay' and ει as 'ei' so you can hear how a word is spelled. No one in antiquity ever spoke it, but most seminaries teach it because dictation is easier. Restored Koine (Buth/Kantor) is the best reconstruction of how a Jew in first-century Jerusalem actually sounded: η = ee, β = v, οι = ü → ee. Modern Greek is what living Greeks speak — extremely close to late Koine, and you instantly get millions of conversation partners.",
          "Beginners obsess about this. Don't. Children do not choose a perfect accent before they start speaking. Pick one system (this course's recorded audio uses a Koine/Modern voice, close to Kantor) and stay consistent for a year. Your brain needs a single auditory image for each word. Switch later if you want — it's 20 hours to rewire pronunciation once you know the language.",
          "English comparison: imagine you learn English in Texas but later study in Scotland. You still understand everything; you just adjust the vowels. Greek pronunciation is less variable than English is today.",
        ],
        englishVsGreek: [
          {
            english: "We understand 'water' whether you say WAH-tuh (New York), WOH-duh (London), or WOAH-ter (Texas)",
            greek: "ὕδωρ is understood whether you say HY-dor (Erasmian), EE-dōr (Restored), or EE-thor (Modern)",
            whyItMatters:
              "Comprehension tolerates accent variation. Consistency matters more than historical perfection.",
          },
        ],
        thinkLikeGreek: [
          "Choose today: write on a sticky note 'My Greek sounds like ______'. Stick it on your monitor. Decision fatigue is the real enemy.",
        ],
      },
      {
        id: "loop",
        title: "The 20-minute loop that builds a language in your head",
        body: [
          "You did not learn English by memorizing grammar tables. You learned it by hearing something just beyond what you already knew, guessing, being corrected, and hearing it again. Linguists call this i+1 — input that is 80-90% known, 10-20% new.",
          "Every lesson here follows that loop: Watch a 10-minute video (new concept), Listen to 6 drilled sentences (ear training), Read one real verse aloud (application), Drill 8 flashcards (retention). That's it. If you do that daily, in 90 days you will be reading 1 John without a lexicon.",
          "English parallel: you don't learn to play piano by reading about the piano. You learn by 20 minutes of scales plus one real song every day. Greek is a motor skill too — tongue, throat, eye-tracking.",
        ],
        thinkLikeGreek: [
          "Set a phone timer for 20 minutes. When it rings, stop even if you are mid-lesson. Leaving the brain wanting more creates overnight consolidation.",
        ],
        commonPitfalls: [
          "Bingeing 3 hours on Saturday and skipping the week. Spaced repetition needs sleep between sessions.",
          "Writing English translations under every Greek word. That builds a translation habit, not a reading habit. Use the interlinear tap, then cover it.",
        ],
      },
    ],
  },
  alphabet: {
    slug: "alphabet",
    intro:
      "Twenty-four letters. You learned 26 for English as a toddler. You can do this in an afternoon if you treat it like a sound-system, not a code-system.",
    sections: [
      {
        id: "vowel-core",
        title: "Vowels first: the 7 singing sounds",
        body: [
          "English has 5 vowel letters for about 15 vowel sounds (think a in cat, father, cake, about). Greek is blessedly honest: 7 vowel symbols for 7 sounds, almost always pronounced the same way.",
          "α ε η ι ο υ ω. Two are always short: ε like met, ο like not. Two are always long: η like meet (in Koine), ω like tone. Three swing both ways: α ι υ can be short or long depending on the word — just like English 'a' in cat vs father.",
          "Say them: ah, eh, ee, ee, oh, ü (like French tu, later ee), oh-long. That's 80% of reading aloud.",
          "English cheat: The alphabet song in English is ABCDEFG. In Greek it is α β γ δ ε ζ η θ... Sing it three times to the same tune. Your muscle memory doesn't care which language it is.",
        ],
        englishVsGreek: [
          {
            english: "a in father (α), e in met (ε), ee in see (η/ι), o in not (ο), o in tone (ω)",
            greek: "Every Greek vowel has one home. No silent e, no 'ough' with 8 pronunciations.",
            whyItMatters: "Once you learn a vowel, you have learned it forever. English vowel chaos does not exist here.",
          },
        ],
        examples: [
          { greek: "ἀγάπη", translit: "agapē", literal: "a-ga-pē", natural: "love", breakdown: "α = ah, γ = g (ng before second γ), ά = stress, π = p, η = ay→ee. Three syllables: ah-GAH-pay." },
          { greek: "Ἰησοῦς", translit: "Iēsous", literal: "Yay-soos", natural: "Jesus/Joshua", breakdown: "Ἰ = Yee, η = ee, σοῦ = soos with circumflex length. This is why Spanish spells it Jesús — same sounds." },
        ],
        thinkLikeGreek: [
          "Write your English name in Greek letters, sounding it out: e.g., Peter = Πέτρος. Add -ος if masculine.",
          "Label 5 objects in your room with sticky notes in Greek: door = θύρα, window = παράθυρον (θ = th, very satisfying).",
        ],
        memoryTrick: "Alpha looks like A, Eta looks like H but it's a vowel, Rho looks like P but is R — the three impostors. Write them in red.",
      },
      {
        id: "consonant-friends",
        title: "Consonants: most are already your friends",
        body: [
          "κ τ π ν μ λ σ — these are exactly English k t p n m l s. Zero work. β is trickier: in Erasmian it's b, in Koine it's v (vine). Greek kids learn it as v; English textbooks pretend it's b for spelling clarity. Both are fine if you are consistent.",
          "The magic rule: γ before γ, κ, χ, ξ becomes 'ng'. So ἄγγελος is not ag-gelos but ANG-gelos — exactly how we say 'angel' in English. You already know this rule; English stole it from Greek.",
          "θ, φ, χ: In English we have th (thing), ph (phone), ch (Bach). Greek invented them. Ἀρχή → archeology, φῶς → photograph, θεός → theology. You already pronounce these daily.",
          "Final sigma: σ inside a word, ς at the end. Same as English: we have different shapes for lowercase and uppercase; Greek just adds one more variant. Ἰησοῦς shows both σ and ς in one paradigm.",
        ],
        englishVsGreek: [
          {
            english: "sing (ng) = γγ, angel (ng) = γγ",
            greek: "ἄγγελος = ANG-gelos",
            whyItMatters: "This is not a new rule; it's the rule that explains why 'angel' is pronounced ANGEL not AGGEL.",
          },
          {
            english: "photograph = φῶς (light) + γραφή (writing)",
            greek: "φῶς = light, γράφω = I write",
            whyItMatters: "Deconstruct English to learn Greek vocabulary, not the reverse.",
          },
        ],
        thinkLikeGreek: ["Read a restaurant menu: gyros = γύρος (circle, because the meat rotates), pita = πίτα. You're already reading Greek."],
        commonPitfalls: ["Confusing ν (nu) with v. ν = n. The v-sound is β or (in Erasmian) sometimes not.", "Confusing ρ (rho) with p. ρ = r, tapped like Spanish single r."],
      },
      {
        id: "diphthongs",
        title: "Two vowels, one mouthful: diphthongs",
        body: [
          "A diphthong is two vowels that slide together in one syllable. English has tons: boy (oi), cow (au), eight (ei), food (ou). Greek is simpler: second letter is always ι or υ.",
          "αι like aisle in Erasmian, but like e in met in Koine. ει like eight (Erasmian) or machine (Koine). ου is always oo like food — the easiest one and the most common. αυ = av/af (like 'ouch' without the ch, + v). ευ = ev/ef.",
          "The sneaky ones: ᾳ ῃ ῳ — an alpha, eta or omega with a tiny iota underneath. It's silent today but grammarians left it because it screams 'I am a dative singular!' When you see τῇ καρδίᾳ, that little subscript tells you 'in the heart' without looking up a chart.",
        ],
        englishVsGreek: [
          { english: "boy = ο + ι → οι, cow = α + υ → αυ, machine = ε + ι → ει", greek: "Same sliding logic: two vowels, one syllable, fast glide", whyItMatters: "If you can say 'boy' you can say 'οἶκος' — same mouth." },
        ],
        examples: [
          { greek: "καί", translit: "kai", literal: "k-eye (Era) / ke (Koine)", natural: "and", breakdown: "The most common Greek word. Just memorize: και = and. You'll see it 9,000 times." },
          {
            greek: "εὐαγγέλιον",
            translit: "euangelion",
            literal: "ev-an-GHE-lee-on (late-Koine/Modern)",
            natural: "good news, gospel",
            breakdown:
              "εὐ = good (as in euphemism/euphoria) + ἄγγελος = messenger. The smooth breathing on υ is silent; it never adds an m-sound. In the app's Greek voice, ευ before the following vowel is ev. The exact γγ quality varies by reconstructed period.",
          },
        ],
        thinkLikeGreek: ["For one day, say 'and' as καί in your head whenever you think it. Replace a high-frequency English function word. This is how bilingual kids start."],
        memoryTrick: "Suspended in a diphthong: second letter is always ι or υ. If second letter is α, ε, ο — it's two separate syllables, not a diphthong.",
      },
    ],
  },
  "breathings-accents": {
    slug: "breathings-accents",
    intro:
      "Tiny squiggles above vowels that ancient scribes added 700 years after Jesus to help you read. Five minutes to learn them saves you hundreds of misreads.",
    sections: [
      {
        id: "breathing",
        title: "Breathings: the only h in Greek",
        body: [
          "Greek has no letter h. Instead, it puts a tiny c above the starting vowel: smooth (᾿) = nothing, rough (῾) = h. That's it.",
          "ὁ = ho (the), ὅς = hos (who), ἅγιος = hagios (holy). Remove the mark, no h. Add it, h. English does the same with an actual letter: hour vs our, heir vs air.",
          "On a diphthong the breathing goes on the second letter: αὐτός, οὗτος. On ρ it's always rough: ῥῆμα (r + h → rh). This is why we transliterate rhetoric, rhythm with rh — Greek had rough breathing on rho.",
          "English memory: we have 'an heir' vs 'a hair', 'an hour' vs 'our'. The difference is just presence of h, exactly like ὁ vs ο.",
        ],
        englishVsGreek: [
          { english: "an hour (silent h) vs a house (pronounced h)", greek: "ἐν (en, no h) vs ἑν (hen, with h) — but Greek marks the h with ῾", whyItMatters: "Same job, different orthography." },
          { english: "rhetoric, rhythm, rhesus — we keep rh for Greek rough rho", greek: "ῥητορική, ῥυθμός", whyItMatters: "English spelling preserves Greek breathings you never knew existed." },
        ],
        examples: [
          { greek: "εἷς vs εἰς", literal: "heis vs eis", natural: "one vs into", breakdown: "Only breathing + accent differ. εἷς (rough, circumflex) = number one. εἰς (smooth) = preposition into. Misplace the breathing, flip meaning." },
          { greek: "αὐτή vs αὕτη", literal: "autē vs hautē", natural: "she vs this woman", breakdown: "αὐτή (smooth) = 3rd person pronoun she/it. αὕτη (rough) = demonstrative 'this'. Again, only breathing distinguishes." },
        ],
        thinkLikeGreek: ["Take five English h-words (holy, house, heaven) and add rough breathing in your mind when you say them in Greek. Build the reflex."],
        memoryTrick: "Rough looks like an opening half-circle, like you are opening your mouth to let out an h: ῾ . Smooth is closing: ᾿.",
      },
      {
        id: "accents",
        title: "Three accents, one job: tell you where the music goes",
        body: [
          "Ancient Greek was pitched like Chinese or Swedish — voice rose and fell. acute ´ = rising pitch, grave ` = flat/dropped, circumflex ῀ = rise then fall on a long vowel. Today we just stress the accented syllable, like English.",
          "Rules: Accent can only be on one of the last three syllables. Circumflex can only be on a long vowel/diphthong. If final syllable is long, accent cannot be on third-from-last — it moves forward (ὁ ἄνθρωπος but τοῦ ἀνθρώπου).",
          "You do not need to master this to read, but two contrasts change meaning: τίς (who? with accent) vs τις (someone, enclitic, usually unaccented) and ποῦ (where?) vs που (somewhere). Interrogative always acute; indefinite usually throws its accent away.",
          "English parallel: 'record' as noun (RE-cord) vs verb (re-CORD) — stress changes meaning. Greek accents do similar work but more systematically.",
        ],
        englishVsGreek: [
          { english: "REcord (noun) vs reCORD (verb) — stress changes category", greek: "τίς (who?) vs τις (someone) — accent changes definiteness", whyItMatters: "Both languages use accent to distinguish interrogative from indefinite." },
        ],
        examples: [
          { greek: "τί ποιεῖς;", literal: "ti poieis?", natural: "What are you doing? (with ; as ?)", breakdown: "τίς → τί before a vowel. English question mark is ; . This is also an example of enclitic τόν." },
          { greek: "ἄνθρωπός τις", literal: "anthrōpos tis", natural: "a certain man, some man", breakdown: "τις is enclitic and leans on ἄνθρωπος, often losing accent. If you see τις with no accent, think 'some'." },
        ],
        thinkLikeGreek: ["When you read, don't chant accents. Just stress the accented syllable slightly louder and longer, like English. That's close enough for Koine pronunciation."],
        commonPitfalls: ["Confusing ; as semicolon. In Greek manuscripts, ; is the question mark. The raised dot · is semicolon/colon.", "Thinking grave accent matters for meaning — it is just an acute that lost its pitch because another word followed. καὶ ὁ λόγος: καί becomes καὶ when another word is after it."],
      },
    ],
  },
  "cases-nouns": {
    slug: "cases-nouns",
    intro:
      "Greek doesn't need word order to tell you who did what to whom. It puts that information on the end of the noun itself. You already do this a little in English — you just forgot.",
    sections: [
      {
        id: "english-cases",
        title: "Wait — English has cases too (you use them every day)",
        body: [
          "I vs me vs my. He vs him vs his. She vs her vs hers. They vs them vs theirs. You use three different forms of the same pronoun depending on its job. I (subject), me (object), my (possession). That IS case.",
          "English nouns lost most case endings, so we compensate with strict word order: 'The dog chased the cat' means something completely different from 'The cat chased the dog.' Flip order, flip meaning — because there are no case endings to tell us who is subject.",
          "Greek keeps the endings, so order is free to mark emphasis. ὁ λόγος is subject no matter where it sits because -ος and ὁ mark it nominative. Couple that ending freedom with English order-freedom and you get: Greek word order = emphasis, not grammar.",
          "Kids get this fast if you show them: 'Dog bites man' is news; 'Man bites dog' is newsier because you flipped subject/object by order. Greek would keep both nouns in nominative/accusative forms and flip order to highlight whichever it wants first.",
        ],
        englishVsGreek: [
          { english: "He (subject) / him (object) / his (owner) — three forms, same person", greek: "αὐτός (subject) / αὐτόν (object) / αὐτοῦ (owner) — same idea, but for every noun not just pronouns", whyItMatters: "You already have native case intuition from English pronouns. Extend it to all nouns." },
          { english: "The dog (subj) chased the cat (obj) — order tells you", greek: "ὁ κύων ἐδίωξε τὸν αἴλουρον — ending tells you, order is free so αἴλουρον could go first for emphasis: τὸν αἴλουρον ἐδίωξε ὁ κύων 'It was the CAT the dog chased!'", whyItMatters: "Same information, different device: suffix instead of position." },
        ],
        examples: [
          { greek: "βλέπω τὸν ἄνθρωπον / τὸν ἄνθρωπον βλέπω", literal: "I-see the man / the man I-see", natural: "Both mean I see the man, but second emphasizes THE MAN", breakdown: "τὸν + -ον = accusative = object. No matter where you put it, it stays object. The order shift is pragmatiс." },
          { greek: "ὁ θεὸς ἀγαπᾷ τὸν κόσμον", literal: "the God loves the world", natural: "God loves the world (John 3:16)", breakdown: "God = nominative subject (ὁ…ὁς → -ός). World = accusative object (τὸν κόσμον). Swap them: τὸν κόσμον ἀγαπᾷ ὁ θεός still means God loves world, but emphasizes world." },
        ],
        thinkLikeGreek: [
          "For one afternoon, speak English but add fake case endings: 'I-saw he-accusative.' Feel how ending marks job, not order.",
          "Parse English sentences for fun: find subject, object, owner in a newspaper headline.",
        ],
        memoryTrick: "N = Nominative = Naming (subject). G = Genitive = general's (possessive). D = Dative = giving to/for. A = Accusative = accus-ing (direct object). V = Vocative = voc! calling.",
      },
      {
        id: "second-decl",
        title: "Second declension: the -ος/-ον family (your first paradigm)",
        body: [
          "If a Greek noun ends in -ος it's probably masculine (ὁ ἄνθρωπος, ὁ λόγος, ὁ Ἰησοῦς) and if -ον it's neuter (τὸ ἔργον, τὸ τέκνον). Feminine in this declension are rare but important: ἡ ὁδός 'way/road' looks masculine but is feminine — you must learn its article.",
          "Neuter superpower: neuter nominative = accusative, always. τὸ ἔργον could be either 'the work' as subject or object; you need the verb to decide. τὰ ἔργα could be subject or object plural. This ambiguity is normal and solved by context, just like English 'She hit the bat' is ambiguous without story context.",
          "Learn nouns as article+form: ὁ λόγος not just λόγος, τὸ ἔργον not just ἔργον. The article carries gender for free and drills the case endings via osmosis.",
        ],
        englishVsGreek: [
          { english: "We say 'a work / works' but 'work' form barely changes", greek: "τὸ ἔργον / τὰ ἔργα — vowel change tells number, just like foot/feet", whyItMatters: "English has irregular plurals; Greek has regular - but the concept of stem+ending change is familiar." },
        ],
        examples: [
          { greek: "οἱ ἀδελφοὶ ἀκούουσιν τὸν λόγον", literal: "the brothers hear the word", natural: "The brothers hear the word", breakdown: "οἱ = masc pl nom article, ἀδελφοὶ = -οι nom pl, ἀκούουσιν = they hear, τὸν λόγον = accusative object." },
          { greek: "ἐν τῷ οἴκῳ τοῦ ἀδελφοῦ", literal: "in the house of the brother", natural: "in the brother's house", breakdown: "ἐν + dative = in, τῷ οἴκῳ dat sg, τοῦ ἀδελφοῦ gen sg = of the brother." },
        ],
        thinkLikeGreek: ["Build a sentence factory: pick a subject from 2nd declension, a verb you know, an object: ὁ δοῦλος βλέπει τὸν οἶκον. Say it aloud. Swap subject/object and keep meaning via endings."],
        commonPitfalls: [
          "Forgetting neuter = nominative = accusative ambiguity. Don't panic; look at verb agreement and common sense.",
          "Assuming -ος always = masculine. Most are, but ὁδός, ἄβυσσος, etc. are feminine. Trust the article, not the ending.",
        ],
      },
      {
        id: "first-decl",
        title: "First declension: the -α/-η family (mostly feminine)",
        body: [
          "If -ος is the masculine uniform, -α/-η is the feminine uniform. Three sub-patterns look messy but rule is simple: look at the letter before the ending.",
          "After ε, ι, ρ, α stays α everywhere: ἡμέρα, ἡμέρας, ἡμέρᾳ, ἡμέραν (day). After most consonants, η everywhere: γραφή, γραφῆς, γραφῇ, γραφήν (writing). After σ ζ ξ ψ or double consonant, mix: δόξα, δόξης, δόξῃ, δόξαν (glory) — α flips to η only in genitive and dative singular.",
          "English has this too: we say 'box → boxes' (es after x), 'bus → buses'. The spelling changes to make pronunciation easier. Greek does same: after certain consonants α eases to η.",
          "Plural for ALL first declension is identical: -αι, -ῶν, -αις, -ας. Learn that chunk once, reuse everywhere.",
        ],
        englishVsGreek: [
          { english: "cat → cats, box → boxes — spelling adjusts after s-like sounds", greek: "δόξα → δόξης (not δόξας) after ξ", whyItMatters: "Phonological ease drives spelling changes in both languages." },
        ],
        examples: [
          { greek: "ἡ βασιλεία τῶν οὐρανῶν", literal: "the kingdom of the heavens", natural: "the kingdom of heaven", breakdown: "βασιλεία nom sg, τῶν οὐρανῶν gen pl — of the heavens. Matthew's favorite circumlocution for God's kingdom." },
          { greek: "ἐν τῇ ἡμέρᾳ τῇ ἐσχάτῃ", literal: "in the day the last", natural: "on the last day", breakdown: "Double article + adjective: τῇ ἡμέρᾳ (dat sg) τῇ ἐσχάτῃ — attributive position, both dative." },
        ],
        memoryTrick: "Alpha-pure = after ε, ι, ρ (the letters in the word 'eir'). Remember EIR = alpha stays pure. Everything else gets mixed.",
      },
    ],
  },
  "article-adjectives": {
    slug: "article-adjectives",
    intro:
      "19,870 times in the New Testament — the article ὁ ἡ τό is the most common Greek word. Master its 24 forms and you master half the noun system's endings for free.",
    sections: [
      {
        id: "article-chart",
        title: "24 forms that teach you everything, like the multiplication table",
        body: [
          "In English we have one form 'the'. Greek 'the' changes for gender, number, case: ὁ masc nom sg, ἡ fem nom sg, τό neut nom sg, τοῦ genitive (any gender singular because -ου), τῶν gen plural (any gender plural). Learn the chart like a times table — after that every noun ending looks familiar because nouns copy the article.",
          "Greek has no 'a/an'. If there is no article, context decides. Sometimes it's indefinite ('a god'), sometimes qualitative ('divine in quality'), sometimes definite for other reasons (proper names don't need article). This is why John 1:1c θεὸς ἦν ὁ λόγος is not 'a god' but 'what God was, the Word was' in quality.",
          "Superpower: article + anything = noun. τὸ ἀγαθόν 'the good thing', οἱ μετ' αὐτοῦ 'those with him' (literally 'the with hims'), τὸ ἀποθανεῖν 'the to-die' = dying. Once you see this, Pauline phrases become transparent.",
        ],
        englishVsGreek: [
          { english: "the rich, the poor, the good — adjective used as noun", greek: "οἱ ἅγιοι = the holy ones = saints, ὁ πονηρός = the evil one", whyItMatters: "Exact same construction in both languages: article + adjective = noun phrase." },
        ],
        examples: [
          { greek: "ὁ ἀγαθὸς ἄνθρωπος", literal: "the good man", natural: "the good man", breakdown: "Attributive position 1: article + adjective + noun. Bubble: [ὁ ἀγαθὸς ἄνθρωπος] all one." },
          { greek: "ὁ ἄνθρωπος ὁ ἀγαθός", literal: "the man the good", natural: "the good man (more emphatic)", breakdown: "Attributive position 2: article + noun + article + adjective. Second wrapper emphasizes the adjective." },
          { greek: "ὁ ἄνθρωπος ἀγαθός", literal: "the man good", natural: "the man IS good", breakdown: "Predicate: adjective outside article bubble → supply 'is'. This one rule solves hundreds of English mistranslations." },
        ],
        thinkLikeGreek: [
          "When reading, draw a bubble around article+noun groups in your mind. If adjective is inside bubble, it's 'the good man'. If outside, it's 'the man is good'.",
          "Find 10 examples of article+adjective as noun in Paul (e.g., Romans). List them: οἱ πιστοί, οἱ ἅγιοι, etc.",
        ],
        memoryTrick: "Attributive = inside bubble = AN. Predicate = outside bubble = IS. AN vs IS.",
      },
    ],
  },
  "present-indicative": {
    slug: "present-indicative",
    intro:
      "Greek verbs carry their own pronouns. English says 'I loose, you loose, he looses'. Greek says λύω, λύεις, λύει — the ending is the pronoun.",
    sections: [
      {
        id: "person-endings",
        title: "Endings are pronouns — you can drop 'I' and 'you'",
        body: [
          "Present tense stem + ω/εις/ει/ομεν/ετε/ουσι(ν). -ω = I, -εις = you (singular), -ει = he/she/it, -ομεν = we, -ετε = you plural, -ουσι(ν) = they. English does something similar: I walk, you walk, he walks (adds -s). Greek just does it for all persons, so pronouns are optional and when added they are emphatic: ἐγὼ λύω = *I* (not you) loose.",
          "This feels weird until you realize Spanish, Italian, Greek, Hebrew all do this. English is the odd one out for needing pronouns always. You already know this pattern from texts: 'Going to store. Be back soon.' We drop pronouns informally — Greek does it formally.",
          "Aspect primer: present tense in Greek is not about present time only; it's about viewpoint. Present = imperfective aspect = you're watching the action from inside, as unfolding. 'He is loosing, he keeps loosing'. In storytelling it can even be past (historic present) for vividness: 'And he says to them...' in Mark narrating past events.",
        ],
        englishVsGreek: [
          { english: "He walks vs they walk — one letter -s marks person/number", greek: "λύει vs λύουσι — ending marks person/number for every pronoun, so no pronoun needed", whyItMatters: "Same job (marking who), broader application." },
          { english: "We text 'Going to store' — pronoun dropped, endingless but understood", greek: "λύω alone means 'I loose' — ending is pronoun", whyItMatters: "Pro-drop is natural; English does it informally, Greek grammatically." },
        ],
        examples: [
          { greek: "πιστεύω εἰς τὸν κύριον", literal: "I-believe into the Lord", natural: "I believe in the Lord", breakdown: "πιστεύω = 1st sg present + εἰς + accusative = trust directed toward. Classic Christian formula." },
          { greek: "οὐ βλέπομεν τὸν κύριον", literal: "not we-see the Lord", natural: "We do not see the Lord", breakdown: "οὐ negates indicative; -ομεν says we; no ἡμεῖς needed." },
        ],
        thinkLikeGreek: [
          "Conjugate πιστεύω aloud while walking: πιστεύω, πιστεύεις, πιστεύει... Add gestures for each person.",
          "Listen for movable nu: λύουσιν before vowel, λύουσι at end. It has no meaning, just eases pronunciation like English a vs an.",
        ],
        commonPitfalls: [
          "Confusing present tense with only present time. In participles/infinitives, present = aspect only, no time.",
          "Thinking οὐ and μή are interchangeable. οὐ = not for statements (indicative). μή = not for thoughts, wishes, commands.",
        ],
        memoryTrick: "Song to 'Twinkle Twinkle': -ω, -εις, -ει, -ομεν, -ετε, -ουσι(ν). Sing it with πιστεύω words.",
      },
    ],
  },
  "eimi-prepositions": {
    slug: "eimi-prepositions",
    intro:
      "Two glue systems: εἰμί 'to be' for identity and prepositions for space. Together they build your first real sentences.",
    sections: [
      {
        id: "eimi",
        title: "εἰμί: the most irregular verb in both English and Greek — and that's normal",
        body: [
          "English 'to be' is wildly irregular: am, is, are, was, were. Greek εἰμί is equally irregular: εἰμί, εἶ, ἐστί(ν), ἐσμέν, ἐστέ, εἰσί(ν). Every language mangles its most common verb because we use it so often we wear down its forms.",
          "Key: εἰμί never takes an object. What follows is same case as subject — nominative. ὁ λόγος ἐστὶ θεός? No, θεὸς ἦν ὁ λόγος — predicate nominative, not accusative. This solves a lot of John 1:1 confusion: article on λόγος tells you it's subject even if word order flips for emphasis.",
          "Imperfect ἦν = was (continuous). In John 1:1 ἦν means the Word continuously was — not started. For 'came into being' John uses different verb ἐγένετο (aorist of ginomai). The distinction between 'was' and 'became' is theology ingrammar.",
        ],
        englishVsGreek: [
          { english: "I am a student = I (nom) = a student (nom) — both sides of 'is' describe same person", greek: "ἐγώ εἰμι μαθητής — both nominative, same structure", whyItMatters: "Be verbs equate, they don't act on an object. Same in both languages." },
        ],
        examples: [
          { greek: "ἐγώ εἰμι ἡ ἀλήθεια", literal: "I I-am the truth", natural: "I am the truth", breakdown: "Pred nominative, intensive ἐγώ optional. The double naming emphasizes identity." },
          { greek: "ἦν πρὸς τὸν θεόν", literal: "was face-to-face-to the God", natural: "was with God (intimate, face-to-face)", breakdown: "πρός + acc = toward, with nuance of personal presence vs ἐν = in." },
        ],
        memoryTrick: "ἤμην, ἦς, ἦν — sing to 'I was, you were, he was' — imperfect tells past continuous, like 'was verb-ing'.",
      },
      {
        id: "prepositions",
        title: "Prepositions are tiny GPS devices and their meaning changes with case",
        body: [
          "English prepositions are simple: in, into, out of, through, because of. Greek uses fewer words but changes meaning via the case that follows. διά + genitive = through (space). διά + accusative = because of (reason). Same word, different case = different GPS coordinate.",
          "This is like English 'on': on Monday (time), on purpose (cause), on the table (location). One preposition, many senses. Greek just marks which sense with case ending, so it's actually clearer.",
          "Learn prepositions as families, not singles. Group by how many cases they take: one-case-only (ἐν + dat only = in), two-case (διά), three-case (ἐπί gen/dat/acc). Start with one-case masters: ἐν ( dat only) = in/by, εἰς (acc only) = into, ἐκ (gen only) = out of.",
          "They also prefix verbs and keep meaning: βάλλω throw, ἐκ-βάλλω throw out, εἰσ-βάλλω throw into. English does this: in-come vs out-come vs be-come. Same Lego.",
        ],
        englishVsGreek: [
          { english: "'in the house' vs 'into the house' — different prepositions", greek: "ἐν τῷ οἴκῳ (dative) vs εἰς τὸν οἶκον (acc) — case does work English does with two words", whyItMatters: "Case reduces need for extra prepositions; it's efficient." },
          { english: "overlook (over+look) keeps 'over' sense", greek: "ἐκβάλλω (out-throw) keeps ἐκ sense", whyItMatters: "Compound verbs are transparent in both languages if you know the prefix." },
        ],
        examples: [
          { greek: "διὰ τοῦ νόμου", literal: "through the law", natural: "through the law (genitive)", breakdown: "διά + genitive = channel/space." },
          { greek: "διὰ τὸν νόμον", literal: "because-of the law", natural: "because of the law (accusative)", breakdown: "Same preposition διά, different case, different meaning. Watch the article." },
        ],
        thinkLikeGreek: [
          "Draw a house: mark ἐν (inside), εἰς (arrow in), ἐκ (arrow out), πρός (arrow toward face). Visual > list.",
          "Find 5 compound verbs with ἐκ in John and decode them via prefix sense.",
        ],
      },
    ],
  },
  "immersion-stories": {
    slug: "immersion-stories",
    intro:
      "You learned your first language without a grammar book. This lesson is permission to learn Greek the same way — by understanding stories directly, not by translating them.",
    sections: [
      {
        id: "comprehensible",
        title: "80-90% known is the sweet spot (Krashen's i+1)",
        body: [
          "If you understand less than 80%, it's noise. More than 95%, you're not learning. Good immersion content is 80-90% comprehensible — you get the story from pictures, gestures, repetition, and a few unfamiliar words you guess from context.",
          "Alpha with Angela does this with drawing, props and slow speech — all in Greek, zero English. At first you understand 30%. Rewatch same story tomorrow: 70%. Day 3: 90%. That jump is language acquisition, not puzzle-solving.",
          "English parallel: you watch a Spanish cooking show with no subtitles. You don't catch every word, but you see tomato, knife, pan, and the host says '¡Más sal!' while adding salt. You infer 'more salt'. You didn't translate; you acquired.",
          "Shadowing: Play a sentence, pause, repeat aloud imitating melody and rhythm. Five minutes daily rewires your mouth. Monks learned Latin this way for centuries.",
        ],
        englishVsGreek: [
          { english: "You learn 'What's this?' before 'What is the accusative singular masculine form of this demonstrative?'", greek: "Τί ἐστιν τοῦτο; first, then grammar", whyItMatters: "Communication before analysis mirrors first-language order." },
        ],
        examples: [
          { greek: "ποῦ ἐστιν τὸ παιδίον;", literal: "where is the small-child?", natural: "Where is the child?", breakdown: "πού = where? ἐστιν = is, τὸ παιδίον = the child (diminutive). Question answered by pointing." },
          { greek: "τὸ παιδίον ἐστὶν ἐν τῷ οἴκῳ.", literal: "the child is in the house", natural: "The child is in the house", breakdown: "Full SVO-ish answer, locative ἐν + dative." },
        ],
        thinkLikeGreek: [
          "Watch a story once without pausing, no dictionary. Write 3 things you caught. Rewatch tomorrow.",
          "Make your own story with stick figures using only words you know. Tell it aloud in Greek to a wall.",
        ],
        memoryTrick: "Input → Intake → Output. Intake only happens if input is comprehensible. Don't climb a wall too high; walk around it via many easy stories.",
      },
    ],
  },
  "imperfect-future": {
    slug: "imperfect-future",
    intro:
      "Two new tense-forms: imperfect adds a past prefix, future adds a σ. Both reveal Greek sound laws you can feel in your mouth.",
    sections: [
      {
        id: "augment",
        title: "Augment: Greek marks past with a spare vowel up front",
        body: [
          "English marks past with -ed at the end: walk → walked. Greek marks past with ἐ- at the front called augment: λύω → ἔλυον. Both are just 'past flag' morphemes.",
          "Vowel-initial verbs lengthen instead: ἀκούω → ἤκουον (α→η), ἐγείρω → ἤγειρον (ε→η), ὁράω → ἑώρων (ο→ω). English does something similar: fall → fell, not fall-ed for a handful of common verbs. Common verbs are irregular.",
          "Compound verbs: augment goes between prefix and root: ἐκβάλλω → ἐξέβαλλον. English: override → overrode (past infix-like). Same sandwiching idea.",
          "Ambiguity: ἔλυον is both I was loosing and they were loosing. Context decides, just like English 'you' is singular or plural based on context.",
        ],
        englishVsGreek: [
          { english: "walk → walked (add -ed suffix for past)", greek: "λύω → ἔ-λυ-ον (add ἐ- prefix for past)", whyItMatters: "Same job, opposite edge of word. Past marking is prefixal in Greek indicative, suffixal in English." },
        ],
        examples: [
          { greek: "ἐδίδασκεν αὐτοὺς", literal: "he-was-teaching them", natural: "He was teaching them", breakdown: "Imperfect = ongoing/past background. Mark loves this to slow camera for scenery." },
          { greek: "ἤκουον τὴν φωνήν", literal: "they-were-hearing the voice", natural: "They were hearing the voice", breakdown: "ἀκούω → ἤκουον via augment α→η." },
        ],
        thinkLikeGreek: ["Take 5 present verbs, augment them, say them as 'was verb-ing'. Feel past continuity vs simple past."],
      },
      {
        id: "future-sigma",
        title: "Future: insert σ, then watch consonants kiss and change",
        body: [
          "Future = stem + σ + primary endings: λύσω, λύσεις, λύσει. English future uses word 'will'. Greek uses a single letter σ. Both are future markers.",
          "Sound law: labial (π β φ) + σ → ψ (that's why 'lips' is spelled ps-ish: βλέπω → βλέψω). Velar (κ γ χ) + σ → ξ (ἄγω → ἄξω, like axe). Dental (τ δ θ) + σ → σ with dental dropping (πείθω → πείσω). ζ + σ → σ (βαπτίζω → βαπτίσω).",
          "These are exactly English assimilation: we say 'cups' not 'cup-s' → ps sound, 'dogs' → gz. Mouth prefers to blend.",
          "Liquid futures (λ μ ν ρ): stem + εσ which contracts with circumflex: μένω → μενῶ, ἀποστέλλω → ἀποστελῶ. The circumflex is a flag that contraction happened.",
        ],
        englishVsGreek: [
          { english: "cup + s = cups /kʌps/ (p+s→ps)", greek: "βλέπ + σ → βλέψω (p+s→ps)", whyItMatters: "Identical phonological rule: labial + sibilant → ps cluster." },
        ],
        memoryTrick: "Labial → ψ like lips (labial). Velar → ξ like axe (velar). Dental → loses itself, humble.",
      },
    ],
  },
  aorist: {
    slug: "aorist",
    intro:
      "The aorist is the backbone of Greek narrative. Think of it as the default 'and then he did X' tense that moves story forward. It's not about time alone — it's about viewpoint: whole action from outside.",
    sections: [
      {
        id: "first-vs-second",
        title: "First aorist (σ-aorist) vs second aorist (root-changing)",
        body: [
          "First aorist shouts -σα-: ἔλυσα, ἐπίστευσα, ἐβάπτισα. If you see σα between augment and ending, it's first aorist 90% of time.",
          "Second aorist changes stem root and uses endings of imperfect: λέγω → εἶπον (completely new stem), λαμβάνω → ἔλαβον, ἔρχομαι → ἦλθον, ὁράω → εἶδον. No σα. You must memorize principal parts like English 'go→went' not 'goed'.",
          "No meaning difference between first and second aorist. It's purely morphology, like English 'walked' vs 'ran' both indicate past.",
          "Liquid aorists drop σ and lengthen: ἀποστέλλω → ἀπέστειλα, μένω → ἔμεινα — same as future but with augment.",
        ],
        englishVsGreek: [
          { english: "go → went, eat → ate (second past form changes root)", greek: "λέγω → εἶπον, ἐσθίω → ἔφαγον (second aorist changes root)", whyItMatters: "Both languages have regular -ed/-sa past and irregular root-change past." },
        ],
        examples: [
          { greek: "καὶ ὁ λόγος σὰρξ ἐγένετο", literal: "and the Word flesh became", natural: "And the Word became flesh", breakdown: "ἐγένετο = aorist middle of γίνομαι, whole event viewed as complete entry into new state." },
          { greek: "ἐβαλον vs ἐβαλλον", literal: "they threw vs they were throwing", natural: "aorist vs imperfect distinguished only by single/double λ", breakdown: "Proof that you must memorize: only λλ vs λ distinguishes tense." },
        ],
        commonPitfalls: [
          "Reading 'aorist = once-for-all' into preaching. Aorist can cover 40-year reign. It's undefined, not instantaneous.",
          "Assuming aorist participle = past time. Outside indicative, aorist has NO time, only aspect (view whole). Temporal meaning comes from context.",
        ],
      },
      {
        id: "aspect-primer",
        title: "Perfective vs imperfective: camera outside vs inside",
        body: [
          "Imagine filming a race. Imperfect: camera runs alongside runner, you see strides, sweat, ongoing. Aorist: drone shot from above, you see whole race as one dot traveling from start to finish.",
          "English progressive vs simple past approximates: 'he was reigning' (imperfect, inside) vs 'he reigned' (aorist, exterior summary). But Greek uses aspect more systematically than English, especially beyond indicative.",
          "In narrative, aorist is backbone: and then he did X, and then Y, and then Z. Imperfect paints background: while he was doing X, Y was happening. Mark shifts to present for vivid beats — historic present.",
        ],
        englishVsGreek: [
          { english: "It was raining when he arrived — background (was raining) vs main event (arrived)", greek: "Imperfect background (ἔβρεχεν) + aorist mainline (ἦλθεν)", whyItMatters: "Both languages use imperfective for background, perfective for foreground." },
        ],
        thinkLikeGreek: ["When reading Mark, highlight imperfects in blue (background), aorists in yellow (mainline), presents in pink (vivid). Watch pattern emerge."],
      },
    ],
  },
  "middle-passive": {
    slug: "middle-passive",
    intro:
      "English has two voices: active (I break) and passive (I am broken). Greek has three — middle — where subject is somehow involved in or affected by action. This is not exotic; English sneaks it in.",
    sections: [
      {
        id: "middle-meaning",
        title: "Middle: subject is inside the action",
        body: [
          "Active: I wash the car — I act on external object. Passive: The car is washed (by me) — I receive action. Middle: I wash myself (λούομαι) — I act but also affected. Or: I wash (my own hands) for my benefit. Or: I get washed in the sense of experiencing.",
          "English middle traces: 'This book sells well' — book is not passive victim, it's inherently sellable. 'The door opened' — not 'was opened by someone', just middle. Greek uses this much more.",
          "Forms: present middle/passive identical: λύομαι, λύῃ, λύεται, λυόμεθα, λύεσθε, λύονται. Only aorist/future split: ἐλυσάμην (aor mid) vs ἐλύθην (aor pass with -θη-). -θη- is historically middle marker that specialized toward passive, so many θη-forms are not passive in meaning: ἀπεκρίθη 'he answered' (middle sense), ἐφοβήθη 'he became afraid'.",
        ],
        englishVsGreek: [
          { english: "The door opened vs The door was opened — middle vs passive subtlety", greek: "Same split: middle affected subject vs passive external agent", whyItMatters: "English intuits middle; Greek grammaticalizes it." },
        ],
        examples: [
          { greek: "ἀπεκρίθη ὁ Ἰησοῦς", literal: "answered (middle-θ form) the Jesus", natural: "Jesus answered", breakdown: "θη-form but middle meaning: subject engages in answering, affected by conversation. Not passive." },
          { greek: "ἐβαπτίσθη ὑπὸ Ἰωάννου", literal: "was-baptised by John", natural: "was baptised by John — true passive with agent ὑπό + genitive", breakdown: "Agent expressed = passive. No agent = often middle." },
        ],
        commonPitfalls: [
          "Translating every middle as reflexive 'myself'. Often it's not reflexive but subject-involved: beneficial middle, spontaneous process, mental process.",
          "Calling ἔρχομαι, γίνομαι deponent (active meaning despite middle form). Modern view: they ARE middle in meaning — coming, becoming affect the subject.",
        ],
      },
    ],
  },
  "third-declension": {
    slug: "third-declension",
    intro:
      "Third declension looks scary because nominative hides the true stem. Find genitive, strip -ος, and you have stem. That's the whole trick.",
    sections: [
      {
        id: "stem-trick",
        title: "The one rule: genitive reveals stem",
        body: [
          "First and second declensions: nominative shows stem (ἄνθρωπ-ος). Third: nominative disguised by sound changes when σ added. Solution: Lexicons give genitive: σάρξ, σαρκός → stem σαρκ-. πνεῦμα, πνεύματος → stem πνευματ-. πίστις, πίστεως → stem πιστε-. Remove -ος from genitive, you own the noun.",
          "English analogy: 'foot' → 'feet' looks irregular; but possessive 'foot's' reveals base 'foot'. Or child → children's, genitive reveals original vowel. Same method: oblique case reveals base.",
          "Endings: -ς/none (nom sg), -ες (nom pl), -ος/-ων gen, -ι/-σι dat, -α/-ας acc for M/F, bare stem for neuter nom/acc. Once stem known, endings are tiny.",
          "Sound changes: Nom sg and Dat pl add σ → labial+σ→ψ, velar+σ→ξ, dental drops. So σάρξ = σαρκ + σ, with κ+σ→ξ, τ dropped. That's future/aorist sound law reused. Same mouth physics everywhere.",
        ],
        englishVsGreek: [
          { english: "mouse → mice (vowel changes in plural), child → children (r-insertion)", greek: "πατήρ, πατρός → stem πατρ- with vowel syncopation, similar hidden stem", whyItMatters: "Both languages have nouns where singular hides base, oblique form reveals it." },
        ],
        examples: [
          { greek: "διὰ πίστεως τῆς ἐν Χριστῷ", literal: "through faith the in Christ", natural: "through the faith in Christ", breakdown: "πίστεως gen sg from πίστις -ις/-εως class, a common abstract noun type." },
          { greek: "ἐν σαρκί", literal: "in flesh", natural: "in the flesh / according to fleshly nature", breakdown: "σαρκί = dat of σάρξ, guttural stem σαρκ- + ι." },
        ],
        memoryTrick: "Nominative lies, genitive tells truth. Always ask 'who's your genitive?'",
      },
    ],
  },
  participles: {
    slug: "participles",
    intro:
      "Participles are verbal adjectives: half verb (tense, voice), half adjective (case, gender, number). English has them: 'the running man' (present participle), 'the broken vase' (past participle). Greek uses them 3x more — they are the engine of Greek prose.",
    sections: [
      {
        id: "verbal-adjective",
        title: "Six-slot parsing: the super-verb that agrees like an adjective",
        body: [
          "English: running (verb: action of running) + man (noun it describes) = adjective phrase. Greek: λύων (present active participle, masc nom sg) — present = unfolding aspect, active = subject does loosing, -ων ending = masc nom sg, agrees with noun it modifies.",
          "Morpheme flags: -ντ- = active participle (λύων, λύοντας), -μεν- = middle/passive participle (λυόμενος), -σαντ- = aorist active (λύσας), -θεντ- = aorist passive (λυθείς), -κοτ- = perfect active (λελυκώς). Spotting morpheme before word is reading hack.",
          "Four jobs: adverbial (circumstantial: when/because/if/although/ by verb-ing, anarthrous), adjectival (ὁ ἄνθρωπος ὁ λέγων = the man who is speaking), substantival (ὁ πιστεύων = the one who believes), periphrastic (ἦν διδάσκων = he was teaching).",
          "Time rule: non-indicative verbs have relative time: aorist participle usually BEFORE main verb, present usually SAME time as main verb. This is not absolute but hugely helpful: ἀκούσαντες ἐβαπτίσθησαν = having heard (prior), they were baptized.",
        ],
        englishVsGreek: [
          { english: "Having eaten dinner, he left — 'having eaten' = prior action", greek: "Δειπνήσας ἀπῆλθεν — aorist participle before main aorist", whyItMatters: "Same structure: participial clause describes preceding circumstance." },
          { english: "The one who believes — substantival participle", greek: "ὁ πιστεύων — identical", whyItMatters: "Article + participle = noun in both languages." },
        ],
        examples: [
          { greek: "ὁ πιστεύων εἰς τὸν υἱὸν ἔχει ζωὴν αἰώνιον", literal: "the believing into the Son has life eternal", natural: "The one who believes in the Son has eternal life", breakdown: "ὁ πιστεύων = substantival pres act part. John uses this construction 30+ times." },
          { greek: "λέγοντος αὐτοῦ ταῦτα", literal: "of him saying these things", natural: "While he was saying these things (genitive absolute)", breakdown: "Genitive noun + genitive participle, unconnected to main clause. English 'while' translation." },
        ],
        thinkLikeGreek: [
          "Before translating a participle, ask: 1) does it have article? If yes, adjectival/substantival. If no, adverbial. 2) Is genitive absolute? 3) Relative time: prior or same?",
        ],
      },
    ],
  },
  "infinitives-subjunctive": {
    slug: "infinitives-subjunctive",
    intro:
      "Non-indicative moods: Greek's way to talk about possibilities, wishes, purposes — the 'would/could/should/let's' layer that English does with helper words, Greek does with verb forms.",
    sections: [
      {
        id: "articular-inf",
        title: "Infinitive as noun — even with prepositions",
        body: [
          "English infinitive 'to believe' can be noun: 'To believe is hard.' Greek infinitive does same, but neuter and with article: τὸ πιστεύειν 'the believing'. Add prepositions for fine meaning: διὰ τὸ + inf = because, εἰς τό + inf = in order to, ἐν τῷ + inf = while, μετὰ τό + inf = after, πρὸ τοῦ + inf = before.",
          "Subject of infinitive goes in accusative (English similar: 'I want him to go' — him is accusative subject of to go). Greek: ἐν τῷ σπείρειν αὐτόν = in the sowing him = while he was sowing — αὐτόν is acc subject.",
          "Tense of infinitive is aspect only: present = continuous, aorist = whole. Outside indicative, Greek verbs lose time, keep viewpoint. This is crucial shift from beginner mind.",
        ],
        englishVsGreek: [
          { english: "I want him to believe — accusative 'him' is subject of infinitive", greek: "ἐν τῷ σπείρειν αὐτόν — αὐτόν acc subject of infinitive", whyItMatters: "Same syntax: infinitive's subject is accusative because infinitive is not finite." },
          { english: "In order to eat, After eating, By eating — preposition + gerund", greek: "εἰς τὸ φαγεῖν, μετὰ τὸ φαγεῖν, ἐν τῷ ἐσθίειν — preposition + articular infinitive", whyItMatters: "Exact functional parallel." },
        ],
        examples: [
          { greek: "εἰς τὸ εἶναι αὐτὸν πρωτότοκον", literal: "into the to-be him firstborn", natural: "in order that he be firstborn / so that he might be firstborn", breakdown: "εἰς τό + infinitive = purpose. Sophisticated construction learned with chunk, not built word by word." },
          { greek: "πρὸ τοῦ σε Φίλιππον φωνῆσαι", literal: "before the you Philip to-call", natural: "before Philip called you", breakdown: "πρὸ τοῦ + inf + acc subject σε = before you (were called by Philip) = before Philip called you." },
        ],
      },
      {
        id: "subjunctive",
        title: "Subjunctive: mood of projection — what might be, should be, let's do",
        body: [
          "Recognition: lengthened connecting vowel: λύω→λύω (pres subj 1sg looks same, but λύῃς second), λύωμεν. Aorist subjunctive has NO augment: λύσω (subj) vs ἔλυσα (ind). That's the giveaway.",
          "English does subjunctive with words: 'Let us believe', 'If we should believe', 'in order that we might believe'. Greek does via form: ἵνα πιστεύσωμεν. ἵνα + subjunctive = purpose or content.",
          "Prohibitions: μὴ + present imperative = stop doing (already doing). μὴ + aorist subjunctive = don't start/do at all. English: 'Stop worrying' (present) vs 'Don't worry (ever)'. Greek marks distinction grammatically; English via lexicon.",
          "Real life: All exhortations 'Let us...' in Hebrews are hortatory subjunctive 1st plural: ἀγαπῶμεν 'let us love'. Emphatic negation οὐ μή + aorist subjunctive = 'shall certainly not' — double negative for emphasis, like Southern US 'ain't no way' but grammatical.",
        ],
        englishVsGreek: [
          {
            english: "Let's go; let's eat — a proposal made to a group that includes the speaker",
            greek: "ἀγαπῶμεν = let us love — hortatory first-person plural subjunctive in -ωμεν",
            whyItMatters: "Both languages have a dedicated way to propose shared action; Greek marks it in the verb form.",
          },
          { english: "Don't do that! (command to stop) vs Don't ever do that! (prohibition)", greek: "μὴ ποίει (pres imper: stop doing) vs μὴ ποιήσῃς (aor subj: don't do at all)", whyItMatters: "Greek grammaticalizes a distinction English expresses with adverbs." },
        ],
        thinkLikeGreek: [
          "When you see ἵνα, immediately expect subjunctive next and translate 'so that ... may ...'.",
          "Spot hortatory subjunctives in 1 John: ἀγαπῶμεν ἀλλήλους 'let us love one another'.",
        ],
      },
    ],
  },
  "perfect-mi-contract": {
    slug: "perfect-mi-contract",
    intro:
      "Last morphology wall: reduplication (perfect), vowel collision (contract verbs), and athematic verbs (μι-verbs). All are common, so you meet them constantly — learn the patterns now and they become friends.",
    sections: [
      {
        id: "perfect",
        title: "Perfect: past action with present results — or stative aspect?",
        body: [
          "Form: reduplication (repeat initial consonant with ε): λύω → λέλυκα, πιστεύω → πεπίστευκα, γράφω → γέγραφα. Plus κ in active. Middle/passive: reduplication but no κ: γέγραπται, τετέλεσται.",
          "Meaning debate: Traditional says perfect = past action with abiding results: 'he has believed and still does'. Aspectual view says perfect = stative — focus on state of subject. Either way, perfect is marked and prominent: author chooses it when state matters. Τετέλεσται on cross is not just 'it finished' but 'it stands finished with results now'.",
          "High-frequency perfects: οἶδα is perfect form but present meaning 'I know' (second perfect). γέγραπται 'it stands written' is perfect passive, perfect state.",
          "English has perfect: 'I have written' vs 'I wrote' — present relevance vs simple past. Greek perfect similar but stronger prominence.",
        ],
        englishVsGreek: [
          { english: "It is finished (present state) vs It finished (past event)", greek: "τετέλεσται (perfect: stands finished, result now) vs ἐτελέσθη (aorist: it was finished)", whyItMatters: "Same contrast English makes with 'is finished' vs 'finished'." },
        ],
        examples: [
          { greek: "γέγραπται", literal: "it-has-been-written-and-stands-written", natural: "It stands written", breakdown: "Perfect pass 3sg, hugely frequent formula citing scripture as still authoritative." },
          { greek: "τετέλεσται", literal: "it-has-been-and-stands-finished", natural: "It is finished / It stands accomplished", breakdown: "Perfect pass of τελέω, frontground prominence — flare in narrative." },
        ],
      },
      {
        id: "contract",
        title: "Contract verbs: when vowels collide, they merge and show a hat (circumflex)",
        body: [
          "Verbs ending -άω, -έω, -όω: ἀγαπάω, ποιέω, πληρόω. In present/imperfect, stem vowel eats connecting vowel: α+ω→ω with circumflex ἀγαπῶ, ε+ει→ει ποιεῖς. The hat tells you contraction happened. Future and aorist lengthen vowel and no longer contract: ἀγαπήσω, ἐποίησα.",
          "English contractions: do+not→don't, cannot→can't. Vowels merge, apostrophe marks it like circumflex. Same economy.",
          "Rule chunks: For α-contract: α+ε→α, α+ο→ω, α+ει→ᾳ. For ε-contract: ε+ε→ει, ε+ο→ου. For ο-contract ο+ε→ου, ο+ο→ου, ο+ει→οι. Don't memorize table; notice circumflex as clue you're looking at contract verb, then consult lexicon.",
        ],
        englishVsGreek: [
          { english: "don't = do+not contracted", greek: "ἀγαπῶ = ἀγαπάω contracted — circumflex is apostrophe", whyItMatters: "Circumflex signals vowel merger, like apostrophe." },
        ],
        examples: [
          { greek: "ἀγαπῶμεν ἀλλήλους", literal: "we-love one-another", natural: "Let us love one another", breakdown: "Present act ind or subj 1pl? With circumflex ἀγαπῶ- = α-contract. Context decides." },
        ],
      },
      {
        id: "mi",
        title: "μι-verbs: the 12 rebels that skip the connecting vowel",
        body: [
          "Most verbs use thematic vowel ο/ε between stem and ending: λύ-ο-μεν. A dozen common verbs skip it: δί-δω-μι, τί-θη-μι, ἵ-στη-μι. They reduplicate present with ι: δι-δω-, τι-θη-, ἱ-στα-. Endings direct: -μι, -ς, -σι(ν), -μεν, -τε, -ασι(ν).",
          "Aorist often κ-aorist: ἔδωκα, ἔθηκα, ἀφῆκα. ἵστημι transitive/intransitive puzzle: active present 'I cause to stand' = I set; intransitive aorist ἔστην = I stood; perfect ἕστηκα = I am standing (state).",
          "English: be, have, do are highly irregular and common. Greek μι-verbs are same: super common, super irregular, must memorize.",
        ],
        englishVsGreek: [
          { english: "am, is, are — most common verb irregular", greek: "δίδωμι, τίθημι — most common exchange verbs irregular", whyItMatters: "Frequency breeds irregularity in all languages (Zipf's law)." },
        ],
      },
    ],
  },
  "case-syntax": {
    slug: "case-syntax",
    intro:
      "Now we move from labeling cases to arguing with them: subjective vs objective genitive can change justification theology. Syntax is exegesis.",
    sections: [
      {
        id: "genitive-33",
        title: "Genitive overload: 33 labels but 5 questions",
        body: [
          "Wallace lists 33 genitive uses. Don't memorize list; ask diagnostic questions. Is head noun a verbal idea (ἀγάπη, πίστις, γνῶσις, ζῆλος)? If yes, subjective vs objective live. Could 'of' be paraphrased as adjective? Attributive (σῶμα τῆς ἁμαρτίας = sinful body, body characterized by sin). Is it whole vs part? Partitive (τινες τῶν γραμματέων = some of the scribes). Is it 'namely'? Appositive (τὸ σημεῖον τῆς περιτομῆς = the sign, namely circumcision). Is it required by governing word? Then it's just verbal complement, no fancy label.",
          "Subjective genitive: head noun's action done BY genitive: ἡ ἀγάπη τοῦ θεοῦ = God's love for us (God loves). Objective: action done TO genitive: ὁ ζῆλος τοῦ οἴκου σου = zeal for your house (house receives zeal).",
          "English has same ambiguity: 'love of God' — does God love or is he loved? 'Fear of death' — death objective. 'John's love' — John's loving? Ambiguity is not Greek-specific; it's verbal noun + of.",
        ],
        englishVsGreek: [
          { english: "love of God — God's love? love for God?", greek: "ἀγάπη τοῦ θεοῦ — same ambiguity, needs argument", whyItMatters: "Both languages use 'of' with verbal nouns ambiguously. Context and usage decide." },
          { english: "a group of students — partitive: students = whole, group = part", greek: "τὶς τῶν μαθητῶν — partitive same", whyItMatters: "Partitive is universal cognitive relation." },
        ],
        examples: [
          { greek: "διὰ πίστεως Ἰησοῦ Χριστοῦ", literal: "through faith/faithfulness of Jesus Christ", natural: "through faith in Christ OR through Christ's faithfulness", breakdown: "Key debate: objective vs subjective. Evidence both ways: πίστις Ἀβραάμ elsewhere subjective, but πιστεύω εἰς elsewhere objective." },
        ],
        thinkLikeGreek: [
          "When you see genitive, write two translations: subjective and objective. Then argue using usage elsewhere in same author, context, redundancy.",
          "Don't label unless translation/theology changes. Over-labeling is taxonomic showmanship.",
        ],
      },
    ],
  },
  "verbal-aspect": {
    slug: "verbal-aspect",
    intro:
      "The most important grammar revolution in a century: tense-forms encode viewpoint (aspect), not time. Master this and you stop translating Greek with English tense and start reading Greek as Greek.",
    sections: [
      {
        id: "three-terms",
        title: "Three words you must not conflate: tense, aspect, Aktionsart",
        body: [
          "Tense = grammaticalized time. Does verb form itself encode past/present/future? Porter says no, even indicative time comes from context+deixis. Fanning says yes, indicative does encode time. Both agree aspect is primary.",
          "Aspect = author's chosen viewpoint. Perfective (aorist): view action as whole from outside, like dot on timeline. Imperfective (present/imperfect): view from inside, unfolding. Stative/perfect: view as state.",
          "Aktionsart = objective kind of action in reality: punctiliar, iterative, ingressive, etc. This comes from lexeme + context + adverbs, not from tense-form. Fallacy: 'Aorist means once-for-all' confuses aspect (viewpoint) with Aktionsart (real-world kind).",
          "English: 'I was walking' (imperfective aspect) could be iterative ('I was walking to school daily') or progressive ('I was walking when he arrived') — same aspect, different Aktionsart from context. Greek same.",
        ],
        englishVsGreek: [
          { english: "I have written vs I wrote — perfect vs simple past aspectual difference, both past-referring", greek: "γέγραπται vs ἔγραψα — same perfect vs aorist contrast, prominence difference", whyItMatters: "English perfect exists but Greek uses aspect more heavily, especially outside indicative." },
        ],
        examples: [
          { greek: "ἔρχεται ὁ ἰσχυρότερός μου", literal: "comes the stronger-than-me", natural: "The stronger one is coming (historic present in past narrative)", breakdown: "Present tense in past narrative is not present time; it's imperfective aspect highlighting new participant." },
          { greek: "ἐβασίλευσεν ὁ θάνατος", literal: "reigned the death", natural: "Death reigned — aorist over 40-year span, not instantaneous", breakdown: "Proves aorist not punctiliar; it's whole-view." },
        ],
        thinkLikeGreek: ["When reading narrative, ask not 'when?' but 'why this viewpoint here when another was available?'"],
      },
      {
        id: "three-schools",
        title: "Porter vs Fanning vs Campbell: where they agree matters more",
        body: [
          "Porter (1989): No Greek tense encodes time, even indicative. Three aspects: perfective (aorist), imperfective (present/imperfect), stative (perfect/pluperfect). Prominence: background (aorist) → foreground (present/imperfect) → frontground (perfect).",
          "Fanning (1990): Aspect primary but indicative does encode time. Detailed taxonomy of aspect + lexis → Aktionsart. He keeps time but subordinates it to aspect.",
          "Campbell (2007-08): Accepts non-temporal indicative, reanalyzes perfect as imperfective aspect + heightened proximity (spatial metaphor), not stative. Remoteness/proximity instead of past/present.",
          "Consensus: aspect is semantic core; English tense equivalence fails; discourse prominence uses aspect choice; no fallacious 'aorist = once-for-all'.",
        ],
      },
    ],
  },
  "discourse-grammar": {
    slug: "discourse-grammar",
    intro:
      "Above the sentence: why does Mark start with καί not δέ? Why front ὑμεῖς? Why repeat 'and answering he said'? These are not filler — they are processing instructions for hearers.",
    sections: [
      {
        id: "word-order",
        title: "Default order is Verb-first, but fronting = spotlight",
        body: [
          "Neutral Koine narrative default is VSO-ish: verb first, then subject, then object. Ἐδίδασκεν αὐτοὺς — he was teaching them. If subject comes first, it's doing pragmatic work: topic (frame) or focus (salient new info).",
          "Topic = 'as for X...' — sets frame: ἐν τῇ ὁδῷ 'on the road' (time/place frame). Focus = most important new info, just before verb: Ὑμεῖς δὲ τίνα με λέγετε εἶναι; YOU (focus) — as opposed to crowds — who do you say that I am?",
          "English does this via stress and clefts: 'YOU, who do you say I am?' vs neutral 'Who do you say I am?'. Greek does via position. Fronting is clefting.",
        ],
        englishVsGreek: [
          { english: "It's YOU who I love (cleft for focus)", greek: "Ὑμεῖς ἐστε (fronted pronoun for focus)", whyItMatters: "Both use marked syntax to spotlight contrast. Greek uses order, English uses it-cleft." },
        ],
        examples: [
          { greek: "θεὸς ἦν ὁ λόγος", literal: "God was the Word", natural: "The Word was God (with emphasis on divine quality)", breakdown: "Predicate nominative θεός fronted for qualitative emphasis. Unmarked would be ὁ λόγος ἦν θεός." },
          { greek: "καὶ εὐθὺς ἀναβαίνων ... εἶδεν", literal: "and immediately coming-up ... he-saw", natural: "And immediately coming up, he saw", breakdown: "Participle fronted before main verb is typical narrative chaining." },
        ],
      },
    ],
  },
  "fluent-reading": {
    slug: "fluent-reading",
    intro:
      "Stop decoding, start reading. Fluency is 80% extensive and 20% intensive. This lesson gives you a graded path and the audio-first method.",
    sections: [
      {
        id: "protocol",
        title: "The 95% rule: extensive reading path",
        body: [
          "Research on extensive reading suggests that below roughly 95% word coverage, reading becomes frustrating and slow. About 95–98% is a learning zone where remaining words can be inferred from context; above 98% is a fluency zone. So begin with 1 John (small vocabulary, high repetition), then John's Gospel, Mark, Matthew/Revelation, Paul's shorter letters, denser Pauline prose, and finally Luke-Acts, Hebrews, and 2 Peter.",
          "Intensive vs extensive: intensive = parse everything, look up, diagram. Builds knowledge. Extensive = fast, large volume, tolerate ambiguity, no dictionary until second pass. Builds fluency. Most students do 90% intensive, 10% extensive — reverse it.",
          "Audio-first: Listen twice no text, then listen following text, then read aloud along, then read alone aloud. Ear before eye breaks translation habit. This is how blind scholars in early church learned — hearing first.",
        ],
        englishVsGreek: [
          { english: "Child hears 10,000 hours before reading independently", greek: "You need ~100 hours of audio exposure before extensive reading feels natural", whyItMatters: "Listening bootstraps reading." },
        ],
        thinkLikeGreek: [
          "Pick 1 John, read whole chapter in one sitting without stopping, aloud if possible. Re-read next day. Only third day look up unknowns.",
          "Never sub-vocalize English. If caught translating, re-read aloud faster — speed forces direct Greek processing.",
        ],
      },
    ],
  },
  "textual-criticism": {
    slug: "textual-criticism",
    intro:
      "No original manuscripts survive. We have ~5,800 Greek copies, plus versions and patristic quotes. Textual criticism is how we infer the earliest text from this cloud of copies.",
    sections: [
      {
        id: "witnesses",
        title: "Papyri, uncials, minuscules — weighing, not counting",
        body: [
          "English has one King James Version basically. Greek NT has families: Alexandrian (shorter, harder readings, generally earliest: 𝔓75, א, B), Western (paraphrastic, especially Acts: D), Byzantine (smooth, full, majority of later minuscules).",
          "External evidence: Date (earlier generally better but not always), geographical spread (reading found in Egypt AND Italy AND Syria more valuable), genealogical relationship (manuscripts are not independent witnesses; they have parents).",
          "Internal: transcription (lectio brevior potior — scribes added not subtracted; lectio difficilior potior — scribes smoothed difficulties), also intrinsic (author's style).",
          "English parallel: if you have 5 copies of a Shakespeare play, 4 late conflating errors, 1 early messy but unique, you weigh early despite counting 4 vs 1.",
        ],
        englishVsGreek: [
          { english: "You have 5 student copies of lecture notes: 4 copied from each other late, 1 early from professor — you trust early despite minority", greek: "Byzantine majority vs Alexandrian early — same principle", whyItMatters: "Genealogy beats numerology." },
        ],
        examples: [
          { greek: "μονογενὴς θεός vs ὁ μονογενὴς υἱός (John 1:18)", literal: "only-begotten God vs only Son", natural: "Variant changes Christology", breakdown: "External: θεός has 𝔓66,75, א,B — early Alexandrian. Internal: harder reading θεός explains υἱός as smoothing (scribes preferred common 'Son' phrase)." },
          { greek: "Mark 16:9-20 absent in א, B", literal: "long ending missing", natural: "Almost certainly not original — vocabulary, style, Eusebius knowledge", breakdown: "Example of taking apparatus and arguing from internal + external." },
        ],
      },
    ],
  },
  septuagint: {
    slug: "septuagint",
    intro:
      "The Old Testament Jesus and Paul quoted was almost always Greek, not Hebrew — the Septuagint (LXX), translated in Alexandria over two centuries. Its Greek shapes NT theology vocabulary.",
    sections: [
      {
        id: "translation-greek",
        title: "Hebrew wrapped in Greek clothing — translationese",
        body: [
          "Translators often rendered Hebrew word-for-word: καὶ ἐγένετο + finite verb translates Hebrew wayehi (and it happened). Not natural Greek, but Septuagintal style. Luke imitates it deliberately to sound biblical when narrating birth of Jesus.",
          "Cognate dative hebraism: θανάτῳ ἀποθανεῖσθε 'by death you shall die' translates Hebrew infinitive absolute construction intensifying (surely die). English 'you shall surely die'.",
          "Article misuse: Hebrew has no case, so translators sometimes over- or under-use article. Prepositions like ἐν χειρί 'by hand of' for beyad — literal, unidiomatic, but becomes Christian idiom.",
          "Why it matters: NT authors use LXX words, not classical Greek meanings. κύριος = YHWH, not just sir. διαθήκη = covenant (בְּרִית) not last will. σάρξ = embodied humanity (בָּשָׂר) not just meat. To understand Paul you need LXX, not Plato.",
        ],
        englishVsGreek: [
          { english: "We say 'holy of holies' translating Hebrew superlative (not plural of holies)", greek: "LXX keeps Hebraisms like τὸ ἅγιον τῶν ἁγίων", whyItMatters: "Literal translation imports Hebrew idiom literally." },
        ],
        examples: [
          { greek: "ἐν ἀρχῇ ἐποίησεν ὁ θεὸς", literal: "in beginning made the God", natural: "In the beginning God made — Gen 1:1 LXX", breakdown: "ἐποίησεν translates עָשָׂה. Note article ὁ θεός but no article on ἀρχῇ typical Hebrew." },
          { greek: "κύριος ποιμαίνει με", literal: "Lord shepherds me", natural: "The Lord is my shepherd — Ps 22 LXX", breakdown: "κύριος renders יהוה. NT applying κύριος to Jesus invokes divine name." },
        ],
      },
    ],
  },
  "papyri-register": {
    slug: "papyri-register",
    intro:
      "1900: Adolf Deissmann finds Greek shopping lists in Egyptian rubbish and realizes they contain Paul's 'holy' vocabulary. NT Greek is not Holy Ghost language — it's everyday Koine.",
    sections: [
      {
        id: "deissmann",
        title: "Divine words in dirty papyri",
        body: [
          "Before Deissmann, scholars thought Biblical Greek was special Spirit-language. He opened Oxyrhynchus papyri: private letters saying 'I pray you are well' (ἐρρῶσθαί σε εὔχομαι) — same opening as 3 John. Words like ἀγάπη thought Christian-exclusive found in non-Christian letters.",
          "ἀρραβών = down payment/deposit in commerce (Eph 1:14 Holy Spirit is down payment). From Semitic but used daily. λειτουργία = public service funded by rich citizen (Rom 15:16 Paul's ministry). παρουσία = royal visit with preparations and new coins — background for 1 Thess 4 coming of Lord.",
          "English: we think 'church' is religious but 'assembly' is secular. Greek ἐκκλησία was civic assembly of citizens — secular. LXX applied it to Israel assembly, then church. Secular → theological shift is natural, not special word creation.",
        ],
        englishVsGreek: [
          { english: "We say 'deposit on house' in everyday life, not religious", greek: "ἀρραβών in papyri = deposit, Paul uses same commercial term", whyItMatters: "Everyday commercial life supplies NT metaphors." },
        ],
        examples: [
          { greek: "ἐρρῶσθαί σε εὔχομαι", literal: "to-be-well you I-pray", natural: "I pray that you are well — standard papyrus letter closing and 3 John 2", breakdown: "Formulaic health wish shows epistolary convention shared." },
        ],
      },
    ],
  },
  "research-toolkit": {
    slug: "research-toolkit",
    intro:
      "Lexicons, grammars, databases, method — how to turn Greek text into a defensible argument without committing the standard fallacies.",
    sections: [
      {
        id: "fallacies",
        title: "Five fallacies that kill sermons and papers",
        body: [
          "Root fallacy: ἐκκλησία = ἐκ + καλέω = called-out ones, therefore church must be called out of world. Wrong. Meaning from usage, not etymology. ἐκκλησία in Koine = assembly, civic term, regardless of components. English: 'butterfly' not from butter+fly logic.",
          "Semantic anachronism: δύναμις = dynamite, so power of God is explosive. Dynamite invented 1860s, Greek word 1000 years earlier. Anachronistic.",
          "Illegitimate totality transfer: import every sense of λόγος (word, reason, account, proportion) into John 1:1 at once. Text chooses one sense in context.",
          "Selective evidence: cite only usages supporting your reading, ignore counter-evidence.",
          "Appeal to unknown: revive rare Homeric sense for NT meaning.",
          "Cure: check BDAG first sense is most common, check same author usage first, then NT, then LXX, then contemporary papyri. Don't start with Kittel TDNT which mixes theology into lexicon.",
        ],
        englishVsGreek: [
          { english: "'Nice' once meant ignorant (Latin nescius) — don't preach that nice people are ignorant today", greek: "Etymology no longer active meaning. Meaning = current usage", whyItMatters: "Words change; usage determines meaning, not origin." },
        ],
      },
      {
        id: "workflow",
        title: "Eight-step exegetical workflow that works",
        body: [
          "1) Text: check the apparatus for variants that affect meaning. 2) Translate woodenly and transparently before consulting English versions. 3) Structure: block-diagram the passage and find the main clause. 4) Grammar: resolve material ambiguities such as genitives and participles. 5) Discourse: locate the paragraph in its argument; track connectives and prominence. 6) Lexis: study genuinely disputed terms in this order—same author → NT → LXX → contemporary Koine. 7) Context: historical, cultural, literary, and canonical. 8) Synthesis: state the author's point in one sentence. If you cannot, you are not finished. 9) Dialogue: now read commentaries and record where and why you differ.",
          "Write provisional synthesis before commentaries to avoid merely decorating someone else's exegesis with Greek.",
          "English public speaking parallel: you wouldn't read three other people's speeches before writing yours, then claim it's yours. Form own reading, then test.",
        ],
      },
    ],
  },
};

export function deepGuideFor(slug: string): DeepGuide | undefined {
  return DEEP_GUIDES[slug];
}
