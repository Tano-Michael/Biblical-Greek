export type InterWord = {
  g: string; // Greek surface form
  l: string; // lemma
  p: string; // parsing
  e: string; // English gloss
};

export type Verse = {
  ref: string;
  words: InterWord[];
  english: string;
};

export type Passage = {
  id: string;
  title: string;
  reference: string;
  level: "beginner" | "intermediate" | "advanced";
  blurb: string;
  audioNote: string;
  verses: Verse[];
};

export const PASSAGES: Passage[] = [
  {
    id: "john-1",
    title: "The Prologue",
    reference: "John 1:1-5",
    level: "beginner",
    blurb:
      "The most famous opening in Greek literature after Homer. Only 16 distinct words, almost all of them in your first vocabulary list.",
    audioNote:
      "Read each verse aloud three times before revealing the gloss. Aim for a steady, unhurried pace.",
    verses: [
      {
        ref: "1:1",
        english: "In the beginning was the Word, and the Word was with God, and the Word was God.",
        words: [
          { g: "Ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "ἀρχῇ", l: "ἀρχή", p: "noun, dat. sg. fem.", e: "beginning" },
          { g: "ἦν", l: "εἰμί", p: "verb, imperf. act. ind. 3 sg.", e: "was (continuously)" },
          { g: "ὁ", l: "ὁ", p: "article, nom. sg. masc.", e: "the" },
          { g: "λόγος", l: "λόγος", p: "noun, nom. sg. masc.", e: "Word" },
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "ὁ", l: "ὁ", p: "article, nom. sg. masc.", e: "the" },
          { g: "λόγος", l: "λόγος", p: "noun, nom. sg. masc.", e: "Word" },
          { g: "ἦν", l: "εἰμί", p: "verb, imperf. act. ind. 3 sg.", e: "was" },
          { g: "πρὸς", l: "πρός", p: "preposition + accusative", e: "with, face-to-face with" },
          { g: "τὸν", l: "ὁ", p: "article, acc. sg. masc.", e: "the" },
          { g: "θεόν", l: "θεός", p: "noun, acc. sg. masc.", e: "God" },
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "θεὸς", l: "θεός", p: "noun, nom. sg. masc. (predicate)", e: "God (qualitative)" },
          { g: "ἦν", l: "εἰμί", p: "verb, imperf. act. ind. 3 sg.", e: "was" },
          { g: "ὁ", l: "ὁ", p: "article, nom. sg. masc.", e: "the" },
          { g: "λόγος", l: "λόγος", p: "noun, nom. sg. masc. (subject)", e: "Word" },
        ],
      },
      {
        ref: "1:2",
        english: "He was in the beginning with God.",
        words: [
          { g: "οὗτος", l: "οὗτος", p: "demonstrative pron., nom. sg. masc.", e: "this one, he" },
          { g: "ἦν", l: "εἰμί", p: "verb, imperf. act. ind. 3 sg.", e: "was" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "ἀρχῇ", l: "ἀρχή", p: "noun, dat. sg. fem.", e: "beginning" },
          { g: "πρὸς", l: "πρός", p: "preposition + accusative", e: "with" },
          { g: "τὸν", l: "ὁ", p: "article, acc. sg. masc.", e: "the" },
          { g: "θεόν", l: "θεός", p: "noun, acc. sg. masc.", e: "God" },
        ],
      },
      {
        ref: "1:3",
        english:
          "All things came into being through him, and apart from him not one thing came into being that has come into being.",
        words: [
          { g: "πάντα", l: "πᾶς", p: "adjective, nom. pl. neut.", e: "all things" },
          { g: "δι᾽", l: "διά", p: "preposition + genitive", e: "through" },
          { g: "αὐτοῦ", l: "αὐτός", p: "pronoun, gen. sg. masc.", e: "him" },
          { g: "ἐγένετο", l: "γίνομαι", p: "verb, aor. mid. ind. 3 sg.", e: "came into being" },
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "χωρὶς", l: "χωρίς", p: "preposition + genitive", e: "apart from" },
          { g: "αὐτοῦ", l: "αὐτός", p: "pronoun, gen. sg. masc.", e: "him" },
          { g: "ἐγένετο", l: "γίνομαι", p: "verb, aor. mid. ind. 3 sg.", e: "came into being" },
          { g: "οὐδὲ", l: "οὐδέ", p: "conjunction", e: "not even" },
          { g: "ἕν", l: "εἷς", p: "numeral, nom. sg. neut.", e: "one thing" },
          { g: "ὃ", l: "ὅς", p: "relative pron., nom. sg. neut.", e: "which" },
          { g: "γέγονεν", l: "γίνομαι", p: "verb, perf. act. ind. 3 sg.", e: "has come into being" },
        ],
      },
      {
        ref: "1:4",
        english: "In him was life, and the life was the light of humanity.",
        words: [
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "αὐτῷ", l: "αὐτός", p: "pronoun, dat. sg. masc.", e: "him" },
          { g: "ζωὴ", l: "ζωή", p: "noun, nom. sg. fem.", e: "life" },
          { g: "ἦν", l: "εἰμί", p: "verb, imperf. act. ind. 3 sg.", e: "was" },
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "ἡ", l: "ὁ", p: "article, nom. sg. fem.", e: "the" },
          { g: "ζωὴ", l: "ζωή", p: "noun, nom. sg. fem.", e: "life" },
          { g: "ἦν", l: "εἰμί", p: "verb, imperf. act. ind. 3 sg.", e: "was" },
          { g: "τὸ", l: "ὁ", p: "article, nom. sg. neut.", e: "the" },
          { g: "φῶς", l: "φῶς", p: "noun, nom. sg. neut. (3rd decl.)", e: "light" },
          { g: "τῶν", l: "ὁ", p: "article, gen. pl. masc.", e: "of the" },
          { g: "ἀνθρώπων", l: "ἄνθρωπος", p: "noun, gen. pl. masc.", e: "human beings" },
        ],
      },
      {
        ref: "1:5",
        english: "And the light shines in the darkness, and the darkness did not overcome it.",
        words: [
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "τὸ", l: "ὁ", p: "article, nom. sg. neut.", e: "the" },
          { g: "φῶς", l: "φῶς", p: "noun, nom. sg. neut.", e: "light" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "τῇ", l: "ὁ", p: "article, dat. sg. fem.", e: "the" },
          { g: "σκοτίᾳ", l: "σκοτία", p: "noun, dat. sg. fem.", e: "darkness" },
          { g: "φαίνει", l: "φαίνω", p: "verb, pres. act. ind. 3 sg.", e: "shines" },
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "ἡ", l: "ὁ", p: "article, nom. sg. fem.", e: "the" },
          { g: "σκοτία", l: "σκοτία", p: "noun, nom. sg. fem.", e: "darkness" },
          { g: "αὐτὸ", l: "αὐτός", p: "pronoun, acc. sg. neut.", e: "it" },
          { g: "οὐ", l: "οὐ", p: "negative particle", e: "not" },
          { g: "κατέλαβεν", l: "καταλαμβάνω", p: "verb, aor. act. ind. 3 sg.", e: "overcame / grasped" },
        ],
      },
    ],
  },
  {
    id: "lords-prayer",
    title: "The Lord's Prayer",
    reference: "Matthew 6:9-13",
    level: "beginner",
    blurb:
      "Third-person imperatives, an aorist imperative, and the famously untranslatable ἐπιούσιος. Learn it by heart.",
    audioNote: "Memorise one clause per day. Say it aloud from memory before reading.",
    verses: [
      {
        ref: "6:9",
        english: "Our Father in the heavens, let your name be hallowed;",
        words: [
          { g: "Πάτερ", l: "πατήρ", p: "noun, voc. sg. masc. (3rd decl.)", e: "Father!" },
          { g: "ἡμῶν", l: "ἐγώ", p: "pronoun, gen. pl.", e: "our" },
          { g: "ὁ", l: "ὁ", p: "article, nom. sg. masc.", e: "the one" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "τοῖς", l: "ὁ", p: "article, dat. pl. masc.", e: "the" },
          { g: "οὐρανοῖς", l: "οὐρανός", p: "noun, dat. pl. masc.", e: "heavens" },
          { g: "ἁγιασθήτω", l: "ἁγιάζω", p: "verb, aor. pass. imperative 3 sg.", e: "let it be hallowed" },
          { g: "τὸ", l: "ὁ", p: "article, nom. sg. neut.", e: "the" },
          { g: "ὄνομά", l: "ὄνομα", p: "noun, nom. sg. neut. (3rd decl.)", e: "name" },
          { g: "σου", l: "σύ", p: "pronoun, gen. sg.", e: "your" },
        ],
      },
      {
        ref: "6:10",
        english: "let your kingdom come; let your will be done, as in heaven so also on earth.",
        words: [
          { g: "ἐλθέτω", l: "ἔρχομαι", p: "verb, aor. act. imperative 3 sg.", e: "let it come" },
          { g: "ἡ", l: "ὁ", p: "article, nom. sg. fem.", e: "the" },
          { g: "βασιλεία", l: "βασιλεία", p: "noun, nom. sg. fem.", e: "kingdom" },
          { g: "σου", l: "σύ", p: "pronoun, gen. sg.", e: "your" },
          { g: "γενηθήτω", l: "γίνομαι", p: "verb, aor. pass. imperative 3 sg.", e: "let it be done" },
          { g: "τὸ", l: "ὁ", p: "article, nom. sg. neut.", e: "the" },
          { g: "θέλημά", l: "θέλημα", p: "noun, nom. sg. neut. (3rd decl.)", e: "will" },
          { g: "σου", l: "σύ", p: "pronoun, gen. sg.", e: "your" },
          { g: "ὡς", l: "ὡς", p: "conjunction", e: "as" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "οὐρανῷ", l: "οὐρανός", p: "noun, dat. sg. masc.", e: "heaven" },
          { g: "καὶ", l: "καί", p: "adverbial", e: "also" },
          { g: "ἐπὶ", l: "ἐπί", p: "preposition + genitive", e: "on" },
          { g: "γῆς", l: "γῆ", p: "noun, gen. sg. fem.", e: "earth" },
        ],
      },
      {
        ref: "6:11",
        english: "Give us today our daily bread;",
        words: [
          { g: "τὸν", l: "ὁ", p: "article, acc. sg. masc.", e: "the" },
          { g: "ἄρτον", l: "ἄρτος", p: "noun, acc. sg. masc.", e: "bread" },
          { g: "ἡμῶν", l: "ἐγώ", p: "pronoun, gen. pl.", e: "our" },
          { g: "τὸν", l: "ὁ", p: "article, acc. sg. masc.", e: "the" },
          { g: "ἐπιούσιον", l: "ἐπιούσιος", p: "adjective, acc. sg. masc.", e: "daily / necessary (a famous crux)" },
          { g: "δὸς", l: "δίδωμι", p: "verb, aor. act. imperative 2 sg.", e: "give!" },
          { g: "ἡμῖν", l: "ἐγώ", p: "pronoun, dat. pl.", e: "to us" },
          { g: "σήμερον", l: "σήμερον", p: "adverb", e: "today" },
        ],
      },
      {
        ref: "6:12",
        english: "and forgive us our debts, as we also have forgiven our debtors;",
        words: [
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "ἄφες", l: "ἀφίημι", p: "verb, aor. act. imperative 2 sg.", e: "forgive!" },
          { g: "ἡμῖν", l: "ἐγώ", p: "pronoun, dat. pl.", e: "us" },
          { g: "τὰ", l: "ὁ", p: "article, acc. pl. neut.", e: "the" },
          { g: "ὀφειλήματα", l: "ὀφείλημα", p: "noun, acc. pl. neut.", e: "debts" },
          { g: "ἡμῶν", l: "ἐγώ", p: "pronoun, gen. pl.", e: "our" },
          { g: "ὡς", l: "ὡς", p: "conjunction", e: "as" },
          { g: "καὶ", l: "καί", p: "adverbial", e: "also" },
          { g: "ἡμεῖς", l: "ἐγώ", p: "pronoun, nom. pl. (emphatic)", e: "we" },
          { g: "ἀφήκαμεν", l: "ἀφίημι", p: "verb, aor. act. ind. 1 pl.", e: "have forgiven" },
          { g: "τοῖς", l: "ὁ", p: "article, dat. pl. masc.", e: "the" },
          { g: "ὀφειλέταις", l: "ὀφειλέτης", p: "noun, dat. pl. masc.", e: "debtors" },
          { g: "ἡμῶν", l: "ἐγώ", p: "pronoun, gen. pl.", e: "our" },
        ],
      },
      {
        ref: "6:13",
        english: "and do not bring us into testing, but deliver us from the evil one.",
        words: [
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "μὴ", l: "μή", p: "negative particle", e: "not" },
          { g: "εἰσενέγκῃς", l: "εἰσφέρω", p: "verb, aor. act. subj. 2 sg. (prohibition)", e: "bring in" },
          { g: "ἡμᾶς", l: "ἐγώ", p: "pronoun, acc. pl.", e: "us" },
          { g: "εἰς", l: "εἰς", p: "preposition + accusative", e: "into" },
          { g: "πειρασμόν", l: "πειρασμός", p: "noun, acc. sg. masc.", e: "testing, temptation" },
          { g: "ἀλλὰ", l: "ἀλλά", p: "conjunction", e: "but" },
          { g: "ῥῦσαι", l: "ῥύομαι", p: "verb, aor. mid. imperative 2 sg.", e: "rescue!" },
          { g: "ἡμᾶς", l: "ἐγώ", p: "pronoun, acc. pl.", e: "us" },
          { g: "ἀπὸ", l: "ἀπό", p: "preposition + genitive", e: "from" },
          { g: "τοῦ", l: "ὁ", p: "article, gen. sg. masc.", e: "the" },
          { g: "πονηροῦ", l: "πονηρός", p: "adjective, gen. sg. masc. (substantival)", e: "evil one / evil" },
        ],
      },
    ],
  },
  {
    id: "mark-1",
    title: "The Beginning of the Gospel",
    reference: "Mark 1:1-4",
    level: "intermediate",
    blurb:
      "A chain of genitives, a perfect passive, and Mark's characteristic parataxis. Also the LUMO film chapter in the Advanced track.",
    audioNote: "Compare your reading with the LUMO Mark film and the Robinson audio in the Library.",
    verses: [
      {
        ref: "1:1",
        english: "The beginning of the gospel of Jesus Christ, the Son of God.",
        words: [
          { g: "Ἀρχὴ", l: "ἀρχή", p: "noun, nom. sg. fem.", e: "beginning" },
          { g: "τοῦ", l: "ὁ", p: "article, gen. sg. neut.", e: "of the" },
          { g: "εὐαγγελίου", l: "εὐαγγέλιον", p: "noun, gen. sg. neut.", e: "gospel" },
          { g: "Ἰησοῦ", l: "Ἰησοῦς", p: "noun, gen. sg. masc.", e: "of Jesus" },
          { g: "Χριστοῦ", l: "Χριστός", p: "noun, gen. sg. masc.", e: "Christ" },
          { g: "υἱοῦ", l: "υἱός", p: "noun, gen. sg. masc. (apposition)", e: "Son" },
          { g: "θεοῦ", l: "θεός", p: "noun, gen. sg. masc.", e: "of God" },
        ],
      },
      {
        ref: "1:2",
        english:
          "As it stands written in Isaiah the prophet: Behold, I send my messenger before your face, who will prepare your way;",
        words: [
          { g: "Καθὼς", l: "καθώς", p: "conjunction", e: "just as" },
          { g: "γέγραπται", l: "γράφω", p: "verb, perf. pass. ind. 3 sg.", e: "it stands written" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "τῷ", l: "ὁ", p: "article, dat. sg. masc.", e: "the" },
          { g: "Ἠσαΐᾳ", l: "Ἠσαΐας", p: "noun, dat. sg. masc.", e: "Isaiah" },
          { g: "τῷ", l: "ὁ", p: "article, dat. sg. masc.", e: "the" },
          { g: "προφήτῃ", l: "προφήτης", p: "noun, dat. sg. masc. (1st decl. masc.)", e: "prophet" },
          { g: "Ἰδοὺ", l: "ἰδού", p: "particle", e: "behold!" },
          { g: "ἀποστέλλω", l: "ἀποστέλλω", p: "verb, pres. act. ind. 1 sg.", e: "I send" },
          { g: "τὸν", l: "ὁ", p: "article, acc. sg. masc.", e: "the" },
          { g: "ἄγγελόν", l: "ἄγγελος", p: "noun, acc. sg. masc.", e: "messenger" },
          { g: "μου", l: "ἐγώ", p: "pronoun, gen. sg.", e: "my" },
          { g: "πρὸ", l: "πρό", p: "preposition + genitive", e: "before" },
          { g: "προσώπου", l: "πρόσωπον", p: "noun, gen. sg. neut.", e: "face" },
          { g: "σου", l: "σύ", p: "pronoun, gen. sg.", e: "your" },
        ],
      },
      {
        ref: "1:3",
        english:
          "a voice of one crying in the wilderness: Prepare the way of the Lord, make his paths straight.",
        words: [
          { g: "φωνὴ", l: "φωνή", p: "noun, nom. sg. fem.", e: "a voice" },
          { g: "βοῶντος", l: "βοάω", p: "pres. act. participle, gen. sg. masc.", e: "of one crying out" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "τῇ", l: "ὁ", p: "article, dat. sg. fem.", e: "the" },
          { g: "ἐρήμῳ", l: "ἔρημος", p: "adjective used as noun, dat. sg. fem.", e: "wilderness" },
          { g: "Ἑτοιμάσατε", l: "ἑτοιμάζω", p: "verb, aor. act. imperative 2 pl.", e: "prepare!" },
          { g: "τὴν", l: "ὁ", p: "article, acc. sg. fem.", e: "the" },
          { g: "ὁδὸν", l: "ὁδός", p: "noun, acc. sg. fem. (2nd decl. fem.)", e: "way" },
          { g: "κυρίου", l: "κύριος", p: "noun, gen. sg. masc.", e: "of the Lord" },
          { g: "εὐθείας", l: "εὐθύς", p: "adjective, acc. pl. fem.", e: "straight" },
          { g: "ποιεῖτε", l: "ποιέω", p: "verb, pres. act. imperative 2 pl.", e: "make!" },
          { g: "τὰς", l: "ὁ", p: "article, acc. pl. fem.", e: "the" },
          { g: "τρίβους", l: "τρίβος", p: "noun, acc. pl. fem.", e: "paths" },
          { g: "αὐτοῦ", l: "αὐτός", p: "pronoun, gen. sg. masc.", e: "his" },
        ],
      },
      {
        ref: "1:4",
        english:
          "John the baptiser appeared in the wilderness, proclaiming a baptism of repentance for the forgiveness of sins.",
        words: [
          { g: "ἐγένετο", l: "γίνομαι", p: "verb, aor. mid. ind. 3 sg.", e: "appeared, came" },
          { g: "Ἰωάννης", l: "Ἰωάννης", p: "noun, nom. sg. masc.", e: "John" },
          { g: "ὁ", l: "ὁ", p: "article, nom. sg. masc.", e: "the" },
          { g: "βαπτίζων", l: "βαπτίζω", p: "pres. act. participle, nom. sg. masc. (substantival)", e: "baptiser" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "τῇ", l: "ὁ", p: "article, dat. sg. fem.", e: "the" },
          { g: "ἐρήμῳ", l: "ἔρημος", p: "noun, dat. sg. fem.", e: "wilderness" },
          { g: "κηρύσσων", l: "κηρύσσω", p: "pres. act. participle, nom. sg. masc. (adverbial)", e: "proclaiming" },
          { g: "βάπτισμα", l: "βάπτισμα", p: "noun, acc. sg. neut. (3rd decl.)", e: "a baptism" },
          { g: "μετανοίας", l: "μετάνοια", p: "noun, gen. sg. fem.", e: "of repentance" },
          { g: "εἰς", l: "εἰς", p: "preposition + accusative", e: "for" },
          { g: "ἄφεσιν", l: "ἄφεσις", p: "noun, acc. sg. fem. (3rd decl.)", e: "forgiveness" },
          { g: "ἁμαρτιῶν", l: "ἁμαρτία", p: "noun, gen. pl. fem.", e: "of sins" },
        ],
      },
    ],
  },
  {
    id: "phil-2",
    title: "The Christ Hymn",
    reference: "Philippians 2:5-8",
    level: "advanced",
    blurb:
      "The hardest short passage in the New Testament: ἁρπαγμόν, ἐκένωσεν, μορφή vs. σχῆμα, and a chain of participles.",
    audioNote:
      "Read it as poetry. Notice the rhythm of the participial clauses building to θανάτου δὲ σταυροῦ.",
    verses: [
      {
        ref: "2:5",
        english: "Have this mind among yourselves, which is also in Christ Jesus,",
        words: [
          { g: "τοῦτο", l: "οὗτος", p: "demonstrative, acc. sg. neut.", e: "this" },
          { g: "φρονεῖτε", l: "φρονέω", p: "verb, pres. act. imperative 2 pl.", e: "think, be minded" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "among / in" },
          { g: "ὑμῖν", l: "σύ", p: "pronoun, dat. pl.", e: "you" },
          { g: "ὃ", l: "ὅς", p: "relative pron., nom. sg. neut.", e: "which" },
          { g: "καὶ", l: "καί", p: "adverbial", e: "also" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "Χριστῷ", l: "Χριστός", p: "noun, dat. sg. masc.", e: "Christ" },
          { g: "Ἰησοῦ", l: "Ἰησοῦς", p: "noun, dat. sg. masc.", e: "Jesus" },
        ],
      },
      {
        ref: "2:6",
        english:
          "who, existing in the form of God, did not consider equality with God something to be exploited,",
        words: [
          { g: "ὃς", l: "ὅς", p: "relative pron., nom. sg. masc.", e: "who" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "μορφῇ", l: "μορφή", p: "noun, dat. sg. fem.", e: "form, essential nature" },
          { g: "θεοῦ", l: "θεός", p: "noun, gen. sg. masc.", e: "of God" },
          { g: "ὑπάρχων", l: "ὑπάρχω", p: "pres. act. participle, nom. sg. masc. (concessive)", e: "although existing" },
          { g: "οὐχ", l: "οὐ", p: "negative", e: "not" },
          { g: "ἁρπαγμὸν", l: "ἁρπαγμός", p: "noun, acc. sg. masc.", e: "a thing to be seized/exploited" },
          { g: "ἡγήσατο", l: "ἡγέομαι", p: "verb, aor. mid. ind. 3 sg.", e: "considered" },
          { g: "τὸ", l: "ὁ", p: "article, acc. sg. neut. (articular infinitive)", e: "the" },
          { g: "εἶναι", l: "εἰμί", p: "pres. act. infinitive", e: "to be" },
          { g: "ἴσα", l: "ἴσος", p: "adjective, acc. pl. neut. (adverbial)", e: "equal" },
          { g: "θεῷ", l: "θεός", p: "noun, dat. sg. masc.", e: "with God" },
        ],
      },
      {
        ref: "2:7",
        english:
          "but emptied himself, taking the form of a slave, coming to be in the likeness of humanity;",
        words: [
          { g: "ἀλλὰ", l: "ἀλλά", p: "conjunction", e: "but" },
          { g: "ἑαυτὸν", l: "ἑαυτοῦ", p: "reflexive pron., acc. sg. masc.", e: "himself" },
          { g: "ἐκένωσεν", l: "κενόω", p: "verb, aor. act. ind. 3 sg.", e: "emptied" },
          { g: "μορφὴν", l: "μορφή", p: "noun, acc. sg. fem.", e: "form" },
          { g: "δούλου", l: "δοῦλος", p: "noun, gen. sg. masc.", e: "of a slave" },
          { g: "λαβών", l: "λαμβάνω", p: "aor. act. participle, nom. sg. masc. (means)", e: "by taking" },
          { g: "ἐν", l: "ἐν", p: "preposition + dative", e: "in" },
          { g: "ὁμοιώματι", l: "ὁμοίωμα", p: "noun, dat. sg. neut. (3rd decl.)", e: "likeness" },
          { g: "ἀνθρώπων", l: "ἄνθρωπος", p: "noun, gen. pl. masc.", e: "of human beings" },
          { g: "γενόμενος", l: "γίνομαι", p: "aor. mid. participle, nom. sg. masc.", e: "coming to be" },
        ],
      },
      {
        ref: "2:8",
        english:
          "and being found in appearance as a human being, he humbled himself, becoming obedient to the point of death — even death on a cross.",
        words: [
          { g: "καὶ", l: "καί", p: "conjunction", e: "and" },
          { g: "σχήματι", l: "σχῆμα", p: "noun, dat. sg. neut.", e: "in outward appearance" },
          { g: "εὑρεθεὶς", l: "εὑρίσκω", p: "aor. pass. participle, nom. sg. masc.", e: "being found" },
          { g: "ὡς", l: "ὡς", p: "conjunction", e: "as" },
          { g: "ἄνθρωπος", l: "ἄνθρωπος", p: "noun, nom. sg. masc.", e: "a human being" },
          { g: "ἐταπείνωσεν", l: "ταπεινόω", p: "verb, aor. act. ind. 3 sg.", e: "humbled" },
          { g: "ἑαυτὸν", l: "ἑαυτοῦ", p: "reflexive pron., acc. sg. masc.", e: "himself" },
          { g: "γενόμενος", l: "γίνομαι", p: "aor. mid. participle, nom. sg. masc.", e: "becoming" },
          { g: "ὑπήκοος", l: "ὑπήκοος", p: "adjective, nom. sg. masc.", e: "obedient" },
          { g: "μέχρι", l: "μέχρι", p: "preposition + genitive", e: "as far as" },
          { g: "θανάτου", l: "θάνατος", p: "noun, gen. sg. masc.", e: "death" },
          { g: "θανάτου", l: "θάνατος", p: "noun, gen. sg. masc. (apposition)", e: "death" },
          { g: "δὲ", l: "δέ", p: "conjunction (ascensive)", e: "and indeed" },
          { g: "σταυροῦ", l: "σταυρός", p: "noun, gen. sg. masc.", e: "of a cross" },
        ],
      },
    ],
  },
];

export const PASSAGES_BY_ID: Record<string, Passage> = Object.fromEntries(
  PASSAGES.map((p) => [p.id, p]),
);
