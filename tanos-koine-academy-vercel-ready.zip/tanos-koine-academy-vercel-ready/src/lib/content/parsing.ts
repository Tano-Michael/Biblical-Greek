export type NounDrill = {
  kind: "noun";
  form: string;
  lemma: string;
  gloss: string;
  case: string;
  number: string;
  gender: string;
  note?: string;
};

export type VerbDrill = {
  kind: "verb";
  form: string;
  lemma: string;
  gloss: string;
  tense: string;
  voice: string;
  mood: string;
  person: string;
  number: string;
  note?: string;
};

export type Drill = NounDrill | VerbDrill;

export const CASES = ["Nominative", "Genitive", "Dative", "Accusative", "Vocative"];
export const NUMBERS = ["Singular", "Plural"];
export const GENDERS = ["Masculine", "Feminine", "Neuter"];
export const TENSES = ["Present", "Imperfect", "Future", "Aorist", "Perfect", "Pluperfect"];
export const VOICES = ["Active", "Middle", "Passive", "Middle/Passive"];
export const MOODS = ["Indicative", "Subjunctive", "Imperative", "Infinitive", "Participle", "Optative"];
export const PERSONS = ["1st", "2nd", "3rd"];

const n = (
  form: string,
  lemma: string,
  gloss: string,
  c: string,
  num: string,
  g: string,
  note?: string,
): NounDrill => ({ kind: "noun", form, lemma, gloss, case: c, number: num, gender: g, note });

const v = (
  form: string,
  lemma: string,
  gloss: string,
  tense: string,
  voice: string,
  mood: string,
  person: string,
  num: string,
  note?: string,
): VerbDrill => ({ kind: "verb", form, lemma, gloss, tense, voice, mood, person, number: num, note });

export const NOUN_DRILLS: NounDrill[] = [
  n("λόγου", "λόγος", "of a word", "Genitive", "Singular", "Masculine", "2nd declension -ου"),
  n("λόγῳ", "λόγος", "to/by a word", "Dative", "Singular", "Masculine", "iota subscript = dative sg."),
  n("λόγους", "λόγος", "words (obj.)", "Accusative", "Plural", "Masculine"),
  n("ἀνθρώπων", "ἄνθρωπος", "of people", "Genitive", "Plural", "Masculine", "-ων is genitive plural in every declension"),
  n("ἀνθρώποις", "ἄνθρωπος", "to/for people", "Dative", "Plural", "Masculine"),
  n("ἄνθρωπε", "ἄνθρωπος", "O man!", "Vocative", "Singular", "Masculine", "direct address"),
  n("ἔργα", "ἔργον", "works", "Accusative", "Plural", "Neuter", "neuter nom. and acc. are identical"),
  n("ἔργῳ", "ἔργον", "in a work", "Dative", "Singular", "Neuter"),
  n("ἡμέρας", "ἡμέρα", "of a day / days", "Genitive", "Singular", "Feminine", "also acc. pl. — ambiguous"),
  n("ἡμέρᾳ", "ἡμέρα", "on a day", "Dative", "Singular", "Feminine"),
  n("δόξης", "δόξα", "of glory", "Genitive", "Singular", "Feminine", "α-impure: α → η in gen./dat. sg."),
  n("δόξῃ", "δόξα", "in glory", "Dative", "Singular", "Feminine"),
  n("γραφαί", "γραφή", "writings", "Nominative", "Plural", "Feminine"),
  n("βασιλείας", "βασιλεία", "of a kingdom", "Genitive", "Singular", "Feminine"),
  n("καρδίαις", "καρδία", "in hearts", "Dative", "Plural", "Feminine"),
  n("πνεύματος", "πνεῦμα", "of a spirit", "Genitive", "Singular", "Neuter", "3rd declension -ματ stem"),
  n("πνεύματι", "πνεῦμα", "by/in the Spirit", "Dative", "Singular", "Neuter"),
  n("πνεύμασιν", "πνεῦμα", "to spirits", "Dative", "Plural", "Neuter", "stem + σι, dental drops"),
  n("ὀνόματι", "ὄνομα", "in the name", "Dative", "Singular", "Neuter"),
  n("σαρκός", "σάρξ", "of flesh", "Genitive", "Singular", "Feminine", "3rd declension guttural stem"),
  n("σαρξίν", "σάρξ", "to fleshes", "Dative", "Plural", "Feminine", "κ + σ = ξ"),
  n("πίστεως", "πίστις", "of faith", "Genitive", "Singular", "Feminine", "-ις/-εως class"),
  n("πίστει", "πίστις", "by faith", "Dative", "Singular", "Feminine"),
  n("πόλεις", "πόλις", "cities", "Accusative", "Plural", "Feminine", "also nom. pl. — ambiguous"),
  n("πατρός", "πατήρ", "of a father", "Genitive", "Singular", "Masculine", "syncopated stem πατρ-"),
  n("πατράσιν", "πατήρ", "to fathers", "Dative", "Plural", "Masculine"),
  n("γυναικός", "γυνή", "of a woman", "Genitive", "Singular", "Feminine"),
  n("ἀνδρῶν", "ἀνήρ", "of men", "Genitive", "Plural", "Masculine"),
  n("χάριτος", "χάρις", "of grace", "Genitive", "Singular", "Feminine"),
  n("βασιλέως", "βασιλεύς", "of a king", "Genitive", "Singular", "Masculine", "-ευς class"),
  n("βασιλεῦσιν", "βασιλεύς", "to kings", "Dative", "Plural", "Masculine"),
  n("φωτός", "φῶς", "of light", "Genitive", "Singular", "Neuter"),
  n("σώματα", "σῶμα", "bodies", "Nominative", "Plural", "Neuter", "also accusative plural"),
  n("υἱῷ", "υἱός", "to a son", "Dative", "Singular", "Masculine"),
  n("κυρίῳ", "κύριος", "to the Lord", "Dative", "Singular", "Masculine"),
  n("ἁμαρτιῶν", "ἁμαρτία", "of sins", "Genitive", "Plural", "Feminine"),
  n("ὁδόν", "ὁδός", "way (obj.)", "Accusative", "Singular", "Feminine", "2nd declension but feminine!"),
  n("αἰῶνας", "αἰών", "ages (obj.)", "Accusative", "Plural", "Masculine"),
  n("ἐκκλησίαις", "ἐκκλησία", "to the churches", "Dative", "Plural", "Feminine"),
  n("ζωήν", "ζωή", "life (obj.)", "Accusative", "Singular", "Feminine"),
];

export const VERB_DRILLS: VerbDrill[] = [
  v("λύομεν", "λύω", "we loose", "Present", "Active", "Indicative", "1st", "Plural"),
  v("λύεις", "λύω", "you loose", "Present", "Active", "Indicative", "2nd", "Singular"),
  v("λύουσιν", "λύω", "they loose", "Present", "Active", "Indicative", "3rd", "Plural", "movable nu"),
  v("ἔλυον", "λύω", "I was loosing", "Imperfect", "Active", "Indicative", "1st", "Singular", "also 3rd plural — ambiguous"),
  v("ἐλύετε", "λύω", "you were loosing", "Imperfect", "Active", "Indicative", "2nd", "Plural"),
  v("λύσω", "λύω", "I will loose", "Future", "Active", "Indicative", "1st", "Singular", "σ marks the future"),
  v("ἔλυσαν", "λύω", "they loosed", "Aorist", "Active", "Indicative", "3rd", "Plural", "augment + σα"),
  v("ἐλύσαμεν", "λύω", "we loosed", "Aorist", "Active", "Indicative", "1st", "Plural"),
  v("λέλυκα", "λύω", "I have loosed", "Perfect", "Active", "Indicative", "1st", "Singular", "reduplication + κα"),
  v("λύεται", "λύω", "he is loosed", "Present", "Middle/Passive", "Indicative", "3rd", "Singular"),
  v("λυόμεθα", "λύω", "we are loosed", "Present", "Middle/Passive", "Indicative", "1st", "Plural"),
  v("ἐλύθη", "λύω", "he was loosed", "Aorist", "Passive", "Indicative", "3rd", "Singular", "θη marks the aorist passive"),
  v("λυθήσονται", "λύω", "they will be loosed", "Future", "Passive", "Indicative", "3rd", "Plural"),
  v("λύσῃς", "λύω", "you may loose", "Aorist", "Active", "Subjunctive", "2nd", "Singular", "no augment + lengthened vowel"),
  v("λύωμεν", "λύω", "let us loose", "Present", "Active", "Subjunctive", "1st", "Plural", "hortatory"),
  v("λῦσον", "λύω", "loose!", "Aorist", "Active", "Imperative", "2nd", "Singular"),
  v("λύετε", "λύω", "keep loosing!", "Present", "Active", "Imperative", "2nd", "Plural", "same form as the indicative — context decides"),
  v("πιστεύει", "πιστεύω", "he believes", "Present", "Active", "Indicative", "3rd", "Singular"),
  v("ἐπίστευσαν", "πιστεύω", "they believed", "Aorist", "Active", "Indicative", "3rd", "Plural"),
  v("πεπίστευκεν", "πιστεύω", "he has believed", "Perfect", "Active", "Indicative", "3rd", "Singular"),
  v("ἀκούετε", "ἀκούω", "you hear", "Present", "Active", "Indicative", "2nd", "Plural"),
  v("ἤκουσεν", "ἀκούω", "he heard", "Aorist", "Active", "Indicative", "3rd", "Singular", "α lengthens to η"),
  v("ἐγένετο", "γίνομαι", "it happened", "Aorist", "Middle", "Indicative", "3rd", "Singular"),
  v("γίνονται", "γίνομαι", "they become", "Present", "Middle", "Indicative", "3rd", "Plural"),
  v("ἦλθεν", "ἔρχομαι", "he came", "Aorist", "Active", "Indicative", "3rd", "Singular", "2nd aorist, suppletive stem"),
  v("ἔρχεται", "ἔρχομαι", "he comes", "Present", "Middle", "Indicative", "3rd", "Singular"),
  v("εἶπον", "λέγω", "I said", "Aorist", "Active", "Indicative", "1st", "Singular", "2nd aorist; also 3rd plural"),
  v("λέγουσιν", "λέγω", "they say", "Present", "Active", "Indicative", "3rd", "Plural"),
  v("ἔλαβεν", "λαμβάνω", "he took", "Aorist", "Active", "Indicative", "3rd", "Singular", "2nd aorist"),
  v("γέγραπται", "γράφω", "it stands written", "Perfect", "Middle/Passive", "Indicative", "3rd", "Singular"),
  v("ἐγράψαμεν", "γράφω", "we wrote", "Aorist", "Active", "Indicative", "1st", "Plural", "π + σ = ψ"),
  v("ἀγαπῶμεν", "ἀγαπάω", "we love", "Present", "Active", "Indicative", "1st", "Plural", "α-contract: αο → ω"),
  v("ποιεῖ", "ποιέω", "he does", "Present", "Active", "Indicative", "3rd", "Singular", "ε-contract: εει → ει"),
  v("ἐποίησαν", "ποιέω", "they did", "Aorist", "Active", "Indicative", "3rd", "Plural"),
  v("δίδωσιν", "δίδωμι", "he gives", "Present", "Active", "Indicative", "3rd", "Singular", "μι-verb"),
  v("ἔδωκεν", "δίδωμι", "he gave", "Aorist", "Active", "Indicative", "3rd", "Singular", "κ-aorist"),
  v("ἐδόθη", "δίδωμι", "it was given", "Aorist", "Passive", "Indicative", "3rd", "Singular"),
  v("ἐστίν", "εἰμί", "he/she/it is", "Present", "Active", "Indicative", "3rd", "Singular"),
  v("ἦσαν", "εἰμί", "they were", "Imperfect", "Active", "Indicative", "3rd", "Plural"),
  v("ἀπεκρίθη", "ἀποκρίνομαι", "he answered", "Aorist", "Passive", "Indicative", "3rd", "Singular", "θη-form with middle sense"),
  v("ἐβαπτίσθη", "βαπτίζω", "he was baptised", "Aorist", "Passive", "Indicative", "3rd", "Singular"),
  v("σωθήσεται", "σῴζω", "he will be saved", "Future", "Passive", "Indicative", "3rd", "Singular"),
  v("ἐδίδασκεν", "διδάσκω", "he was teaching", "Imperfect", "Active", "Indicative", "3rd", "Singular"),
  v("μενεῖ", "μένω", "he will remain", "Future", "Active", "Indicative", "3rd", "Singular", "liquid future — note the circumflex"),
  v("ἀπέστειλεν", "ἀποστέλλω", "he sent", "Aorist", "Active", "Indicative", "3rd", "Singular", "liquid aorist, no σ"),
  v("ἐγήγερται", "ἐγείρω", "he has been raised", "Perfect", "Middle/Passive", "Indicative", "3rd", "Singular"),
  v("δύναται", "δύναμαι", "he is able", "Present", "Middle", "Indicative", "3rd", "Singular"),
  v("οἴδαμεν", "οἶδα", "we know", "Perfect", "Active", "Indicative", "1st", "Plural", "perfect with present meaning"),
];

export const ALL_DRILLS: Drill[] = [...NOUN_DRILLS, ...VERB_DRILLS];
