export type Letter = {
  upper: string;
  lower: string;
  name: string;
  greekName: string;
  translit: string;
  erasmian: string;
  koine: string;
  modern: string;
  numeric: number;
  example: string;
  exampleGloss: string;
  type: "vowel" | "consonant";
};

export const ALPHABET: Letter[] = [
  { upper: "Α", lower: "α", name: "alpha", greekName: "ἄλφα", translit: "a", erasmian: "a as in father", koine: "a as in father", modern: "a", numeric: 1, example: "ἀγάπη", exampleGloss: "love", type: "vowel" },
  { upper: "Β", lower: "β", name: "beta", greekName: "βῆτα", translit: "b / v", erasmian: "b as in ball", koine: "v as in vine", modern: "v", numeric: 2, example: "βασιλεία", exampleGloss: "kingdom", type: "consonant" },
  { upper: "Γ", lower: "γ", name: "gamma", greekName: "γάμμα", translit: "g", erasmian: "g as in gone", koine: "soft gh / y", modern: "gh / y", numeric: 3, example: "γραφή", exampleGloss: "writing, Scripture", type: "consonant" },
  { upper: "Δ", lower: "δ", name: "delta", greekName: "δέλτα", translit: "d", erasmian: "d as in dog", koine: "th as in this", modern: "th (this)", numeric: 4, example: "δόξα", exampleGloss: "glory", type: "consonant" },
  { upper: "Ε", lower: "ε", name: "epsilon", greekName: "ἒ ψιλόν", translit: "e", erasmian: "e as in met", koine: "e as in met", modern: "e", numeric: 5, example: "ἐκκλησία", exampleGloss: "assembly, church", type: "vowel" },
  { upper: "Ζ", lower: "ζ", name: "zeta", greekName: "ζῆτα", translit: "z", erasmian: "dz as in adze", koine: "z as in zoo", modern: "z", numeric: 7, example: "ζωή", exampleGloss: "life", type: "consonant" },
  { upper: "Η", lower: "η", name: "eta", greekName: "ἦτα", translit: "ē", erasmian: "ay as in obey", koine: "ee as in see", modern: "ee", numeric: 8, example: "ἡμέρα", exampleGloss: "day", type: "vowel" },
  { upper: "Θ", lower: "θ", name: "theta", greekName: "θῆτα", translit: "th", erasmian: "th as in thing", koine: "th as in thing", modern: "th (thing)", numeric: 9, example: "θεός", exampleGloss: "God", type: "consonant" },
  { upper: "Ι", lower: "ι", name: "iota", greekName: "ἰῶτα", translit: "i", erasmian: "i as in machine", koine: "i as in machine", modern: "ee", numeric: 10, example: "Ἰησοῦς", exampleGloss: "Jesus", type: "vowel" },
  { upper: "Κ", lower: "κ", name: "kappa", greekName: "κάππα", translit: "k", erasmian: "k as in king", koine: "k as in king", modern: "k", numeric: 20, example: "κύριος", exampleGloss: "Lord", type: "consonant" },
  { upper: "Λ", lower: "λ", name: "lambda", greekName: "λάμβδα", translit: "l", erasmian: "l as in law", koine: "l as in law", modern: "l", numeric: 30, example: "λόγος", exampleGloss: "word", type: "consonant" },
  { upper: "Μ", lower: "μ", name: "mu", greekName: "μῦ", translit: "m", erasmian: "m as in man", koine: "m as in man", modern: "m", numeric: 40, example: "μαθητής", exampleGloss: "disciple", type: "consonant" },
  { upper: "Ν", lower: "ν", name: "nu", greekName: "νῦ", translit: "n", erasmian: "n as in now", koine: "n as in now", modern: "n", numeric: 50, example: "νόμος", exampleGloss: "law", type: "consonant" },
  { upper: "Ξ", lower: "ξ", name: "xi", greekName: "ξῖ", translit: "x", erasmian: "x as in axe", koine: "x as in axe", modern: "ks", numeric: 60, example: "ξύλον", exampleGloss: "wood, tree", type: "consonant" },
  { upper: "Ο", lower: "ο", name: "omicron", greekName: "ὂ μικρόν", translit: "o", erasmian: "o as in not", koine: "o as in not", modern: "o", numeric: 70, example: "οἶκος", exampleGloss: "house", type: "vowel" },
  { upper: "Π", lower: "π", name: "pi", greekName: "πῖ", translit: "p", erasmian: "p as in pen", koine: "p as in pen", modern: "p", numeric: 80, example: "πνεῦμα", exampleGloss: "spirit", type: "consonant" },
  { upper: "Ρ", lower: "ρ", name: "rho", greekName: "ῥῶ", translit: "r", erasmian: "r (trilled)", koine: "r (tapped)", modern: "r (tapped)", numeric: 100, example: "ῥῆμα", exampleGloss: "word, saying", type: "consonant" },
  { upper: "Σ", lower: "σ / ς", name: "sigma", greekName: "σῖγμα", translit: "s", erasmian: "s as in sit", koine: "s as in sit", modern: "s", numeric: 200, example: "σάρξ", exampleGloss: "flesh", type: "consonant" },
  { upper: "Τ", lower: "τ", name: "tau", greekName: "ταῦ", translit: "t", erasmian: "t as in top", koine: "t as in top", modern: "t", numeric: 300, example: "τέκνον", exampleGloss: "child", type: "consonant" },
  { upper: "Υ", lower: "υ", name: "upsilon", greekName: "ὖ ψιλόν", translit: "y / u", erasmian: "oo / ü", koine: "ü as in French tu", modern: "ee", numeric: 400, example: "υἱός", exampleGloss: "son", type: "vowel" },
  { upper: "Φ", lower: "φ", name: "phi", greekName: "φῖ", translit: "ph", erasmian: "ph as in phone", koine: "f as in fine", modern: "f", numeric: 500, example: "φῶς", exampleGloss: "light", type: "consonant" },
  { upper: "Χ", lower: "χ", name: "chi", greekName: "χῖ", translit: "ch", erasmian: "ch as in Bach", koine: "ch as in Bach", modern: "ch / h", numeric: 600, example: "χάρις", exampleGloss: "grace", type: "consonant" },
  { upper: "Ψ", lower: "ψ", name: "psi", greekName: "ψῖ", translit: "ps", erasmian: "ps as in lips", koine: "ps as in lips", modern: "ps", numeric: 700, example: "ψυχή", exampleGloss: "soul", type: "consonant" },
  { upper: "Ω", lower: "ω", name: "omega", greekName: "ὦ μέγα", translit: "ō", erasmian: "o as in tone", koine: "o as in tone", modern: "o", numeric: 800, example: "ὥρα", exampleGloss: "hour", type: "vowel" },
];

export type Diphthong = {
  form: string;
  erasmian: string;
  koine: string;
  example: string;
  gloss: string;
};

export const DIPHTHONGS: Diphthong[] = [
  { form: "αι", erasmian: "ai as in aisle", koine: "e as in met", example: "καί", gloss: "and" },
  { form: "ει", erasmian: "ei as in eight", koine: "ee as in see", example: "εἰμί", gloss: "I am" },
  { form: "οι", erasmian: "oi as in oil", koine: "ü → ee", example: "οἶκος", gloss: "house" },
  { form: "υι", erasmian: "wee", koine: "wi", example: "υἱός", gloss: "son" },
  { form: "αυ", erasmian: "ow as in cow", koine: "av / af", example: "αὐτός", gloss: "he, self" },
  {
    form: "ευ",
    erasmian: "eu as in feud",
    koine: "ev before a vowel/voiced sound; ef before a voiceless sound",
    example: "εὐαγγέλιον",
    gloss: "gospel — ev-an-GHE-lee-on; the smooth breathing is silent",
  },
  { form: "ου", erasmian: "oo as in food", koine: "oo as in food", example: "οὐρανός", gloss: "heaven" },
  { form: "ηυ", erasmian: "eh-oo", koine: "iv / if", example: "ηὕρισκον", gloss: "they were finding" },
  { form: "ᾳ", erasmian: "long a (iota silent)", koine: "long a", example: "καρδίᾳ", gloss: "in the heart (dat.)" },
  { form: "ῃ", erasmian: "long ay (iota silent)", koine: "ee", example: "ἀρχῇ", gloss: "in the beginning (dat.)" },
  { form: "ῳ", erasmian: "long o (iota silent)", koine: "long o", example: "λόγῳ", gloss: "in/by the word (dat.)" },
];

export const PRONUNCIATION_SYSTEMS = [
  {
    id: "koine",
    name: "Restored Koine",
    subtitle: "Buth / Kantor",
    blurb:
      "Reconstructed first-century Judean pronunciation, based on spelling variation in the papyri and transcriptions into Hebrew, Latin and Coptic. Historically defensible and increasingly standard in immersion programmes.",
  },
  {
    id: "erasmian",
    name: "Erasmian",
    subtitle: "the seminary convention",
    blurb:
      "A teaching artefact that keeps every vowel letter audibly distinct so that spelling is easy. No ancient person spoke it, but it dominates English-language classrooms and makes dictation simple.",
  },
  {
    id: "modern",
    name: "Modern Greek",
    subtitle: "as spoken in Greece today",
    blurb:
      "Very close to late Koine. Gives you a living speech community, native audio resources, and a head start on Modern Greek. Ambiguous for spelling because of vowel mergers (itacism).",
  },
] as const;
