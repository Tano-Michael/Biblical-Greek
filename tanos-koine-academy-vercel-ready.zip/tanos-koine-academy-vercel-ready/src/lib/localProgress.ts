import type { Vocab } from "@/lib/content/vocabulary";
import { schedule, type Rating, xpForRating } from "@/lib/srs";
import { GAMES, xpForGameScore, type GameId } from "@/lib/games";

const STORAGE_KEY = "tanos-koine-academy-progress-v1";
const CHANGE_EVENT = "koine-progress-changed";

export type StoredCard = {
  ease: number;
  intervalDays: number;
  reps: number;
  lapses: number;
  dueAt: string;
  lastRating: number;
};

type LessonRecord = { score: number; completedAt: string };
type ActivityRecord = { xp: number; reviews: number; minutes: number };
type NoteRecord = { id: string; reference: string; body: string; createdAt: string };
type AssignmentRecord = {
  lessonSlug: string;
  body: string;
  xpAwarded: number;
  updatedAt: string;
};
type GameRecord = { best: number; plays: number; lastScore: number };

export type LocalProgress = {
  version: 1;
  displayName: string;
  xp: number;
  streak: number;
  lastActiveOn: string | null;
  completedLessons: Record<string, LessonRecord>;
  srs: Record<string, StoredCard>;
  lessonCards: Record<string, StoredCard>;
  notes: NoteRecord[];
  assignments: Record<string, AssignmentRecord>;
  games: Partial<Record<GameId, GameRecord>>;
  activityDays: Record<string, ActivityRecord>;
};

export type ReviewCard = {
  vocabId: string;
  lemma: string;
  translit: string;
  gloss: string;
  pos: string;
  detail: string;
  level: string;
  frequency: number;
  reps: number;
  isNew: boolean;
  choices: string[];
};

export function emptyProgress(): LocalProgress {
  return {
    version: 1,
    displayName: "Μαθητής",
    xp: 0,
    streak: 0,
    lastActiveOn: null,
    completedLessons: {},
    srs: {},
    lessonCards: {},
    notes: [],
    assignments: {},
    games: {},
    activityDays: {},
  };
}

function isBrowser(): boolean {
  return typeof window !== "undefined";
}

function isoDay(date = new Date()): string {
  return date.toISOString().slice(0, 10);
}

function normalize(raw: unknown): LocalProgress {
  if (!raw || typeof raw !== "object") return emptyProgress();
  const value = raw as Partial<LocalProgress>;
  return {
    ...emptyProgress(),
    ...value,
    version: 1,
    completedLessons: value.completedLessons ?? {},
    srs: value.srs ?? {},
    lessonCards: value.lessonCards ?? {},
    notes: Array.isArray(value.notes) ? value.notes : [],
    assignments: value.assignments ?? {},
    games: value.games ?? {},
    activityDays: value.activityDays ?? {},
  };
}

export function readProgress(): LocalProgress {
  if (!isBrowser()) return emptyProgress();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? normalize(JSON.parse(raw)) : emptyProgress();
  } catch {
    return emptyProgress();
  }
}

function writeProgress(state: LocalProgress): LocalProgress {
  if (!isBrowser()) return state;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    window.dispatchEvent(new CustomEvent(CHANGE_EVENT));
  } catch {
    // The learning content remains usable even when storage is blocked.
  }
  return state;
}

export function subscribeProgress(listener: () => void): () => void {
  if (!isBrowser()) return () => undefined;
  window.addEventListener(CHANGE_EVENT, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(CHANGE_EVENT, listener);
    window.removeEventListener("storage", listener);
  };
}

function recordActivity(
  state: LocalProgress,
  { xp = 0, reviews = 0, minutes = 0 }: { xp?: number; reviews?: number; minutes?: number },
): LocalProgress {
  const today = isoDay();
  const current = state.activityDays[today] ?? { xp: 0, reviews: 0, minutes: 0 };
  const yesterday = isoDay(new Date(Date.now() - 86_400_000));
  let streak = state.streak;

  if (state.lastActiveOn !== today) {
    streak = state.lastActiveOn === yesterday ? Math.max(1, state.streak + 1) : 1;
  }

  return {
    ...state,
    xp: Math.max(0, state.xp + xp),
    streak,
    lastActiveOn: today,
    activityDays: {
      ...state.activityDays,
      [today]: {
        xp: current.xp + xp,
        reviews: current.reviews + reviews,
        minutes: current.minutes + minutes,
      },
    },
  };
}

export function completeLesson(slug: string, score: number, minutes: number) {
  let state = readProgress();
  const alreadyCompleted = Boolean(state.completedLessons[slug]);
  const safeScore = Math.max(0, Math.min(100, Math.round(score)));
  const gained = alreadyCompleted ? 3 : 25 + Math.round(safeScore / 4);

  state = {
    ...state,
    completedLessons: {
      ...state.completedLessons,
      [slug]: { score: safeScore, completedAt: new Date().toISOString() },
    },
  };
  state = recordActivity(state, { xp: gained, minutes: alreadyCompleted ? 2 : minutes });
  writeProgress(state);
  return { gained, xp: state.xp, streak: state.streak };
}

function buildChoices(target: Vocab, library: Vocab[]): string[] {
  const samePos = library.filter((v) => v.id !== target.id && v.pos === target.pos);
  const source = samePos.length >= 3 ? samePos : library.filter((v) => v.id !== target.id);
  const picked = new Set<string>();
  let guard = 0;
  while (picked.size < 3 && guard < 250) {
    guard += 1;
    const candidate = source[Math.floor(Math.random() * source.length)];
    if (candidate && candidate.gloss !== target.gloss) picked.add(candidate.gloss);
  }
  const options = [...picked, target.gloss];
  for (let i = options.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [options[i], options[j]] = [options[j], options[i]];
  }
  return options;
}

export function getReviewQueue(library: Vocab[], limit = 18, level = "") {
  const state = readProgress();
  const now = Date.now();
  const filter = (v: Vocab) => !level || v.level === level;
  const dueIds = Object.entries(state.srs)
    .filter(([, card]) => new Date(card.dueAt).getTime() <= now)
    .sort((a, b) => new Date(a[1].dueAt).getTime() - new Date(b[1].dueAt).getTime())
    .map(([id]) => id);

  const byId = new Map(library.map((v) => [v.id, v]));
  const cards: ReviewCard[] = [];
  for (const id of dueIds) {
    const vocab = byId.get(id);
    if (!vocab || !filter(vocab)) continue;
    const stored = state.srs[id];
    cards.push({
      vocabId: vocab.id,
      lemma: vocab.lemma,
      translit: vocab.translit,
      gloss: vocab.gloss,
      pos: vocab.pos,
      detail: vocab.detail,
      level: vocab.level,
      frequency: vocab.frequency,
      reps: stored.reps,
      isNew: false,
      choices: buildChoices(vocab, library),
    });
    if (cards.length >= limit) break;
  }

  if (cards.length < limit) {
    const fresh = library
      .filter((v) => filter(v) && !state.srs[v.id])
      .sort((a, b) => b.frequency - a.frequency)
      .slice(0, limit - cards.length);
    for (const vocab of fresh) {
      cards.push({
        vocabId: vocab.id,
        lemma: vocab.lemma,
        translit: vocab.translit,
        gloss: vocab.gloss,
        pos: vocab.pos,
        detail: vocab.detail,
        level: vocab.level,
        frequency: vocab.frequency,
        reps: 0,
        isNew: true,
        choices: buildChoices(vocab, library),
      });
    }
  }

  const allCards = Object.values(state.srs);
  return {
    cards,
    stats: {
      total: allCards.length,
      dueNow: allCards.filter((card) => new Date(card.dueAt).getTime() <= now).length,
      mature: allCards.filter((card) => card.intervalDays >= 21).length,
      library: library.length,
    },
  };
}

export function rateVocabulary(vocabId: string, rating: Rating) {
  let state = readProgress();
  const current = state.srs[vocabId] ?? {
    ease: 2.5,
    intervalDays: 0,
    reps: 0,
    lapses: 0,
    dueAt: new Date().toISOString(),
    lastRating: 0,
  };
  const next = schedule(current, rating);
  state = {
    ...state,
    srs: {
      ...state.srs,
      [vocabId]: {
        ease: next.ease,
        intervalDays: next.intervalDays,
        reps: next.reps,
        lapses: next.lapses,
        dueAt: next.dueAt.toISOString(),
        lastRating: rating,
      },
    },
  };
  state = recordActivity(state, { xp: xpForRating(rating), reviews: 1, minutes: 1 });
  writeProgress(state);
  return { ok: true, nextDue: next.dueAt.toISOString(), xp: state.xp, streak: state.streak };
}

export function rateLessonCard(cardId: string, rating: Rating) {
  let state = readProgress();
  const current = state.lessonCards[cardId] ?? {
    ease: 2.5,
    intervalDays: 0,
    reps: 0,
    lapses: 0,
    dueAt: new Date().toISOString(),
    lastRating: 0,
  };
  const next = schedule(current, rating);
  state = {
    ...state,
    lessonCards: {
      ...state.lessonCards,
      [cardId]: {
        ease: next.ease,
        intervalDays: next.intervalDays,
        reps: next.reps,
        lapses: next.lapses,
        dueAt: next.dueAt.toISOString(),
        lastRating: rating,
      },
    },
  };
  state = recordActivity(state, { xp: xpForRating(rating), reviews: 1, minutes: 1 });
  writeProgress(state);
  return { ok: true, dueAt: next.dueAt.toISOString() };
}

export function saveAssignment(assignmentId: string, lessonSlug: string, body: string, xp: number) {
  let state = readProgress();
  const isNew = !state.assignments[assignmentId];
  state = {
    ...state,
    assignments: {
      ...state.assignments,
      [assignmentId]: {
        lessonSlug,
        body: body.slice(0, 8000),
        xpAwarded: xp,
        updatedAt: new Date().toISOString(),
      },
    },
  };
  if (isNew) state = recordActivity(state, { xp, minutes: 15 });
  writeProgress(state);
  return { ok: true, xp: isNew ? xp : 0 };
}

export function saveNote(reference: string, body: string) {
  let state = readProgress();
  const note: NoteRecord = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    reference: reference.slice(0, 120),
    body: body.slice(0, 4000),
    createdAt: new Date().toISOString(),
  };
  state = { ...state, notes: [note, ...state.notes].slice(0, 100) };
  writeProgress(state);
  return note;
}

export function saveGameScore(game: GameId, score: number) {
  let state = readProgress();
  const safeScore = Math.max(0, Math.min(100_000, Math.round(score)));
  const current = state.games[game] ?? { best: 0, plays: 0, lastScore: 0 };
  const xpAwarded = xpForGameScore(safeScore);
  state = {
    ...state,
    games: {
      ...state.games,
      [game]: {
        best: Math.max(current.best, safeScore),
        plays: current.plays + 1,
        lastScore: safeScore,
      },
    },
  };
  state = recordActivity(state, { xp: xpAwarded, minutes: 2 });
  writeProgress(state);
  const updated = state.games[game]!;
  return {
    ok: true,
    score: safeScore,
    best: updated.best,
    rank: 1,
    xpAwarded,
    playCount: updated.plays,
    xp: state.xp,
    streak: state.streak,
  };
}

export function setDisplayName(displayName: string) {
  const name = displayName.trim().slice(0, 40);
  if (name.length < 2) throw new Error("Name must be at least 2 characters");
  const state = writeProgress({ ...readProgress(), displayName: name });
  return state.displayName;
}

export function getWeeklyXp(state = readProgress()): number {
  const cutoff = Date.now() - 6 * 86_400_000;
  return Object.entries(state.activityDays).reduce((sum, [day, activity]) => {
    const time = new Date(`${day}T00:00:00Z`).getTime();
    return time >= cutoff ? sum + activity.xp : sum;
  }, 0);
}

export function getActivityHeatmap(days = 84, state = readProgress()) {
  const out: { day: string; xp: number; reviews: number }[] = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    const day = isoDay(new Date(Date.now() - i * 86_400_000));
    const row = state.activityDays[day];
    out.push({ day, xp: row?.xp ?? 0, reviews: row?.reviews ?? 0 });
  }
  return out;
}

export function getProgressBoard() {
  const state = readProgress();
  const me = {
    id: 1,
    displayName: state.displayName,
    xp: state.xp,
    streak: state.streak,
    rank: 1,
    weeklyXp: getWeeklyXp(state),
    lessonsDone: Object.keys(state.completedLessons).length,
  };
  const games: Record<string, { rank: number; name: string; learnerId: number; score: number; plays: number }[]> = {};
  for (const game of GAMES) {
    const record = state.games[game.id];
    games[game.id] = record
      ? [{ rank: 1, name: state.displayName, learnerId: 1, score: record.best, plays: record.plays }]
      : [];
  }
  const row = { ...me };
  return { me, allTime: [row], byWeek: [row], games };
}

export function resetProgress() {
  if (!isBrowser()) return;
  window.localStorage.removeItem(STORAGE_KEY);
  window.dispatchEvent(new CustomEvent(CHANGE_EVENT));
}
