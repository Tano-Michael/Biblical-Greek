"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";

type SpeechState = {
  supported: boolean;
  voices: SpeechSynthesisVoice[];
  voiceURI: string | null;
  setVoiceURI: (uri: string) => void;
  rate: number;
  setRate: (rate: number) => void;
  speaking: string | null;
  speak: (text: string, id?: string) => void;
  speakSequence: (items: { text: string; id?: string }[]) => Promise<void>;
  stop: () => void;
};

const Ctx = createContext<SpeechState | null>(null);

function isGreekVoice(voice: SpeechSynthesisVoice): boolean {
  return voice.lang?.toLowerCase().startsWith("el") || /greek|ελλην/i.test(voice.name);
}

/** Only select a real Greek voice. Italian/Spanish voices misread Greek letters. */
function pickGreek(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | undefined {
  return voices.find((voice) => voice.lang?.toLowerCase() === "el-gr") ?? voices.find(isGreekVoice);
}

/**
 * Browser Greek voices are trained primarily on monotonic Modern Greek. Some
 * engines interpret polytonic breathing marks as extra tokens, making forms
 * such as εὐ or εὖγε sound like an unrelated word. We preserve the fully
 * accented text on screen but convert the hidden speech copy to monotonic Greek:
 *
 * - smooth/rough breathings are removed (they are not separate syllables)
 * - acute stress is preserved; grave/circumflex become monotonic acute
 * - diaeresis is preserved because it prevents an unwanted diphthong
 * - silent iota subscript, macron and breve are removed
 *
 * εὐαγγέλιον → ευαγγέλιον (ev-an-GHE-lee-on)
 * εὖγε          → εύγε         (EV-ye, never "me")
 * Ἠσαΐας        → Ησαΐας       (diaeresis retained)
 */
export function normalizeGreekForSpeech(text: string): string {
  let output = "";
  for (const char of text.normalize("NFD")) {
    const code = char.codePointAt(0) ?? 0;
    if (char === "\u0301" || char === "\u0308") {
      // Preserve acute stress and diaeresis.
      output += char;
    } else if (char === "\u0300" || char === "\u0342") {
      // Grave and circumflex mark the same stressed syllable in monotonic speech.
      output += "\u0301";
    } else if ((code >= 0x0300 && code <= 0x036f) || (code >= 0x1dc0 && code <= 0x1dff)) {
      // Drop breathings, quantity marks, iota subscript, and other polytonic marks.
      continue;
    } else {
      output += char;
    }
  }
  return output
    .normalize("NFC")
    .replace(/[᾽’ʼ]/g, "")
    .replace(/[\[\]]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** Split long passages only at word boundaries so browser speech never truncates them. */
function speechChunks(text: string, maxLength = 180): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const chunks: string[] = [];
  let current = "";
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length > maxLength && current) {
      chunks.push(current);
      current = word;
    } else {
      current = candidate;
    }
    if (current.length >= 70 && /[.;·?!]$/.test(word)) {
      chunks.push(current);
      current = "";
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

export function GreekAudioProvider({ children }: { children: ReactNode }) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceURI, setVoiceURI] = useState<string | null>(null);
  const [rate, setRate] = useState(0.85);
  const [speaking, setSpeaking] = useState<string | null>(null);
  const supported = typeof window !== "undefined" && "speechSynthesis" in window;
  const initialised = useRef(false);
  const speechRun = useRef(0);

  useEffect(() => {
    if (!supported) return;
    const load = () => {
      const list = window.speechSynthesis.getVoices();
      if (!list.length) return;
      setVoices(list);
      if (!initialised.current) {
        initialised.current = true;
        const stored = window.localStorage.getItem("koine_voice");
        const match = stored ? list.find((v) => v.voiceURI === stored && isGreekVoice(v)) : undefined;
        setVoiceURI((match ?? pickGreek(list))?.voiceURI ?? null);
      }
    };
    load();
    window.speechSynthesis.addEventListener("voiceschanged", load);
    const storedRate = window.localStorage.getItem("koine_rate");
    if (storedRate) setRate(Number(storedRate));
    return () => window.speechSynthesis.removeEventListener("voiceschanged", load);
  }, [supported]);

  const stop = useCallback(() => {
    if (!supported) return;
    speechRun.current += 1;
    window.speechSynthesis.cancel();
    setSpeaking(null);
  }, [supported]);

  const speak = useCallback(
    (text: string, id?: string) => {
      if (!supported || !text.trim()) return;
      speechRun.current += 1;
      window.speechSynthesis.cancel();
      const spokenText = normalizeGreekForSpeech(text);
      const requested = voices.find((v) => v.voiceURI === voiceURI && isGreekVoice(v));
      const voice = requested ?? pickGreek(voices);
      const utterance = new SpeechSynthesisUtterance(spokenText);
      if (voice) utterance.voice = voice;
      // Even when the browser does not enumerate voices, el-GR asks the OS to
      // route the utterance through its Greek voice instead of an English one.
      utterance.lang = "el-GR";
      utterance.rate = rate;
      utterance.pitch = 1;
      utterance.onend = () => setSpeaking(null);
      utterance.onerror = () => setSpeaking(null);
      setSpeaking(id ?? text);
      window.speechSynthesis.speak(utterance);
    },
    [supported, voices, voiceURI, rate],
  );

  const speakSequence = useCallback(
    async (items: { text: string; id?: string }[]) => {
      if (!supported || !items.length) return;
      const run = ++speechRun.current;
      window.speechSynthesis.cancel();
      const requested = voices.find((v) => v.voiceURI === voiceURI && isGreekVoice(v));
      const voice = requested ?? pickGreek(voices);

      for (const item of items) {
        if (speechRun.current !== run) break;
        const chunks = speechChunks(normalizeGreekForSpeech(item.text));
        setSpeaking(item.id ?? item.text);

        for (const chunk of chunks) {
          if (speechRun.current !== run) break;
          await new Promise<void>((resolve) => {
            const utterance = new SpeechSynthesisUtterance(chunk);
            if (voice) utterance.voice = voice;
            utterance.lang = "el-GR";
            utterance.rate = rate;
            utterance.pitch = 1;
            let settled = false;
            const finish = () => {
              if (settled) return;
              settled = true;
              clearTimeout(watchdog);
              resolve();
            };
            // The timeout is a last-resort guard for browsers that do not emit
            // an error event after cancellation. Normal sequencing uses onend.
            const watchdog = window.setTimeout(finish, Math.max(12_000, chunk.length * 300));
            utterance.onend = finish;
            utterance.onerror = finish;
            window.speechSynthesis.speak(utterance);
          });
        }
      }

      if (speechRun.current === run) setSpeaking(null);
    },
    [supported, voices, voiceURI, rate],
  );

  const handleVoice = useCallback((uri: string) => {
    setVoiceURI(uri);
    window.localStorage.setItem("koine_voice", uri);
  }, []);

  const handleRate = useCallback((value: number) => {
    setRate(value);
    window.localStorage.setItem("koine_rate", String(value));
  }, []);

  const value = useMemo<SpeechState>(
    () => ({
      supported,
      voices,
      voiceURI,
      setVoiceURI: handleVoice,
      rate,
      setRate: handleRate,
      speaking,
      speak,
      speakSequence,
      stop,
    }),
    [supported, voices, voiceURI, handleVoice, rate, handleRate, speaking, speak, speakSequence, stop],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useGreekAudio(): SpeechState {
  const ctx = useContext(Ctx);
  if (ctx) return ctx;
  return {
    supported: false,
    voices: [],
    voiceURI: null,
    setVoiceURI: () => {},
    rate: 0.85,
    setRate: () => {},
    speaking: null,
    speak: () => {},
    speakSequence: async () => {},
    stop: () => {},
  };
}

export function SpeakButton({
  text,
  id,
  label,
  size = "md",
  className = "",
}: {
  text: string;
  id?: string;
  label?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const { speak, speaking, supported } = useGreekAudio();
  const active = speaking === (id ?? text);
  const dims =
    size === "sm" ? "h-7 w-7 text-xs" : size === "lg" ? "h-11 w-11 text-lg" : "h-9 w-9 text-sm";

  return (
    <button
      type="button"
      onClick={() => speak(text, id)}
      disabled={!supported}
      title={supported ? (label ?? "Hear it in Greek") : "Speech synthesis unavailable"}
      aria-label={label ?? "Play Greek audio"}
      className={`inline-flex shrink-0 items-center justify-center rounded-full border transition ${dims} ${
        active
          ? "speaking border-amber-400 bg-amber-400/25 text-amber-200"
          : "border-white/15 bg-white/5 text-slate-300 hover:border-amber-400/60 hover:bg-amber-400/15 hover:text-amber-200"
      } disabled:cursor-not-allowed disabled:opacity-35 ${className}`}
    >
      {active ? "❚❚" : "▶"}
    </button>
  );
}

export function VoiceSettings({ compact = false }: { compact?: boolean }) {
  const { supported, voices, voiceURI, setVoiceURI, rate, setRate, stop, speak } = useGreekAudio();
  const greekVoices = voices.filter(isGreekVoice);
  const hasGreek = greekVoices.length > 0;

  if (!supported) {
    return (
      <p className="rounded-xl border border-amber-500/25 bg-amber-500/10 p-3 text-xs text-amber-200/90">
        Your browser does not expose the Web Speech API, so in-app pronunciation is unavailable.
        Every lesson still links to real recorded Koine audio and video.
      </p>
    );
  }

  return (
    <div className={`panel rounded-2xl p-4 ${compact ? "" : "sm:p-5"}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-slate-200">Pronunciation voice</h3>
        <button
          type="button"
          onClick={stop}
          className="rounded-lg border border-white/10 px-2.5 py-1 text-xs text-slate-400 hover:text-slate-100"
        >
          Stop audio
        </button>
      </div>
      <label className="mt-3 block text-xs text-slate-400">
        Voice
        <select
          value={voiceURI ?? ""}
          onChange={(event) => setVoiceURI(event.target.value)}
          disabled={!hasGreek}
          className="mt-1 w-full rounded-lg border border-white/10 bg-slate-900/80 px-3 py-2 text-sm text-slate-100 outline-none focus:border-amber-400/60 disabled:opacity-50"
        >
          {!hasGreek && <option value="">System Greek voice (el-GR requested)</option>}
          {greekVoices.map((voice) => (
            <option key={voice.voiceURI} value={voice.voiceURI}>
              {voice.name} — {voice.lang}
            </option>
          ))}
        </select>
      </label>
      <label className="mt-3 block text-xs text-slate-400">
        Speed · {rate.toFixed(2)}×
        <input
          type="range"
          min={0.5}
          max={1.3}
          step={0.05}
          value={rate}
          onChange={(event) => setRate(Number(event.target.value))}
          className="mt-2 w-full accent-amber-400"
        />
      </label>
      <div className="mt-3 rounded-xl border border-emerald-400/15 bg-emerald-400/5 p-3">
        <p className="text-[11px] leading-relaxed text-emerald-100/75">
          Polytonic text is displayed exactly, while its hidden speech copy becomes monotonic Greek: stress and
          diaeresis stay, but breathing marks are removed so browsers do not invent extra sounds. A smooth breathing is silent: <span className="greek text-emerald-200">εὐ</span>
          {" "}is sent as <span className="greek text-emerald-200">ευ</span> and pronounced <strong>ev</strong> before a
          vowel/voiced sound or <strong>ef</strong> before a voiceless sound—not “me.”
        </p>
        <button
          type="button"
          onClick={() => speak("εὐαγγέλιον. εὖγε. εὐλογία. εὐχαριστῶ.", "pronunciation-check")}
          className="mt-2 rounded-lg border border-emerald-400/25 px-3 py-1.5 text-[11px] font-medium text-emerald-200 hover:bg-emerald-400/10"
        >
          ▶ Test εὐ: εὐαγγέλιον · εὖγε · εὐλογία · εὐχαριστῶ
        </button>
      </div>
      <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
        {hasGreek
          ? `${greekVoices.length} Greek voice${greekVoices.length > 1 ? "s" : ""} detected. Browser speech uses Modern/late-Koine sound values. Use the human recordings in each lesson for historically reconstructed Koine.`
          : "No Greek (el-GR) voice is enumerated on this device. The app requests the system Greek voice directly; if playback remains inaccurate, install an el-GR voice or use the recorded human audio in each lesson."}
      </p>
    </div>
  );
}
