"use client";

import { useMemo, useState } from "react";
import type { Diphthong, Letter } from "@/lib/content/alphabet";
import { GreekAudioProvider, SpeakButton, VoiceSettings, useGreekAudio } from "@/components/GreekAudio";
import { VideoEmbed } from "@/components/VideoEmbed";

type System = { id: string; name: string; subtitle: string; blurb: string };
type Vid = { id: string; title: string; channel: string; note: string };

export function AlphabetLab(props: {
  letters: Letter[];
  diphthongs: Diphthong[];
  systems: System[];
  videos: Vid[];
}) {
  return (
    <GreekAudioProvider>
      <Inner {...props} />
    </GreekAudioProvider>
  );
}

function Inner({
  letters,
  diphthongs,
  systems,
  videos,
}: {
  letters: Letter[];
  diphthongs: Diphthong[];
  systems: System[];
  videos: Vid[];
}) {
  const [system, setSystem] = useState<"koine" | "erasmian" | "modern">("koine");
  const [selected, setSelected] = useState<Letter>(letters[0]);
  const [quizOn, setQuizOn] = useState(false);

  return (
    <div className="space-y-8">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Ἀλφάβητον</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Alphabet & Pronunciation Lab</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          Twenty-four letters, eleven diphthongs, three pronunciation systems. Click any letter to hear it and
          see an example word. Set your preferred voice at the bottom of the page.
        </p>
      </header>

      {/* System switcher */}
      <section className="grid gap-3 md:grid-cols-3">
        {systems.map((s) => {
          const active = system === s.id;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => setSystem(s.id as typeof system)}
              className={`rounded-2xl border p-4 text-left transition ${
                active
                  ? "border-amber-400/50 bg-amber-400/10"
                  : "border-white/10 bg-white/[0.03] hover:border-white/25"
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className={`text-sm font-semibold ${active ? "text-amber-200" : "text-slate-200"}`}>
                  {s.name}
                </h3>
                {active && <span className="text-xs text-amber-300">selected</span>}
              </div>
              <p className="text-[11px] uppercase tracking-wider text-slate-500">{s.subtitle}</p>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">{s.blurb}</p>
            </button>
          );
        })}
      </section>

      {/* Letter grid + detail */}
      <section className="grid gap-5 lg:grid-cols-[1.55fr_1fr]">
        <div>
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
            {letters.map((letter) => (
              <button
                key={letter.name}
                type="button"
                onClick={() => setSelected(letter)}
                className={`panel panel-hover flex flex-col items-center rounded-xl px-2 py-3 transition ${
                  selected.name === letter.name ? "ring-2 ring-amber-400/60" : ""
                }`}
              >
                <span className="greek text-2xl leading-none text-amber-100">{letter.lower}</span>
                <span className="greek mt-0.5 text-xs text-slate-500">{letter.upper}</span>
                <span className="mt-1 text-[10px] text-slate-400">{letter.name}</span>
              </button>
            ))}
          </div>

          <div className="mt-6">
            <h2 className="text-sm font-semibold text-slate-200">Diphthongs & iota subscripts</h2>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {diphthongs.map((d) => (
                <div key={d.form} className="panel flex items-center gap-3 rounded-xl p-3">
                  <SpeakButton text={d.example} id={`d-${d.form}`} size="sm" />
                  <div className="min-w-0">
                    <p className="greek text-lg leading-none text-amber-100">
                      {d.form}
                      <span className="ml-2 text-sm text-slate-400">{d.example}</span>
                    </p>
                    <p className="mt-1 text-[11px] text-slate-500">
                      {system === "erasmian" ? d.erasmian : d.koine} · {d.gloss}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="panel rounded-2xl p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="greek text-6xl leading-none text-amber-200">{selected.lower}</p>
                <p className="greek mt-1 text-2xl text-slate-500">{selected.upper}</p>
              </div>
              <div className="text-right">
                <p className="greek text-lg text-slate-300">{selected.greekName}</p>
                <p className="text-xs text-slate-500">{selected.name}</p>
                <p className="mt-1 text-[11px] text-slate-600">
                  numeral value {selected.numeric} · {selected.type}
                </p>
              </div>
            </div>

            <div className="mt-4 space-y-1.5 text-sm">
              <Row label="Transliteration" value={selected.translit} />
              <Row
                label="Sound"
                value={
                  system === "erasmian"
                    ? selected.erasmian
                    : system === "modern"
                      ? selected.modern
                      : selected.koine
                }
                highlight
              />
            </div>

            <div className="mt-4 flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3">
              <SpeakButton text={selected.example} id={`ex-${selected.name}`} size="lg" />
              <div>
                <p className="greek text-2xl text-amber-100">{selected.example}</p>
                <p className="text-xs text-slate-400">{selected.exampleGloss}</p>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px]">
              <Mini label="Erasmian" value={selected.erasmian} on={system === "erasmian"} />
              <Mini label="Koine" value={selected.koine} on={system === "koine"} />
              <Mini label="Modern" value={selected.modern} on={system === "modern"} />
            </div>
          </div>

          <button
            type="button"
            onClick={() => setQuizOn((v) => !v)}
            className="w-full rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-4 py-3 text-sm font-semibold text-slate-950 transition hover:brightness-110"
          >
            {quizOn ? "Close listening quiz" : "🎧 Start listening quiz"}
          </button>

          {quizOn && <ListeningQuiz letters={letters} />}

          <VoiceSettings compact />
        </div>
      </section>

      <section>
        <h2 className="text-lg font-semibold text-slate-100">Watch it taught</h2>
        <p className="mt-1 text-sm text-slate-400">
          Four of the best free alphabet and pronunciation videos on the internet.
        </p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {videos.map((video) => (
            <VideoEmbed
              key={video.id}
              id={video.id}
              title={video.title}
              channel={video.channel}
              note={video.note}
              compact
            />
          ))}
        </div>
      </section>
    </div>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-white/6 pb-1.5">
      <span className="text-xs text-slate-500">{label}</span>
      <span className={highlight ? "text-sm font-medium text-amber-200" : "text-sm text-slate-300"}>
        {value}
      </span>
    </div>
  );
}

function Mini({ label, value, on }: { label: string; value: string; on: boolean }) {
  return (
    <div
      className={`rounded-lg border p-2 ${
        on ? "border-amber-400/40 bg-amber-400/10 text-amber-200" : "border-white/8 bg-white/[0.02] text-slate-400"
      }`}
    >
      <p className="text-[10px] uppercase tracking-wider opacity-70">{label}</p>
      <p className="mt-0.5 leading-tight">{value}</p>
    </div>
  );
}

function ListeningQuiz({ letters }: { letters: Letter[] }) {
  const { speak, supported } = useGreekAudio();
  const [round, setRound] = useState(0);
  const [score, setScore] = useState({ right: 0, total: 0 });
  const [picked, setPicked] = useState<string | null>(null);

  const question = useMemo(() => {
    const target = letters[Math.floor(Math.random() * letters.length)];
    const distractors = new Set<string>();
    while (distractors.size < 3) {
      const candidate = letters[Math.floor(Math.random() * letters.length)];
      if (candidate.name !== target.name) distractors.add(candidate.name);
    }
    const options = [...distractors, target.name].sort(() => Math.random() - 0.5);
    return { target, options };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round, letters]);

  function choose(name: string) {
    if (picked) return;
    setPicked(name);
    setScore((s) => ({ right: s.right + (name === question.target.name ? 1 : 0), total: s.total + 1 }));
  }

  return (
    <div className="panel rounded-2xl p-5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-200">Which letter did you hear?</h3>
        <span className="text-xs text-slate-500">
          {score.right}/{score.total}
        </span>
      </div>
      <button
        type="button"
        onClick={() => speak(question.target.example, `quiz-${round}`)}
        disabled={!supported}
        className="mt-3 w-full rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-4 text-3xl text-amber-200 disabled:opacity-40"
      >
        🔊 Play sound
      </button>
      <p className="mt-1 text-center text-[11px] text-slate-500">
        (plays the example word for the hidden letter)
      </p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {question.options.map((name) => {
          const isTarget = name === question.target.name;
          let tone = "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/30";
          if (picked && isTarget) tone = "border-emerald-400/50 bg-emerald-400/12 text-emerald-100";
          else if (picked === name) tone = "border-rose-400/50 bg-rose-400/12 text-rose-100";
          return (
            <button
              key={name}
              type="button"
              onClick={() => choose(name)}
              className={`rounded-xl border px-3 py-2.5 text-sm capitalize transition ${tone}`}
            >
              {name}
            </button>
          );
        })}
      </div>
      {picked && (
        <div className="mt-3 flex items-center justify-between rounded-xl border border-white/8 bg-white/[0.03] p-3">
          <span className="greek text-2xl text-amber-100">
            {question.target.lower} — {question.target.example}
          </span>
          <button
            type="button"
            onClick={() => {
              setPicked(null);
              setRound((r) => r + 1);
            }}
            className="rounded-lg bg-amber-400/20 px-3 py-1.5 text-xs font-medium text-amber-200"
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
