"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  CASES,
  GENDERS,
  MOODS,
  NUMBERS,
  PERSONS,
  TENSES,
  VOICES,
  type Drill,
} from "@/lib/content/parsing";
import { GreekAudioProvider, SpeakButton } from "@/components/GreekAudio";

type Mode = "all" | "noun" | "verb";

export function ParsingGym({ drills }: { drills: Drill[] }) {
  return (
    <GreekAudioProvider>
      <Inner drills={drills} />
    </GreekAudioProvider>
  );
}

function Inner({ drills }: { drills: Drill[] }) {
  const [mode, setMode] = useState<Mode>("all");
  const [seed, setSeed] = useState(0);
  const [picks, setPicks] = useState<Record<string, string>>({});
  const [checked, setChecked] = useState(false);
  const [score, setScore] = useState({ right: 0, total: 0, streak: 0, best: 0 });
  const [timed, setTimed] = useState(false);
  const [remaining, setRemaining] = useState(60);

  const pool = useMemo(
    () => (mode === "all" ? drills : drills.filter((d) => d.kind === mode)),
    [drills, mode],
  );

  const current = useMemo(() => {
    if (!pool.length) return null;
    return pool[Math.floor(Math.random() * pool.length)];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seed, pool]);

  const nextItem = useCallback(() => {
    setPicks({});
    setChecked(false);
    setSeed((s) => s + 1);
  }, []);

  useEffect(() => {
    if (!timed) return;
    if (remaining <= 0) {
      setTimed(false);
      return;
    }
    const timer = setTimeout(() => setRemaining((r) => r - 1), 1000);
    return () => clearTimeout(timer);
  }, [timed, remaining]);

  const slots = useMemo(() => {
    if (!current) return [] as { key: string; label: string; options: string[]; answer: string }[];
    if (current.kind === "noun") {
      return [
        { key: "case", label: "Case", options: CASES, answer: current.case },
        { key: "number", label: "Number", options: NUMBERS, answer: current.number },
        { key: "gender", label: "Gender", options: GENDERS, answer: current.gender },
      ];
    }
    const base = [
      { key: "tense", label: "Tense-form", options: TENSES, answer: current.tense },
      { key: "voice", label: "Voice", options: VOICES, answer: current.voice },
      { key: "mood", label: "Mood", options: MOODS, answer: current.mood },
      { key: "person", label: "Person", options: PERSONS, answer: current.person },
      { key: "number", label: "Number", options: NUMBERS, answer: current.number },
    ];
    return base;
  }, [current]);

  const allPicked = slots.every((s) => picks[s.key]);
  const correct = slots.every((s) => picks[s.key] === s.answer);

  function check() {
    if (!allPicked) return;
    setChecked(true);
    setScore((prev) => {
      const isRight = slots.every((s) => picks[s.key] === s.answer);
      const streak = isRight ? prev.streak + 1 : 0;
      return {
        right: prev.right + (isRight ? 1 : 0),
        total: prev.total + 1,
        streak,
        best: Math.max(prev.best, streak),
      };
    });
  }

  if (!current) return null;

  return (
    <div className="space-y-6">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Γυμνάσιον</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Parsing Gym</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          Parsing is a muscle. Nouns get three slots (case · number · gender); verbs get five (tense-form ·
          voice · mood · person · number). Hear each form, decide, then check.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        {(["all", "noun", "verb"] as Mode[]).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => {
              setMode(m);
              nextItem();
            }}
            className={`rounded-xl px-4 py-2.5 text-sm font-medium capitalize transition ${
              mode === m
                ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/30"
                : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
            }`}
          >
            {m === "all" ? "Mixed" : `${m}s`}
          </button>
        ))}
        <button
          type="button"
          onClick={() => {
            setTimed((t) => !t);
            setRemaining(60);
          }}
          className={`rounded-xl px-4 py-2.5 text-sm font-medium transition ${
            timed ? "bg-rose-500/20 text-rose-200 ring-1 ring-rose-400/30" : "bg-white/[0.04] text-slate-400"
          }`}
        >
          {timed ? `⏱ ${remaining}s` : "⏱ 60-second sprint"}
        </button>
        <div className="ml-auto flex gap-2 text-xs">
          <Pill label="Correct" value={`${score.right}/${score.total}`} />
          <Pill label="Streak" value={String(score.streak)} />
          <Pill label="Best" value={String(score.best)} />
        </div>
      </div>

      <section className="panel rounded-3xl p-6 sm:p-8">
        <div className="flex flex-col items-center text-center">
          <SpeakButton text={current.form} id={`p-${current.form}`} size="lg" />
          <p className="greek mt-4 text-5xl leading-tight text-amber-100 sm:text-6xl">{current.form}</p>
          <p className="mt-2 text-xs text-slate-500">
            from <span className="greek text-sm text-slate-400">{current.lemma}</span>
            <span className="mx-1.5">·</span>
            {current.kind === "noun" ? "noun" : "verb"}
          </p>
        </div>

        <div className="mt-8 space-y-4">
          {slots.map((slot) => (
            <div key={slot.key}>
              <p className="mb-1.5 text-[11px] uppercase tracking-wider text-slate-500">{slot.label}</p>
              <div className="flex flex-wrap gap-1.5">
                {slot.options.map((option) => {
                  const picked = picks[slot.key] === option;
                  const isAnswer = slot.answer === option;
                  let tone = "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/30";
                  if (checked && isAnswer) tone = "border-emerald-400/50 bg-emerald-400/12 text-emerald-100";
                  else if (checked && picked) tone = "border-rose-400/50 bg-rose-400/12 text-rose-100";
                  else if (picked) tone = "border-amber-400/60 bg-amber-400/12 text-amber-100";
                  return (
                    <button
                      key={option}
                      type="button"
                      disabled={checked}
                      onClick={() => setPicks((p) => ({ ...p, [slot.key]: option }))}
                      className={`rounded-lg border px-3 py-1.5 text-xs transition ${tone} disabled:cursor-default`}
                    >
                      {option}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-7 flex flex-wrap items-center gap-3">
          {!checked ? (
            <button
              type="button"
              onClick={check}
              disabled={!allPicked}
              className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-5 py-2.5 text-sm font-semibold text-slate-950 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Check parsing
            </button>
          ) : (
            <button
              type="button"
              onClick={nextItem}
              className="rounded-xl bg-gradient-to-r from-sky-400 to-indigo-500 px-5 py-2.5 text-sm font-semibold text-slate-950"
            >
              Next form →
            </button>
          )}
          <button
            type="button"
            onClick={nextItem}
            className="rounded-xl border border-white/15 px-4 py-2.5 text-sm text-slate-400 hover:text-slate-200"
          >
            Skip
          </button>
        </div>

        {checked && (
          <div
            className={`mt-5 rounded-2xl border p-4 ${
              correct ? "border-emerald-400/30 bg-emerald-400/8" : "border-rose-400/30 bg-rose-400/8"
            }`}
          >
            <p className={`text-sm font-semibold ${correct ? "text-emerald-200" : "text-rose-200"}`}>
              {correct ? "εὖγε (EV-yeh) — correct!" : "Not quite."}
            </p>
            <p className="mt-1.5 text-sm text-slate-300">
              <span className="greek text-lg text-amber-100">{current.form}</span> — {current.gloss}
            </p>
            <p className="mt-1 text-xs text-slate-400">
              {current.kind === "noun"
                ? `${current.case} ${current.number} ${current.gender} of ${current.lemma}`
                : `${current.tense} ${current.voice} ${current.mood}, ${current.person} person ${current.number} of ${current.lemma}`}
            </p>
            {current.note && <p className="mt-2 text-xs italic text-sky-200/80">{current.note}</p>}
          </div>
        )}
      </section>
    </div>
  );
}

function Pill({ label, value }: { label: string; value: string }) {
  return (
    <span className="rounded-lg border border-white/10 bg-white/[0.03] px-2.5 py-1.5 text-slate-300">
      <span className="text-slate-500">{label} </span>
      <span className="font-semibold text-amber-300">{value}</span>
    </span>
  );
}
