"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const LINKS = [
  { href: "/", label: "Dashboard", greek: "Ἀρχή" },
  { href: "/learn", label: "Curriculum", greek: "Μαθήματα" },
  { href: "/alphabet", label: "Alphabet Lab", greek: "Ἀλφάβητον" },
  { href: "/vocabulary", label: "Vocabulary", greek: "Λεξικόν" },
  { href: "/flashcards", label: "Flashcards", greek: "Κάρται" },
  { href: "/parsing", label: "Parsing Gym", greek: "Γυμνάσιον" },
  { href: "/games", label: "Games", greek: "Ἀγῶνες" },
  { href: "/leaderboard", label: "Progress", greek: "Βράβεια" },
  { href: "/reader", label: "Reader", greek: "Ἀνάγνωσις" },
  { href: "/library", label: "Media Library", greek: "Βιβλιοθήκη" },
];

export function SiteNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#070a12]/85 backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <Link href="/" className="flex shrink-0 items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 text-lg font-bold text-slate-950 shadow-lg shadow-amber-500/20">
            Ω
          </span>
          <span className="hidden sm:block">
            <span className="block text-lg leading-none font-semibold text-amber-200">TANO'S</span>
            <span className="block text-[10px] uppercase tracking-[0.18em] text-slate-500">
              Koine Academy
            </span>
          </span>
        </Link>

        <nav className="ml-auto hidden items-center gap-0.5 lg:flex">
          {LINKS.map((link) => {
            const active =
              link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-lg px-3 py-2 text-sm transition ${
                  active
                    ? "bg-amber-500/15 text-amber-200"
                    : "text-slate-400 hover:bg-white/5 hover:text-slate-100"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle navigation"
          className="ml-auto rounded-lg border border-white/10 px-3 py-2 text-sm text-slate-300 lg:hidden"
        >
          {open ? "✕" : "☰"}
        </button>
      </div>

      {open && (
        <div className="grid grid-cols-2 gap-1 border-t border-white/10 px-4 py-3 lg:hidden">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2 text-sm text-slate-300 hover:bg-white/5"
            >
              <span className="greek mr-2 text-amber-300/80">{link.greek}</span>
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
}
