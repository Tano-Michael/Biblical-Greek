"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { Vocab } from "@/lib/content/vocabulary";
import { GreekAudioProvider, SpeakButton, VoiceSettings } from "@/components/GreekAudio";
import { RATING_LABELS, type Rating } from "@/lib/srs";
import { getReviewQueue, rateVocabulary } from "@/lib/localProgress";

type ReviewCard = {
  vocabId: string;
  lemma: string;
  translit: string;
  gloss: string;
  pos: string;
  detail: string;
  level: string;
  frequency: number;
  reps: number;
  isNew: boolean;
  choices: string[];
};

type Stats = { total: number; dueNow: number; mature: number; library: number };

export function VocabTrainer({ library }: { library: Vocab[] }) {
  return (
    <GreekAudioProvider>
      <Inner library={library} />
    </GreekAudioProvider>
  );
}

function Inner({ library }: { library: Vocab[] }) {
  const [tab, setTab] = useState<"review" | "browse">("review");
  const [cards, setCards] = useState<ReviewCard[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [choice, setChoice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState({ done: 0, right: 0, xp: 0 });
  const [level, setLevel] = useState<string>("");
  const [mode, setMode] = useState<"recognition" | "recall">("recognition");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = getReviewQueue(library, 18, level);
      setCards(data.cards ?? []);
      setStats(data.stats ?? null);
      setIdx(0);
      setRevealed(false);
      setChoice(null);
    } finally {
      setLoading(false);
    }
  }, [library, level]);

  useEffect(() => {
    void load();
  }, [load]);

  const card = cards[idx];

  async function grade(rating: Rating) {
    if (!card) return;
    const data = rateVocabulary(card.vocabId, rating);
    setSession((s) => ({
      done: s.done + 1,
      right: s.right + (rating >= 2 ? 1 : 0),
      xp: s.xp + (rating === 0 ? 1 : rating + 1),
    }));
    if (data?.ok) {
      setStats((prev) => (prev ? { ...prev, dueNow: Math.max(0, prev.dueNow - 1) } : prev));
    }
    setRevealed(false);
    setChoice(null);
    setIdx((i) => i + 1);
  }

  const filtered = useMemo(() => {
    const list = level ? library.filter((v) => v.level === level) : library;
    return [...list].sort((a, b) => b.frequency - a.frequency);
  }, [library, level]);

  return (
    <div className="space-y-6">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Λεξικόν</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Vocabulary Trainer</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          {library.length} frequency-ranked New Testament words on an SM-2 spaced-repetition schedule. Every
          card speaks. Around 320 lemmas cover 80% of the Greek New Testament — this is the fastest route to
          reading fluency.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex gap-1.5">
          {(["review", "browse"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={`rounded-xl px-4 py-2.5 text-sm font-medium capitalize transition ${
                tab === t
                  ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/30"
                  : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
              }`}
            >
              {t === "review" ? "🃏 Review session" : "📚 Browse lexicon"}
            </button>
          ))}
        </div>
        <select
          value={level}
          onChange={(event) => setLevel(event.target.value)}
          className="rounded-xl border border-white/10 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-amber-400/50"
        >
          <option value="">All levels</option>
          <option value="foundations">Foundations</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
          <option value="scholar">Scholar</option>
        </select>
        {tab === "review" && (
          <select
            value={mode}
            onChange={(event) => setMode(event.target.value as typeof mode)}
            className="rounded-xl border border-white/10 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-amber-400/50"
          >
            <option value="recognition">Multiple choice</option>
            <option value="recall">Free recall</option>
          </select>
        )}
      </div>

      {stats && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Metric label="Due now" value={stats.dueNow} accent="text-amber-300" />
          <Metric label="Cards started" value={`${stats.total}/${stats.library}`} accent="text-sky-300" />
          <Metric label="Mature (21d+)" value={stats.mature} accent="text-emerald-300" />
          <Metric
            label="This session"
            value={`${session.right}/${session.done}`}
            accent="text-fuchsia-300"
          />
        </div>
      )}

      {tab === "review" && (
        <section className="grid gap-5 lg:grid-cols-[1.6fr_1fr]">
          <div>
            {loading ? (
              <div className="panel flex h-72 items-center justify-center rounded-3xl text-sm text-slate-500">
                Loading your deck…
              </div>
            ) : !card ? (
              <div className="panel flex h-72 flex-col items-center justify-center gap-3 rounded-3xl p-6 text-center">
                <p className="greek text-3xl text-amber-200">εὖγε!</p>
                <p className="text-[11px] uppercase tracking-wider text-amber-300/60">EV-yeh · well done</p>
                <p className="text-sm text-slate-300">
                  {session.done > 0
                    ? `Session finished — ${session.right} of ${session.done} correct, +${session.xp} XP.`
                    : "No cards due right now."}
                </p>
                <button
                  type="button"
                  onClick={() => void load()}
                  className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-5 py-2.5 text-sm font-semibold text-slate-950"
                >
                  Load more cards
                </button>
              </div>
            ) : (
              <div className="panel rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span>
                    Card {idx + 1} of {cards.length}
                    {card.isNew && (
                      <span className="ml-2 rounded bg-sky-500/20 px-1.5 py-0.5 text-sky-300">new</span>
                    )}
                  </span>
                  <span className="capitalize">{card.level}</span>
                </div>

                <div className="mt-6 flex flex-col items-center text-center">
                  <SpeakButton text={card.lemma.split(",")[0]} id={card.vocabId} size="lg" />
                  <p className="greek mt-4 text-4xl leading-tight text-amber-100 sm:text-5xl">
                    {card.lemma}
                  </p>
                  <p className="mt-2 text-xs text-slate-500">{card.translit}</p>
                </div>

                {!revealed ? (
                  mode === "recognition" ? (
                    <div className="mt-8 grid gap-2">
                      {card.choices.map((option) => {
                        const isRight = option === card.gloss;
                        let tone = "border-white/10 bg-white/[0.03] text-slate-300 hover:border-amber-400/40";
                        if (choice) {
                          if (isRight) tone = "border-emerald-400/50 bg-emerald-400/12 text-emerald-100";
                          else if (choice === option)
                            tone = "border-rose-400/50 bg-rose-400/12 text-rose-100";
                        }
                        return (
                          <button
                            key={option}
                            type="button"
                            onClick={() => {
                              if (choice) return;
                              setChoice(option);
                              setTimeout(() => setRevealed(true), 520);
                            }}
                            className={`rounded-xl border px-4 py-3 text-left text-sm transition ${tone}`}
                          >
                            {option}
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setRevealed(true)}
                      className="mt-8 w-full rounded-xl border border-white/15 py-4 text-sm text-slate-300 transition hover:border-amber-400/50 hover:text-amber-200"
                    >
                      Say the meaning aloud, then tap to reveal
                    </button>
                  )
                ) : (
                  <div className="mt-6 space-y-4">
                    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-center">
                      <p className="text-lg font-medium text-slate-100">{card.gloss}</p>
                      <p className="mt-1 text-xs leading-relaxed text-slate-400">{card.detail}</p>
                      <div className="mt-2 flex justify-center gap-2 text-[10px] text-slate-500">
                        <span className="rounded bg-white/5 px-1.5 py-0.5">{card.pos}</span>
                        {card.frequency > 0 && (
                          <span className="rounded bg-white/5 px-1.5 py-0.5">{card.frequency}× in NT</span>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      {RATING_LABELS.map((r) => (
                        <button
                          key={r.value}
                          type="button"
                          onClick={() => void grade(r.value)}
                          className={`rounded-xl px-2 py-3 text-xs font-semibold text-white transition ${r.tone}`}
                        >
                          {r.label}
                          <span className="mt-0.5 block text-[10px] font-normal opacity-75">{r.hint}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {!revealed && (
                  <button
                    type="button"
                    onClick={() => setRevealed(true)}
                    className="mt-4 w-full text-center text-[11px] text-slate-600 hover:text-slate-400"
                  >
                    skip to answer
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="panel rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-slate-200">How the scheduling works</h3>
              <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-400">
                <li>
                  <span className="font-medium text-rose-300">Again</span> — you blanked. Back in 10 minutes,
                  ease drops.
                </li>
                <li>
                  <span className="font-medium text-amber-300">Hard</span> — you got there slowly. Shorter
                  interval.
                </li>
                <li>
                  <span className="font-medium text-emerald-300">Good</span> — normal SM-2 growth: 1 day → 4
                  days → interval × ease.
                </li>
                <li>
                  <span className="font-medium text-sky-300">Easy</span> — instant. Ease rises and the
                  interval jumps.
                </li>
              </ul>
              <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
                Be honest with your ratings. The algorithm only works if the data is true.
              </p>
            </div>
            <VoiceSettings compact />
          </div>
        </section>
      )}

      {tab === "browse" && (
        <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((word) => (
            <div key={word.id} className="panel rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <SpeakButton text={word.lemma.split(",")[0]} id={`b-${word.id}`} size="sm" />
                <div className="min-w-0">
                  <p className="greek text-lg leading-tight text-amber-100">{word.lemma}</p>
                  <p className="text-[11px] text-slate-500">{word.translit}</p>
                  <p className="mt-1 text-sm text-slate-200">{word.gloss}</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-500">{word.detail}</p>
                  <div className="mt-2 flex flex-wrap gap-1.5 text-[10px] text-slate-500">
                    <span className="rounded bg-white/5 px-1.5 py-0.5">{word.pos}</span>
                    <span className="rounded bg-white/5 px-1.5 py-0.5 capitalize">{word.level}</span>
                    {word.frequency > 0 && (
                      <span className="rounded bg-white/5 px-1.5 py-0.5">{word.frequency}×</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}

function Metric({ label, value, accent }: { label: string; value: string | number; accent: string }) {
  return (
    <div className="panel rounded-xl px-3 py-3">
      <p className={`text-xl font-semibold ${accent}`}>{value}</p>
      <p className="mt-0.5 text-[11px] uppercase tracking-wider text-slate-500">{label}</p>
    </div>
  );
}
