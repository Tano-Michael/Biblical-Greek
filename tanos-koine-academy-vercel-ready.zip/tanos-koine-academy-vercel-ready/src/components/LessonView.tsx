"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { Lesson } from "@/lib/content/curriculum";
import type { Vocab } from "@/lib/content/vocabulary";
import { deepGuideFor } from "@/lib/content/deepGuides";
import { assignmentsFor, type Assignment } from "@/lib/content/assignments";
import { cardsFor, type LessonCard } from "@/lib/content/lessonCards";
import { GreekAudioProvider, SpeakButton, VoiceSettings, useGreekAudio } from "@/components/GreekAudio";
import { VideoEmbed } from "@/components/VideoEmbed";
import { RATING_LABELS, type Rating } from "@/lib/srs";
import { completeLesson, rateLessonCard, readProgress, saveAssignment } from "@/lib/localProgress";

type Props = {
  lesson: Lesson;
  vocab: Vocab[];
  trackName: string;
  trackChip: string;
  trackAccent: string;
  prev: { slug: string; title: string } | null;
  next: { slug: string; title: string } | null;
  initiallyCompleted: boolean;
  position: number;
  total: number;
};

const TABS = [
  { id: "watch", label: "Watch", icon: "🎬" },
  { id: "guide", label: "Deep Guide", icon: "📝" },
  { id: "listen", label: "Listen", icon: "🔊" },
  { id: "grammar", label: "Grammar", icon: "📐" },
  { id: "vocab", label: "Words", icon: "🗂" },
  { id: "cards", label: "Flashcards", icon: "🃏" },
  { id: "read", label: "Read", icon: "📖" },
  { id: "assignments", label: "Assignments", icon: "✍️" },
  { id: "quiz", label: "Check", icon: "✅" },
] as const;

type TabId = (typeof TABS)[number]["id"];

export function LessonView(props: Props) {
  return (
    <GreekAudioProvider>
      <LessonInner {...props} />
    </GreekAudioProvider>
  );
}

function LessonInner({
  lesson,
  vocab,
  trackName,
  trackChip,
  trackAccent,
  prev,
  next,
  initiallyCompleted,
  position,
  total,
}: Props) {
  const [tab, setTab] = useState<TabId>("watch");
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [completed, setCompleted] = useState(initiallyCompleted);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    setCompleted(Boolean(readProgress().completedLessons[lesson.slug]));
  }, [lesson.slug]);

  const deepGuide = deepGuideFor(lesson.slug);
  const assignments = assignmentsFor(lesson.slug);
  const lessonCards = cardsFor(lesson.slug);

  const score = useMemo(() => {
    if (!lesson.quiz.length) return 100;
    const correct = lesson.quiz.filter((q, i) => answers[i] === q.answer).length;
    return Math.round((correct / lesson.quiz.length) * 100);
  }, [answers, lesson.quiz]);

  const allAnswered = lesson.quiz.every((_, i) => answers[i] !== undefined);

  async function markComplete() {
    setSaving(true);
    try {
      const data = completeLesson(lesson.slug, score, lesson.minutes);
      setCompleted(true);
      setToast(`Lesson complete · +${data.gained} XP · ${data.streak}-day streak`);
      setTimeout(() => setToast(null), 4200);
    } catch {
      setToast("Could not save progress in this browser.");
      setTimeout(() => setToast(null), 4000);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <header className="rise panel relative overflow-hidden rounded-3xl p-5 sm:p-7">
        <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${trackAccent}`} aria-hidden />
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <Link href="/learn" className="text-slate-500 hover:text-slate-300">
            ← Curriculum
          </Link>
          <span className={`rounded-full border px-2.5 py-0.5 ${trackChip}`}>{trackName}</span>
          <span className="rounded-full bg-white/5 px-2.5 py-0.5 text-slate-400">
            Lesson {position} of {total}
          </span>
          <span className="rounded-full bg-white/5 px-2.5 py-0.5 text-slate-400">{lesson.minutes} min</span>
          {completed && (
            <span className="rounded-full border border-emerald-500/30 bg-emerald-500/15 px-2.5 py-0.5 text-emerald-300">
              ✓ Completed
            </span>
          )}
          <span className="rounded-full border border-amber-400/20 bg-amber-400/10 px-2.5 py-0.5 text-amber-300">
            {lessonCards.length} flashcards · {assignments.length} assignments
          </span>
        </div>

        <div className="mt-4 flex items-start gap-3">
          <SpeakButton text={lesson.greekTitle} size="lg" />
          <div>
            <p className="greek text-xl text-amber-200/90">{lesson.greekTitle}</p>
            <h1 className="mt-0.5 text-2xl leading-tight font-semibold text-slate-50 sm:text-3xl">
              {lesson.title}
            </h1>
          </div>
        </div>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-400">{lesson.summary}</p>

        <ul className="mt-4 grid gap-2 sm:grid-cols-3">
          {lesson.objectives.map((objective) => (
            <li
              key={objective}
              className="rounded-xl border border-white/8 bg-white/[0.03] p-3 text-xs leading-relaxed text-slate-300"
            >
              <span className="mr-1.5 text-amber-400">◆</span>
              {objective}
            </li>
          ))}
        </ul>
      </header>

      <nav className="scroll-thin sticky top-[65px] z-30 -mx-4 flex gap-1.5 overflow-x-auto bg-[#070a12]/90 px-4 py-2 backdrop-blur sm:mx-0 sm:rounded-xl sm:bg-[#0e1320]/90">
        {TABS.map((t) => {
          const disabled =
            (t.id === "read" && !lesson.reading) ||
            (t.id === "vocab" && vocab.length === 0) ||
            (t.id === "quiz" && lesson.quiz.length === 0) ||
            (t.id === "guide" && !deepGuide) ||
            (t.id === "cards" && lessonCards.length === 0) ||
            (t.id === "assignments" && assignments.length === 0);
          if (disabled) return null;
          const count =
            t.id === "cards"
              ? lessonCards.length
              : t.id === "assignments"
                ? assignments.length
                : t.id === "vocab"
                  ? vocab.length
                  : null;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`shrink-0 rounded-xl px-3.5 py-2 text-xs font-medium transition sm:text-sm ${
                tab === t.id
                  ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/30"
                  : "bg-white/[0.04] text-slate-400 hover:bg-white/[0.08] hover:text-slate-200"
              }`}
            >
              <span className="mr-1">{t.icon}</span>
              {t.label}
              {count && <span className="ml-1.5 rounded-full bg-white/10 px-1.5 py-0.5 text-[10px]">{count}</span>}
            </button>
          );
        })}
      </nav>

      {tab === "watch" && (
        <section className="space-y-4">
          <Intro
            title="Watch first — then read the deep guide"
            body="Pick one video. Give it full attention. Then immediately read the Deep Guide tab — it translates the video into English-comparison thinking so you feel Greek, not just memorize it."
          />
          <div className="grid gap-4 md:grid-cols-2">
            {lesson.videos.map((video) => (
              <VideoEmbed
                key={video.id}
                id={video.id}
                kind={video.kind}
                title={video.title}
                channel={video.channel}
                note={video.note}
              />
            ))}
          </div>
        </section>
      )}

      {tab === "guide" && deepGuide && <DeepGuidePanel guide={deepGuide} />}

      {tab === "listen" && <ListenPanel lesson={lesson} />}

      {tab === "grammar" && (
        <section className="space-y-4">
          {lesson.grammar.map((block) => (
            <article key={block.heading} className="panel rounded-2xl p-5 sm:p-6">
              <h3 className="text-lg font-semibold text-amber-100">{block.heading}</h3>
              <div className="mt-3 space-y-2.5">
                {block.body.map((paragraph, i) => (
                  <p key={i} className="text-sm leading-relaxed text-slate-300">
                    <GreekRich text={paragraph} />
                  </p>
                ))}
              </div>
              {block.table && (
                <div className="scroll-thin mt-5 overflow-x-auto rounded-xl border border-white/8">
                  <table className="w-full min-w-[420px] border-collapse text-left text-sm">
                    <caption className="border-b border-white/8 bg-white/[0.03] px-4 py-2 text-left text-xs text-slate-400">
                      {block.table.caption}
                    </caption>
                    <thead>
                      <tr className="bg-white/[0.04]">
                        {block.table.headers.map((header) => (
                          <th
                            key={header}
                            className="px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400"
                          >
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {block.table.rows.map((row, ri) => (
                        <tr key={ri} className="border-t border-white/6 hover:bg-white/[0.03]">
                          {row.map((cell, ci) => (
                            <td
                              key={ci}
                              className={`px-4 py-2 align-top ${
                                /[\u0370-\u03FF\u1F00-\u1FFF]/.test(cell)
                                  ? "greek text-[15px] text-amber-100/90"
                                  : "text-slate-300"
                              }`}
                            >
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {block.tip && (
                <p className="mt-4 rounded-xl border border-sky-400/20 bg-sky-400/8 p-3 text-xs leading-relaxed text-sky-200/90">
                  <span className="font-semibold">Tip · </span>
                  <GreekRich text={block.tip} />
                </p>
              )}
            </article>
          ))}
        </section>
      )}

      {tab === "vocab" && (
        <section className="space-y-4">
          <Intro
            title="Lesson vocabulary + flashcards"
            body="Every word here becomes a flashcard in the Cards tab and enters your SRS deck when you review in Vocabulary. Tap ▶ to hear it, then flip it in cards."
          />
          <div className="grid gap-3 sm:grid-cols-2">
            {vocab.map((word) => (
              <div key={word.id} className="panel rounded-2xl p-4">
                <div className="flex items-start gap-3">
                  <SpeakButton text={word.lemma.split(",")[0]} id={`v-${word.id}`} />
                  <div className="min-w-0">
                    <p className="greek text-xl leading-tight text-amber-100">{word.lemma}</p>
                    <p className="text-xs text-slate-500">{word.translit}</p>
                    <p className="mt-1 text-sm text-slate-200">{word.gloss}</p>
                    <p className="mt-1 text-[11px] leading-relaxed text-slate-500">{word.detail}</p>
                    <div className="mt-2 flex flex-wrap gap-1.5 text-[10px] text-slate-500">
                      <span className="rounded bg-white/5 px-1.5 py-0.5">{word.pos}</span>
                      {word.frequency > 0 && (
                        <span className="rounded bg-white/5 px-1.5 py-0.5">{word.frequency}× in NT</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <Link
            href="/vocabulary"
            className="inline-block rounded-xl border border-white/15 px-4 py-2.5 text-sm text-slate-200 hover:border-amber-400/50 hover:text-amber-200"
          >
            Drill these in the SRS trainer →
          </Link>
        </section>
      )}

      {tab === "cards" && <LessonFlashcardsPanel cards={lessonCards} lessonSlug={lesson.slug} />}

      {tab === "read" && lesson.reading && (
        <section className="space-y-4">
          <Intro title={lesson.reading.ref} body={lesson.reading.intro} />
          <div className="space-y-3">
            {lesson.reading.verses.map((verse, i) => (
              <ReadingVerse key={i} greek={verse.greek} english={verse.english} index={i} />
            ))}
          </div>
          <Link
            href="/reader"
            className="inline-block rounded-xl border border-white/15 px-4 py-2.5 text-sm text-slate-200 hover:border-amber-400/50 hover:text-amber-200"
          >
            Open the full interlinear reader →
          </Link>
        </section>
      )}

      {tab === "assignments" && <AssignmentsPanel assignments={assignments} lessonSlug={lesson.slug} />}

      {tab === "quiz" && (
        <section className="space-y-4">
          <Intro
            title="Check your understanding"
            body="Answer every question, then submit. Explanations appear for each item — including the ones you got right. This is not a test, it's a second teaching pass."
          />
          {lesson.quiz.map((item, qi) => {
            const chosen = answers[qi];
            return (
              <article key={qi} className="panel rounded-2xl p-5">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-white/8 text-xs text-slate-400">
                    {qi + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-slate-100">{item.prompt}</p>
                    {item.greek && (
                      <div className="mt-2 flex items-center gap-2">
                        <SpeakButton text={item.greek} id={`q-${lesson.slug}-${qi}`} size="sm" />
                        <span className="greek text-xl text-amber-100">{item.greek}</span>
                      </div>
                    )}
                    <div className="mt-3 grid gap-2">
                      {item.options.map((option, oi) => {
                        const isChosen = chosen === oi;
                        const isCorrect = oi === item.answer;
                        let tone =
                          "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/25";
                        if (submitted && isCorrect)
                          tone = "border-emerald-400/50 bg-emerald-400/12 text-emerald-100";
                        else if (submitted && isChosen)
                          tone = "border-rose-400/50 bg-rose-400/12 text-rose-100";
                        else if (isChosen) tone = "border-amber-400/60 bg-amber-400/12 text-amber-100";
                        return (
                          <button
                            key={oi}
                            type="button"
                            disabled={submitted}
                            onClick={() => setAnswers((a) => ({ ...a, [qi]: oi }))}
                            className={`rounded-xl border px-3.5 py-2.5 text-left text-sm transition ${tone} disabled:cursor-default`}
                          >
                            <span className="mr-2 text-xs text-slate-500">
                              {String.fromCharCode(65 + oi)}
                            </span>
                            <span className={/[\u0370-\u03FF\u1F00-\u1FFF]/.test(option) ? "greek" : ""}>
                              {option}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                    {submitted && (
                      <p className="mt-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-xs leading-relaxed text-slate-300">
                        <span
                          className={
                            chosen === item.answer
                              ? "font-semibold text-emerald-300"
                              : "font-semibold text-rose-300"
                          }
                        >
                          {chosen === item.answer ? "Correct · " : "Not quite · "}
                        </span>
                        <GreekRich text={item.explain} />
                      </p>
                    )}
                  </div>
                </div>
              </article>
            );
          })}

          <div className="panel flex flex-wrap items-center gap-3 rounded-2xl p-5">
            {!submitted ? (
              <button
                type="button"
                disabled={!allAnswered}
                onClick={() => setSubmitted(true)}
                className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-5 py-2.5 text-sm font-semibold text-slate-950 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Submit answers
              </button>
            ) : (
              <>
                <span className="text-sm text-slate-300">
                  Score: <span className="font-semibold text-amber-300">{score}%</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    setAnswers({});
                  }}
                  className="rounded-xl border border-white/15 px-4 py-2.5 text-sm text-slate-300 hover:text-slate-100"
                >
                  Retry
                </button>
              </>
            )}
            <button
              type="button"
              onClick={markComplete}
              disabled={saving}
              className="ml-auto rounded-xl border border-emerald-400/40 bg-emerald-500/15 px-5 py-2.5 text-sm font-semibold text-emerald-200 transition hover:bg-emerald-500/25 disabled:opacity-50"
            >
              {completed ? "✓ Marked complete — save again" : saving ? "Saving…" : "Mark lesson complete"}
            </button>
          </div>
        </section>
      )}

      <div className="grid gap-4 lg:grid-cols-[1fr_1.4fr]">
        <VoiceSettings />
        <div className="grid gap-3 sm:grid-cols-2">
          {prev ? (
            <Link href={`/learn/${prev.slug}`} className="panel panel-hover rounded-2xl p-4 transition">
              <p className="text-[11px] uppercase tracking-wider text-slate-500">← Previous</p>
              <p className="mt-1 text-sm font-medium text-slate-200">{prev.title}</p>
            </Link>
          ) : (
            <div />
          )}
          {next && (
            <Link
              href={`/learn/${next.slug}`}
              className="panel panel-hover rounded-2xl p-4 text-right transition"
            >
              <p className="text-[11px] uppercase tracking-wider text-slate-500">Next →</p>
              <p className="mt-1 text-sm font-medium text-slate-200">{next.title}</p>
            </Link>
          )}
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-emerald-400/40 bg-emerald-500/20 px-5 py-3 text-sm font-medium text-emerald-100 shadow-2xl backdrop-blur">
          {toast}
        </div>
      )}
    </div>
  );
}

function Intro({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.06] p-4">
      <h3 className="text-sm font-semibold text-amber-200">{title}</h3>
      <p className="mt-1 text-xs leading-relaxed text-amber-100/70">{body}</p>
    </div>
  );
}

function DeepGuidePanel({ guide }: { guide: ReturnType<typeof deepGuideFor> }) {
  if (!guide) return null;
  return (
    <section className="space-y-6">
      <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.06] p-5">
        <p className="greek text-sm text-amber-300/70">Βαθὺς λόγος · Deep Guide</p>
        <p className="mt-2 text-sm leading-relaxed text-amber-100/80">{guide.intro}</p>
        <p className="mt-2 text-[11px] text-amber-200/60">
          How to use: Read this like a letter from a tutor, not a textbook. Pause on each English vs Greek comparison and say both aloud. Then try the Think Like Greek prompts.
        </p>
      </div>

      {guide.sections.map((section) => (
        <article key={section.id} className="panel rounded-2xl p-5 sm:p-7">
          <h3 className="text-xl font-semibold text-amber-100">{section.title}</h3>
          {section.subtitle && <p className="mt-1 text-xs uppercase tracking-wider text-slate-500">{section.subtitle}</p>}

          <div className="mt-4 space-y-3">
            {section.body.map((p, i) => (
              <p key={i} className="text-[14px] leading-relaxed text-slate-300">
                <GreekRich text={p} />
              </p>
            ))}
          </div>

          {section.englishVsGreek && section.englishVsGreek.length > 0 && (
            <div className="mt-6">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-sky-300">English → Greek Bridges</h4>
              <div className="mt-3 grid gap-3">
                {section.englishVsGreek.map((eg, i) => (
                  <div key={i} className="rounded-xl border border-white/8 bg-white/[0.02] p-3">
                    <div className="grid gap-2 sm:grid-cols-2">
                      <div>
                        <p className="text-[11px] uppercase tracking-wider text-slate-500">English</p>
                        <p className="mt-1 text-sm text-slate-200">{eg.english}</p>
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-wider text-amber-400/70">Greek</p>
                        <p className="greek mt-1 text-sm text-amber-100">{eg.greek}</p>
                      </div>
                    </div>
                    <p className="mt-2 text-xs leading-relaxed text-sky-200/80">
                      <span className="font-semibold">Why this matters: </span>
                      {eg.whyItMatters}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section.examples && section.examples.length > 0 && (
            <div className="mt-6">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-emerald-300">Examples — say them, break them, own them</h4>
              <div className="mt-3 grid gap-3">
                {section.examples.map((ex, i) => (
                  <div key={i} className="rounded-xl border border-white/8 bg-white/[0.03] p-4">
                    <div className="flex items-start gap-3">
                      <SpeakButton text={ex.greek} id={`ex-${section.id}-${i}`} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="greek text-xl text-amber-100">{ex.greek}</p>
                        {ex.translit && <p className="text-[11px] text-slate-500">{ex.translit}</p>}
                        <p className="mt-1 text-xs text-slate-500">
                          <span className="text-slate-400">Literal: </span>
                          {ex.literal} → <span className="text-slate-200">{ex.natural}</span>
                        </p>
                        <p className="mt-2 rounded-lg bg-white/[0.02] p-2 text-xs leading-relaxed text-slate-400">
                          <span className="font-semibold text-slate-300">Breakdown: </span>
                          <GreekRich text={ex.breakdown} />
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section.thinkLikeGreek && section.thinkLikeGreek.length > 0 && (
            <div className="mt-6 rounded-xl border border-fuchsia-400/20 bg-fuchsia-400/5 p-4">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-fuchsia-300">Think Like Greek — try today</h4>
              <ul className="mt-2 list-disc space-y-1 pl-5 text-xs leading-relaxed text-fuchsia-100/80">
                {section.thinkLikeGreek.map((t, i) => (
                  <li key={i}>
                    <GreekRich text={t} />
                  </li>
                ))}
              </ul>
            </div>
          )}

          {section.commonPitfalls && section.commonPitfalls.length > 0 && (
            <div className="mt-5 rounded-xl border border-rose-400/20 bg-rose-400/5 p-4">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-rose-300">Common pitfalls</h4>
              <ul className="mt-2 list-disc space-y-1 pl-5 text-xs leading-relaxed text-rose-100/80">
                {section.commonPitfalls.map((p, i) => (
                  <li key={i}>
                    <GreekRich text={p} />
                  </li>
                ))}
              </ul>
            </div>
          )}

          {section.memoryTrick && (
            <p className="mt-5 rounded-xl border border-amber-400/20 bg-amber-400/10 p-3 text-xs leading-relaxed text-amber-200">
              <span className="font-semibold">Memory hook: </span>
              {section.memoryTrick}
            </p>
          )}
        </article>
      ))}
    </section>
  );
}

function LessonFlashcardsPanel({ cards, lessonSlug }: { cards: LessonCard[]; lessonSlug: string }) {
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [done, setDone] = useState(false);
  const [queue, setQueue] = useState(cards);
  const [session, setSession] = useState({ right: 0, total: 0 });

  useEffect(() => {
    setQueue(cards);
    setIndex(0);
    setFlipped(false);
  }, [cards]);

  const card = queue[index];

  async function rate(rating: Rating) {
    if (!card) return;
    setSession((s) => ({ right: s.right + (rating >= 2 ? 1 : 0), total: s.total + 1 }));
    try {
      rateLessonCard(`${lessonSlug}:${card.id}`, rating);
    } catch {}
    if (rating === 0) {
      // again → put back into queue soon
      setQueue((q) => {
        const copy = [...q];
        const [removed] = copy.splice(index, 1);
        copy.splice(Math.min(index + 2, copy.length), 0, removed);
        return copy;
      });
      setFlipped(false);
    } else if (index + 1 >= queue.length) {
      setDone(true);
    } else {
      setIndex((i) => i + 1);
      setFlipped(false);
    }
  }

  if (!cards.length) {
    return <p className="panel rounded-2xl p-6 text-sm text-slate-500">No flashcards for this lesson yet.</p>;
  }

  if (done) {
    return (
      <section className="panel flex flex-col items-center justify-center rounded-3xl p-10 text-center">
        <p className="greek text-3xl text-amber-200">εὖγε!</p>
        <p className="mt-1 text-[11px] uppercase tracking-wider text-amber-300/60">EV-yeh · well done</p>
        <p className="mt-2 text-sm text-slate-300">
          Done — {session.right}/{session.total} correct.
        </p>
        <button
          type="button"
          onClick={() => {
            setDone(false);
            setIndex(0);
            setQueue(cards);
            setFlipped(false);
            setSession({ right: 0, total: 0 });
          }}
          className="mt-4 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-5 py-2.5 text-sm font-semibold text-slate-950"
        >
          Restart deck
        </button>
      </section>
    );
  }

  return (
    <section className="space-y-4">
      <Intro
        title="Flip cards — active recall is king"
        body="Front is Greek or a question, back is meaning + memory hook. Rate honestly: Again = forgot, Hard = slow, Good = recalled, Easy = instant. SRS reschedules automatically."
      />
      <div className="panel relative min-h-[380px] rounded-3xl p-6 sm:p-8">
        <div className="mb-4 flex items-center justify-between text-xs text-slate-500">
          <span>
            Card {index + 1} of {queue.length}
          </span>
          <span>
            {session.right}/{session.total} this session
          </span>
        </div>

        <button
          type="button"
          onClick={() => setFlipped((f) => !f)}
          className="group relative flex min-h-[220px] w-full flex-col items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 p-6 text-center transition hover:border-amber-400/30"
        >
          <span className="absolute right-3 top-3 rounded-full bg-white/5 px-2 py-0.5 text-[10px] text-slate-500">
            {flipped ? "Answer" : "Question"} · tap to flip
          </span>

          <div className="flex items-center gap-3">
            {!flipped && <SpeakButton text={card.front} id={`fc-${card.id}`} size="lg" />}
            <p
              className={`text-center ${/[\u0370-\u03FF\u1F00-\u1FFF]/.test(flipped ? card.back : card.front) ? "greek text-3xl leading-tight text-amber-100 sm:text-4xl" : "text-2xl font-semibold text-slate-100 sm:text-3xl"}`}
            >
              {flipped ? card.back : card.front}
            </p>
          </div>

          {flipped ? (
            <>
              {card.extra && (
                <p className="mt-3 max-w-xl text-xs leading-relaxed text-slate-400">
                  <GreekRich text={card.extra} />
                </p>
              )}
              {card.hint && (
                <p className="mt-3 text-[11px] text-slate-500">
                  Hint: <GreekRich text={card.hint} />
                </p>
              )}
            </>
          ) : (
            card.hint && (
              <p className="mt-3 text-xs text-slate-500">
                <span className="text-slate-400">Hint:</span> {card.hint}
              </p>
            )
          )}

          <p className="mt-4 text-[11px] uppercase tracking-wider text-slate-600">
            {card.type} · {flipped ? "now rate how well you knew it" : "do you know it? flip to check"}
          </p>
        </button>

        {flipped && (
          <div className="mt-6 grid grid-cols-4 gap-2">
            {RATING_LABELS.map((r) => (
              <button
                key={r.value}
                type="button"
                onClick={() => rate(r.value as Rating)}
                className={`rounded-xl px-2 py-3 text-xs font-semibold text-white transition ${r.tone}`}
              >
                {r.label}
                <span className="mt-0.5 block text-[10px] font-normal opacity-75">{r.hint}</span>
              </button>
            ))}
          </div>
        )}

        {!flipped && (
          <button
            type="button"
            onClick={() => setFlipped(true)}
            className="mx-auto mt-6 block rounded-xl border border-white/15 px-5 py-2.5 text-sm text-slate-300 hover:text-slate-100"
          >
            Show answer
          </button>
        )}
      </div>
    </section>
  );
}

function AssignmentsPanel({ assignments, lessonSlug }: { assignments: Assignment[]; lessonSlug: string }) {
  const [open, setOpen] = useState<string | null>(assignments[0]?.id ?? null);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState<Set<string>>(new Set());

  useEffect(() => {
    const stored = readProgress().assignments;
    const ids = assignments.filter((a) => stored[a.id]).map((a) => a.id);
    setSubmitted(new Set(ids));
    setDrafts(
      Object.fromEntries(assignments.filter((a) => stored[a.id]).map((a) => [a.id, stored[a.id].body])),
    );
  }, [assignments]);

  async function submit(a: Assignment) {
    const body = drafts[a.id];
    if (!body?.trim()) {
      setStatus((s) => ({ ...s, [a.id]: "Write something first." }));
      return;
    }
    setStatus((s) => ({ ...s, [a.id]: "Saving…" }));
    try {
      const data = saveAssignment(a.id, lessonSlug, body, a.xp);
      setSubmitted((set) => new Set([...set, a.id]));
      setStatus((s) => ({
        ...s,
        [a.id]: data.xp > 0 ? `Saved · +${data.xp} XP` : "Updated on this device",
      }));
    } catch {
      setStatus((s) => ({ ...s, [a.id]: "Could not save in this browser." }));
    }
  }

  return (
    <section className="space-y-4">
      <Intro
        title="Do the work — then compare with model"
        body="Every assignment has English bridges explaining how English does the same job as Greek. Write your attempt first, then reveal model answers. Submitting earns XP."
      />

      <div className="space-y-3">
        {assignments.map((a) => {
          const isOpen = open === a.id;
          const isDone = submitted.has(a.id);
          return (
            <article key={a.id} className="panel rounded-2xl">
              <button
                type="button"
                onClick={() => setOpen(isOpen ? null : a.id)}
                className="flex w-full items-start justify-between gap-3 p-5 text-left"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`rounded-full border px-2 py-0.5 text-[10px] uppercase tracking-wider ${
                        a.tier === "practice"
                          ? "border-sky-400/30 bg-sky-400/10 text-sky-300"
                          : a.tier === "challenge"
                            ? "border-amber-400/30 bg-amber-400/10 text-amber-300"
                            : "border-fuchsia-400/30 bg-fuchsia-400/10 text-fuchsia-300"
                      }`}
                    >
                      {a.tier}
                    </span>
                    <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-slate-400">
                      {a.kind}
                    </span>
                    <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-2 py-0.5 text-[10px] text-emerald-300">
                      +{a.xp} XP
                    </span>
                    {isDone && (
                      <span className="rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2 py-0.5 text-[10px] text-emerald-200">
                        ✓ submitted
                      </span>
                    )}
                  </div>
                  <h3 className="mt-2 text-sm font-semibold text-slate-100">{a.title}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-slate-400">{a.instruction}</p>
                </div>
                <span className="shrink-0 text-slate-500">{isOpen ? "−" : "+"}</span>
              </button>

              {isOpen && (
                <div className="border-t border-white/8 p-5">
                  <div className="rounded-xl border border-sky-400/20 bg-sky-400/5 p-3">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-sky-300">English bridge</p>
                    <p className="mt-1 text-xs leading-relaxed text-sky-100/80">{a.englishBridge}</p>
                  </div>

                  <div className="mt-4 space-y-3">
                    {a.tasks.map((t, i) => (
                      <div key={i} className="rounded-xl border border-white/8 bg-white/[0.02] p-3">
                        <p className="text-sm text-slate-200">
                          <span className="mr-2 text-xs text-slate-500">{i + 1}.</span>
                          <GreekRich text={t.prompt} />
                        </p>
                        {t.starter && (
                          <p className="mt-1 text-xs text-slate-500">
                            Starter: <span className="greek text-amber-100/80">{t.starter}</span>
                          </p>
                        )}
                        {t.hint && <p className="mt-1 text-[11px] text-slate-500">Hint: {t.hint}</p>}
                      </div>
                    ))}
                  </div>

                  <label className="mt-5 block">
                    <span className="text-xs font-medium text-slate-400">Your attempt — write here, then compare</span>
                    <textarea
                      value={drafts[a.id] ?? ""}
                      onChange={(e) => setDrafts((d) => ({ ...d, [a.id]: e.target.value }))}
                      rows={5}
                      placeholder="Type your answer in Greek + English. Explain your reasoning like you are teaching it..."
                      className="mt-2 w-full resize-y rounded-xl border border-white/10 bg-slate-900/70 p-3 text-sm text-slate-200 outline-none placeholder:text-slate-600 focus:border-amber-400/50"
                    />
                  </label>

                  <div className="mt-3 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => submit(a)}
                      className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-5 py-2.5 text-sm font-semibold text-slate-950"
                    >
                      Submit attempt (+{a.xp} XP)
                    </button>
                    {status[a.id] && <span className="text-xs text-emerald-300">{status[a.id]}</span>}
                  </div>

                  <details className="mt-5 rounded-xl border border-white/8 bg-white/[0.02] p-4">
                    <summary className="cursor-pointer text-xs font-semibold text-amber-300">Reveal model answers (try yourself first)</summary>
                    <div className="mt-3 space-y-2">
                      {a.modelAnswers.map((ma, i) => (
                        <div key={i} className="rounded-lg bg-white/[0.02] p-3">
                          <p className="text-xs text-slate-200">
                            <GreekRich text={ma.answer} />
                          </p>
                          <p className="mt-1 text-[11px] text-slate-500">
                            <span className="font-semibold text-slate-400">Note: </span>
                            {ma.note}
                          </p>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4">
                      <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Rubric — self-check</p>
                      <ul className="mt-1 list-disc space-y-0.5 pl-5 text-[11px] text-slate-500">
                        {a.rubric.map((r, i) => (
                          <li key={i}>{r}</li>
                        ))}
                      </ul>
                    </div>
                    {a.tasks.length > 0 && a.tasks[0].prompt && (
                      <div className="mt-3">
                        <p className="text-[11px] font-semibold text-slate-400">Tips</p>
                        <ul className="mt-1 list-disc space-y-0.5 pl-5 text-[11px] text-slate-500">
                          {a.tasks.map((_, i) => null)}
                          {(assignments.find((x) => x.id === a.id)?.modelAnswers?.length ? [] : []).map((_, i) => null)}
                        </ul>
                      </div>
                    )}
                  </details>
                </div>
              )}
            </article>
          );
        })}
      </div>
    </section>
  );
}

function ListenPanel({ lesson }: { lesson: Lesson }) {
  const { speakSequence, supported } = useGreekAudio();
  const [hideGloss, setHideGloss] = useState(false);
  const [playingAll, setPlayingAll] = useState(false);

  async function playAll() {
    if (!supported) return;
    setPlayingAll(true);
    await speakSequence(
      lesson.listening.map((item) => ({ text: item.greek, id: `l-${item.greek}` })),
    );
    setPlayingAll(false);
  }

  return (
    <section className="space-y-4">
      <Intro
        title="Audio drill — say it out loud until it feels like English"
        body="Greek was heard long before it was parsed. Play each line, then repeat aloud imitating rhythm. Hide glosses on second pass — if you can understand without English, you're thinking in Greek."
      />
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={playAll}
          disabled={!supported || playingAll}
          className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-4 py-2.5 text-sm font-semibold text-slate-950 disabled:opacity-40"
        >
          {playingAll ? "Playing…" : "▶ Play all lines"}
        </button>
        <button
          type="button"
          onClick={() => setHideGloss((v) => !v)}
          className="rounded-xl border border-white/15 px-4 py-2.5 text-sm text-slate-300 hover:text-slate-100"
        >
          {hideGloss ? "Show glosses" : "Hide glosses (think in Greek)"}
        </button>
      </div>
      <div className="grid gap-2.5">
        {lesson.listening.map((item, i) => (
          <div key={i} className="panel flex items-start gap-3 rounded-2xl p-4">
            <SpeakButton text={item.greek} id={`l-${item.greek}`} />
            <div className="min-w-0 flex-1">
              <p className="greek text-xl leading-snug text-amber-100">{item.greek}</p>
              {item.translit && <p className="text-[11px] text-slate-500">{item.translit}</p>}
              <p
                className={`mt-1 text-sm text-slate-400 transition ${hideGloss ? "select-none blur-sm hover:blur-none" : ""}`}
              >
                {item.gloss}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ReadingVerse({ greek, english, index }: { greek: string; english: string; index: number }) {
  const [show, setShow] = useState(false);
  return (
    <article className="panel rounded-2xl p-5">
      <div className="flex items-start gap-3">
        <SpeakButton text={greek} id={`r-${index}`} size="lg" />
        <div className="min-w-0 flex-1">
          <p className="greek text-xl leading-relaxed text-amber-50 sm:text-2xl">{greek}</p>
          <button
            type="button"
            onClick={() => setShow((v) => !v)}
            className="mt-3 text-xs text-slate-500 underline-offset-2 hover:text-amber-300 hover:underline"
          >
            {show ? "Hide translation" : "Reveal translation"}
          </button>
          {show && <p className="mt-2 text-sm leading-relaxed text-slate-300">{english}</p>}
        </div>
      </div>
    </article>
  );
}

function GreekRich({ text }: { text: string }) {
  const parts = text.split(/([\u0370-\u03FF\u1F00-\u1FFF][\u0370-\u03FF\u1F00-\u1FFF\s,.·᾽'’\-()]*)/g);
  return (
    <>
      {parts.map((part, i) =>
        /[\u0370-\u03FF\u1F00-\u1FFF]/.test(part) ? (
          <span key={i} className="greek text-[1.08em] text-amber-100/90">
            {part}
          </span>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </>
  );
}
