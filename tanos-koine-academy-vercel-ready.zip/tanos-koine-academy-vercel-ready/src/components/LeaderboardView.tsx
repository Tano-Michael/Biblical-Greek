"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { GAMES } from "@/lib/games";
import { getProgressBoard, setDisplayName } from "@/lib/localProgress";

type Row = {
  id: number;
  displayName: string;
  xp: number;
  streak: number;
  weeklyXp: number;
  lessonsDone: number;
};

type Me = {
  id: number;
  displayName: string;
  xp: number;
  streak: number;
  rank: number;
  weeklyXp: number;
  lessonsDone: number;
};

type GameRow = { rank: number; name: string; learnerId: number; score: number; plays: number };

type Data = {
  me: Me;
  allTime: Row[];
  byWeek: Row[];
  games: Record<string, GameRow[]>;
};

export function LeaderboardView() {
  const [data, setData] = useState<Data | null>(null);
  const [tab, setTab] = useState<"all" | "week" | "games">("all");
  const [game, setGame] = useState(GAMES[0].id);
  const [name, setName] = useState("");
  const [nameStatus, setNameStatus] = useState<string | null>(null);
  const [savingName, setSavingName] = useState(false);

  const load = useCallback(async () => {
    const json = getProgressBoard() as Data;
    setData(json);
    setName(json.me.displayName);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function saveName() {
    if (!name.trim() || savingName) return;
    setSavingName(true);
    setNameStatus(null);
    try {
      setDisplayName(name.trim());
      setNameStatus("Name saved on this device");
      await load();
    } catch {
      setNameStatus("Could not save name");
    } finally {
      setSavingName(false);
      setTimeout(() => setNameStatus(null), 2500);
    }
  }

  if (!data) {
    return (
      <div className="panel flex h-64 items-center justify-center rounded-3xl text-sm text-slate-500">
        Loading your progress…
      </div>
    );
  }

  const rows = tab === "all" ? data.allTime : data.byWeek;

  return (
    <div className="space-y-6">
      {/* Profile card */}
      <section className="panel rise grid gap-4 rounded-3xl p-5 sm:grid-cols-[1fr_auto] sm:items-center">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Your learning profile</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-amber-400/15 px-3 py-1 text-sm font-bold text-amber-300">
              Device profile
            </span>
            <span className="text-lg font-semibold text-slate-100">{data.me.displayName}</span>
          </div>
          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            <Badge label="Total XP" value={String(data.me.xp)} />
            <Badge label="This week" value={String(data.me.weeklyXp)} />
            <Badge label="Streak" value={`${data.me.streak}🔥`} />
            <Badge label="Lessons" value={String(data.me.lessonsDone)} />
          </div>
        </div>
        <div className="min-w-[240px]">
          <label className="block text-[11px] uppercase tracking-wider text-slate-500">
            Display name on this device
          </label>
          <div className="mt-1.5 flex gap-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={40}
              className="w-full rounded-xl border border-white/10 bg-slate-900/70 px-3 py-2 text-sm text-slate-200 outline-none focus:border-amber-400/50"
              placeholder="Your name…"
            />
            <button
              type="button"
              onClick={saveName}
              disabled={savingName}
              className="shrink-0 rounded-xl bg-amber-400/20 px-4 py-2 text-sm font-semibold text-amber-200 hover:bg-amber-400/30 disabled:opacity-50"
            >
              Save
            </button>
          </div>
          {nameStatus && <p className="mt-1.5 text-xs text-emerald-300">{nameStatus}</p>}
        </div>
      </section>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1.5">
        {(
          [
            ["all", "🏆 Total progress"],
            ["week", "📅 This week"],
            ["games", "🎮 Game records"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`rounded-xl px-4 py-2.5 text-sm font-medium transition ${
              tab === id
                ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/30"
                : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "games" ? (
        <section className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {GAMES.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => setGame(g.id)}
                className={`rounded-xl border px-4 py-2 text-sm transition ${
                  game === g.id
                    ? "border-amber-400/50 bg-amber-400/10 text-amber-200"
                    : "border-white/10 bg-white/[0.03] text-slate-400 hover:text-slate-200"
                }`}
              >
                {g.emoji} {g.name}
              </button>
            ))}
          </div>

          <div className="panel overflow-hidden rounded-3xl">
            <table className="w-full text-left text-sm">
              <thead className="bg-white/[0.04] text-[11px] uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-4 py-3">Record</th>
                  <th className="px-4 py-3">Player</th>
                  <th className="px-4 py-3 text-right">Best score</th>
                  <th className="hidden px-4 py-3 text-right sm:table-cell">Games played</th>
                </tr>
              </thead>
              <tbody>
                {(data.games[game] ?? []).length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-4 py-10 text-center text-sm text-slate-500">
                      No scores yet — set your first record. <Link href={`/games/${game}`} className="text-amber-300 underline underline-offset-2">Play now →</Link>
                    </td>
                  </tr>
                )}
                {(data.games[game] ?? []).map((row) => (
                  <tr
                    key={row.learnerId}
                    className={`border-t border-white/6 ${
                      row.learnerId === data.me.id ? "bg-amber-400/8" : "hover:bg-white/[0.02]"
                    }`}
                  >
                    <td className="px-4 py-3 text-base">
                      <span title="Personal record">⭐</span>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-100">
                      {row.name}
                      {row.learnerId === data.me.id && (
                        <span className="ml-2 rounded bg-amber-400/20 px-1.5 py-0.5 text-[10px] text-amber-200">you</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-amber-300">{row.score}</td>
                    <td className="hidden px-4 py-3 text-right text-slate-500 sm:table-cell">{row.plays}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : (
        <section className="panel overflow-hidden rounded-3xl">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/[0.04] text-[11px] uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-4 py-3">Record</th>
                <th className="px-4 py-3">Learner</th>
                <th className="px-4 py-3 text-right">{tab === "all" ? "Total XP" : "Weekly XP"}</th>
                <th className="hidden px-4 py-3 text-right sm:table-cell">Streak</th>
                <th className="hidden px-4 py-3 text-right md:table-cell">Lessons</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr
                  key={row.id}
                  className={`border-t border-white/6 ${
                    row.id === data.me.id ? "bg-amber-400/8" : "hover:bg-white/[0.02]"
                  }`}
                >
                  <td className="px-4 py-3 text-base">
                    <span title="Your device profile">⭐</span>
                  </td>
                  <td className="px-4 py-3 font-medium text-slate-100">
                    {row.displayName}
                    {row.id === data.me.id && (
                      <span className="ml-2 rounded bg-amber-400/20 px-1.5 py-0.5 text-[10px] text-amber-200">you</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-amber-300">
                    {tab === "all" ? row.xp : row.weeklyXp}
                  </td>
                  <td className="hidden px-4 py-3 text-right text-slate-400 sm:table-cell">{row.streak}🔥</td>
                  <td className="hidden px-4 py-3 text-right text-slate-400 md:table-cell">{row.lessonsDone}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}

    </div>
  );
}

function Badge({ label, value }: { label: string; value: string }) {
  return (
    <span className="rounded-lg border border-white/10 bg-white/[0.03] px-2.5 py-1.5 text-slate-300">
      <span className="text-slate-500">{label} </span>
      <span className="font-semibold text-slate-100">{value}</span>
    </span>
  );
}
