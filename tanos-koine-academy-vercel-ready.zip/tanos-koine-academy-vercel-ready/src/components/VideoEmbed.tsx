"use client";

import { useState } from "react";

export type VideoEmbedProps = {
  id: string;
  kind?: "video" | "playlist";
  title: string;
  channel?: string;
  note?: string;
  compact?: boolean;
};

export function VideoEmbed({ id, kind = "video", title, channel, note, compact }: VideoEmbedProps) {
  const [playing, setPlaying] = useState(false);

  const src =
    kind === "playlist"
      ? `https://www.youtube-nocookie.com/embed/videoseries?list=${id}&autoplay=1&rel=0`
      : `https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0&modestbranding=1`;

  const watchUrl =
    kind === "playlist"
      ? `https://www.youtube.com/playlist?list=${id}`
      : `https://www.youtube.com/watch?v=${id}`;

  const thumb =
    kind === "playlist" ? null : `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;

  return (
    <figure className="panel panel-hover overflow-hidden rounded-2xl transition">
      <div className="relative aspect-video w-full bg-slate-900">
        {playing ? (
          <iframe
            src={src}
            title={title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            loading="lazy"
            className="absolute inset-0 h-full w-full"
          />
        ) : (
          <button
            type="button"
            onClick={() => setPlaying(true)}
            className="group absolute inset-0 flex h-full w-full items-center justify-center"
          >
            {thumb ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={thumb}
                alt=""
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover opacity-65 transition group-hover:opacity-85"
              />
            ) : (
              <div className="absolute inset-0 bg-gradient-to-br from-sky-900/60 via-slate-900 to-fuchsia-900/40" />
            )}
            <span className="relative z-10 flex h-16 w-16 items-center justify-center rounded-full bg-red-600/90 text-2xl text-white shadow-2xl transition group-hover:scale-110">
              ▶
            </span>
            {kind === "playlist" && (
              <span className="absolute bottom-3 right-3 z-10 rounded-md bg-black/70 px-2 py-1 text-[11px] font-medium text-slate-200">
                Full playlist
              </span>
            )}
          </button>
        )}
      </div>
      <figcaption className={`space-y-1 ${compact ? "p-3" : "p-4"}`}>
        <h4 className="text-sm leading-snug font-semibold text-slate-100">{title}</h4>
        {channel && <p className="text-xs text-amber-300/80">{channel}</p>}
        {note && <p className="text-xs leading-relaxed text-slate-400">{note}</p>}
        <a
          href={watchUrl}
          target="_blank"
          rel="noreferrer noopener"
          className="inline-block pt-1 text-[11px] text-slate-500 underline-offset-2 hover:text-slate-300 hover:underline"
        >
          Open on YouTube ↗
        </a>
      </figcaption>
    </figure>
  );
}
