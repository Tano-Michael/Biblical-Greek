"use client";

import { useMemo, useState } from "react";
import type { InterWord, Passage } from "@/lib/content/readings";
import { GreekAudioProvider, SpeakButton, VoiceSettings, useGreekAudio } from "@/components/GreekAudio";
import { saveNote as saveLocalNote } from "@/lib/localProgress";

export function ReaderView({ passages }: { passages: Passage[] }) {
  return (
    <GreekAudioProvider>
      <Inner passages={passages} />
    </GreekAudioProvider>
  );
}

function Inner({ passages }: { passages: Passage[] }) {
  const [activeId, setActiveId] = useState(passages[0].id);
  const [glossMode, setGlossMode] = useState<"tap" | "always" | "never">("tap");
  const [selected, setSelected] = useState<InterWord | null>(null);
  const [showEnglish, setShowEnglish] = useState(false);
  const [noteBody, setNoteBody] = useState("");
  const [noteStatus, setNoteStatus] = useState<string | null>(null);
  const { speakSequence, supported } = useGreekAudio();
  const [reading, setReading] = useState(false);

  const passage = useMemo(
    () => passages.find((p) => p.id === activeId) ?? passages[0],
    [passages, activeId],
  );

  async function readWholePassage() {
    if (!supported) return;
    setReading(true);
    await speakSequence(
      passage.verses.map((verse) => ({
        text: verse.words.map((word) => word.g).join(" "),
        id: `pv-${verse.ref}`,
      })),
    );
    setReading(false);
  }

  async function saveNote() {
    if (!noteBody.trim()) return;
    setNoteStatus("Saving…");
    try {
      saveLocalNote(passage.reference, noteBody);
      setNoteBody("");
      setNoteStatus("Saved to this device.");
    } catch {
      setNoteStatus("Could not save.");
    }
    setTimeout(() => setNoteStatus(null), 3000);
  }

  return (
    <div className="space-y-6">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Ἀνάγνωσις</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Interlinear Reader</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          Tap any Greek word to see its lemma, full parsing and gloss. Play the verse aloud, hide the helps,
          and read it again. Aim to need the glosses less each pass.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        {passages.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => {
              setActiveId(p.id);
              setSelected(null);
              setShowEnglish(false);
            }}
            className={`rounded-xl px-4 py-2.5 text-left text-sm transition ${
              p.id === activeId
                ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/30"
                : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
            }`}
          >
            <span className="block font-medium">{p.title}</span>
            <span className="block text-[11px] opacity-70">
              {p.reference} · {p.level}
            </span>
          </button>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.7fr_1fr]">
        <section className="space-y-4">
          <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.06] p-4">
            <h2 className="text-sm font-semibold text-amber-200">{passage.reference}</h2>
            <p className="mt-1 text-xs leading-relaxed text-amber-100/70">{passage.blurb}</p>
            <p className="mt-2 text-[11px] italic text-amber-100/50">{passage.audioNote}</p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={readWholePassage}
              disabled={!supported || reading}
              className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-4 py-2.5 text-sm font-semibold text-slate-950 disabled:opacity-40"
            >
              {reading ? "Reading…" : "▶ Read whole passage"}
            </button>
            {(["tap", "always", "never"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setGlossMode(m)}
                className={`rounded-xl border px-3.5 py-2.5 text-xs capitalize transition ${
                  glossMode === m
                    ? "border-sky-400/50 bg-sky-400/12 text-sky-200"
                    : "border-white/12 text-slate-400 hover:text-slate-200"
                }`}
              >
                {m === "tap" ? "Glosses on tap" : m === "always" ? "Glosses always" : "Greek only"}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setShowEnglish((v) => !v)}
              className="rounded-xl border border-white/12 px-3.5 py-2.5 text-xs text-slate-400 hover:text-slate-200"
            >
              {showEnglish ? "Hide English" : "Show English"}
            </button>
          </div>

          {passage.verses.map((verse) => (
            <article key={verse.ref} className="panel rounded-2xl p-5">
              <div className="mb-3 flex items-center gap-2">
                <SpeakButton
                  text={verse.words.map((w) => w.g).join(" ")}
                  id={`pv-${verse.ref}`}
                  size="sm"
                />
                <span className="text-xs font-medium text-amber-400/80">{verse.ref}</span>
              </div>

              <div className="flex flex-wrap items-end gap-x-2.5 gap-y-3">
                {verse.words.map((word, i) => (
                  <button
                    key={`${verse.ref}-${i}`}
                    type="button"
                    onClick={() => setSelected(word)}
                    className={`group rounded-lg px-1 py-0.5 text-left transition hover:bg-amber-400/12 ${
                      selected?.g === word.g && selected?.p === word.p ? "bg-amber-400/15" : ""
                    }`}
                  >
                    <span className="greek block text-xl leading-tight text-amber-50 group-hover:text-amber-200 sm:text-2xl">
                      {word.g}
                    </span>
                    {glossMode === "always" && (
                      <span className="block text-[10px] leading-tight text-slate-500">{word.e}</span>
                    )}
                  </button>
                ))}
              </div>

              {showEnglish && (
                <p className="mt-4 border-t border-white/8 pt-3 text-sm leading-relaxed text-slate-400">
                  {verse.english}
                </p>
              )}
            </article>
          ))}
        </section>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="panel min-h-[220px] rounded-2xl p-5">
            <h3 className="text-sm font-semibold text-slate-200">Word inspector</h3>
            {selected ? (
              <div className="mt-3 space-y-3">
                <div className="flex items-center gap-3">
                  <SpeakButton text={selected.g} id={`w-${selected.g}`} />
                  <p className="greek text-3xl text-amber-100">{selected.g}</p>
                </div>
                <Field label="Lemma" value={selected.l} greek />
                <Field label="Parsing" value={selected.p} />
                <Field label="Gloss" value={selected.e} />
              </div>
            ) : (
              <p className="mt-3 text-xs leading-relaxed text-slate-500">
                Tap any Greek word in the passage to inspect its dictionary form, full grammatical parsing and
                contextual gloss.
              </p>
            )}
          </div>

          <div className="panel rounded-2xl p-5">
            <h3 className="text-sm font-semibold text-slate-200">Exegetical notebook</h3>
            <p className="mt-1 text-[11px] text-slate-500">Saved against {passage.reference}.</p>
            <textarea
              value={noteBody}
              onChange={(event) => setNoteBody(event.target.value)}
              rows={4}
              placeholder="e.g. ἦν is imperfect — continuous existence, contrasted with ἐγένετο in v.3…"
              className="mt-3 w-full resize-y rounded-xl border border-white/10 bg-slate-900/70 p-3 text-sm text-slate-200 outline-none placeholder:text-slate-600 focus:border-amber-400/50"
            />
            <div className="mt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={saveNote}
                disabled={!noteBody.trim()}
                className="rounded-xl bg-white/8 px-4 py-2 text-sm text-slate-200 transition hover:bg-white/15 disabled:opacity-40"
              >
                Save note
              </button>
              {noteStatus && <span className="text-xs text-emerald-300">{noteStatus}</span>}
            </div>
          </div>

          <VoiceSettings compact />
        </aside>
      </div>
    </div>
  );
}

function Field({ label, value, greek }: { label: string; value: string; greek?: boolean }) {
  return (
    <div className="rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2">
      <p className="text-[10px] uppercase tracking-wider text-slate-500">{label}</p>
      <p className={`mt-0.5 text-sm text-slate-200 ${greek ? "greek text-lg text-amber-100" : ""}`}>
        {value}
      </p>
    </div>
  );
}
