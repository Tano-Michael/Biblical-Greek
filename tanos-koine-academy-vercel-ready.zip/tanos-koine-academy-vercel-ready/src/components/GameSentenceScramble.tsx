"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { GreekAudioProvider, SpeakButton, useGreekAudio } from "@/components/GreekAudio";
import { saveGameScore } from "@/lib/localProgress";

export type ScrambleRound = {
  ref: string;
  words: string[];
  english: string;
};

type Result = { score: number; best: number; rank: number; xpAwarded: number } | null;

export function GameSentenceScramble({ rounds }: { rounds: ScrambleRound[] }) {
  return (
    <GreekAudioProvider>
      <Inner rounds={rounds} />
    </GreekAudioProvider>
  );
}

function shuffleIndexed(length: number): number[] {
  const arr = Array.from({ length }, (_, i) => i);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function Inner({ rounds }: { rounds: ScrambleRound[] }) {
  const { speakSequence } = useGreekAudio();
  const [phase, setPhase] = useState<"ready" | "playing" | "solved" | "ended">("ready");
  const [roundIdx, setRoundIdx] = useState(0);
  const [pool, setPool] = useState<number[]>([]);
  const [chosen, setChosen] = useState<number[]>([]);
  const [attempts, setAttempts] = useState(1);
  const [marks, setMarks] = useState<("right" | "wrong" | null)[]>([]);
  const [score, setScore] = useState(0);
  const [result, setResult] = useState<Result>(null);

  const round = rounds[roundIdx];
  const target = useMemo(() => (round ? round.words : []), [round]);

  function setup(next: number) {
    const r = rounds[next];
    setRoundIdx(next);
    setPool(shuffleIndexed(r.words.length));
    setChosen([]);
    setAttempts(1);
    setMarks([]);
    setPhase("playing");
  }

  function start() {
    setScore(0);
    setResult(null);
    setup(0);
  }

  function pick(i: number) {
    if (phase !== "playing") return;
    setMarks([]);
    if (pool.includes(i)) {
      setPool((p) => p.filter((x) => x !== i));
      setChosen((c) => [...c, i]);
    }
  }

  function unpick(i: number) {
    if (phase !== "playing") return;
    setMarks([]);
    setChosen((c) => c.filter((x) => x !== i));
    setPool((p) => [...p, i]);
  }

  async function check() {
    if (chosen.length !== target.length || !round) return;
    const verdict = chosen.map((i, pos) => (round.words[i] === target[pos] ? ("right" as const) : ("wrong" as const)));
    if (verdict.every((v) => v === "right")) {
      const gain = attempts === 1 ? 20 : attempts === 2 ? 10 : 5;
      setScore((s) => s + gain);
      setPhase("solved");
      await speakSequence([{ text: target.join(" "), id: `scr-${roundIdx}` }]);
    } else {
      setAttempts((a) => a + 1);
      setMarks(verdict);
    }
  }

  async function finish() {
    setPhase("ended");
    const finalScore = score + 20;
    setScore(finalScore);
    try {
      setResult(saveGameScore("sentence-scramble", finalScore));
    } catch {
      setResult(null);
    }
  }

  function next() {
    if (roundIdx + 1 >= rounds.length) {
      void finish();
    } else {
      setup(roundIdx + 1);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header className="rise text-center">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">ΣΥΝΤΑΓΜΑ</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">🧩 Sentence Scramble</h1>
        <p className="mt-2 text-sm text-slate-400">
          {rounds.length} real verses · first try +20, second +10, third +5 · clear all rounds for +20 bonus
        </p>
      </header>

      {phase === "ready" && (
        <div className="panel rounded-3xl p-8 text-center">
          <p className="text-6xl">🧩</p>
          <h2 className="mt-3 text-xl font-semibold text-slate-100">Order is meaning</h2>
          <p className="mx-auto mt-2 max-w-lg text-sm leading-relaxed text-slate-400">
            Tap Greek words in the right sequence to rebuild each verse. Articles and endings carry the
            grammar — notice how the author puts the important words front and centre. The English is a hint,
            not a scaffold.
          </p>
          <button
            type="button"
            onClick={start}
            className="mt-6 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-3.5 text-base font-semibold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:brightness-110"
          >
            Start building →
          </button>
        </div>
      )}

      {(phase === "playing" || phase === "solved") && round && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400">
              Round {roundIdx + 1}/{rounds.length} · <span className="text-amber-300 font-semibold">{score}</span> pts
            </span>
            <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs text-slate-400">
              attempt {attempts}
            </span>
          </div>

          <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.05] px-4 py-3 text-center">
            <p className="text-[11px] uppercase tracking-wider text-amber-300/70">{round.ref}</p>
            <p className="mt-1 text-sm text-slate-300">{round.english}</p>
          </div>

          {/* Build area */}
          <div
            className={`panel min-h-[90px] rounded-2xl p-4 transition ${
              phase === "solved" ? "ring-2 ring-emerald-400/60" : ""
            }`}
          >
            <p className="mb-2 text-[10px] uppercase tracking-wider text-slate-500">your sentence</p>
            <div className="flex flex-wrap items-center gap-1.5">
              {chosen.length === 0 && (
                <span className="text-sm text-slate-600">Tap words below in order…</span>
              )}
              {chosen.map((i, pos) => (
                <button
                  key={`${i}-${pos}`}
                  type="button"
                  onClick={() => unpick(i)}
                  className={`greek rounded-lg border px-2.5 py-1.5 text-lg transition ${
                    phase === "solved"
                      ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-100"
                      : marks[pos] === "wrong"
                        ? "border-rose-400/50 bg-rose-400/10 text-rose-100"
                        : marks[pos] === "right"
                          ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-100"
                          : "border-amber-400/30 bg-amber-400/10 text-amber-100 hover:border-amber-300"
                  }`}
                >
                  {round.words[i]}
                </button>
              ))}
              {phase === "solved" && (
                <span className="ml-1 text-xl text-emerald-300">✓ +{attempts === 1 ? 20 : attempts === 2 ? 10 : 5}</span>
              )}
            </div>
          </div>

          {/* Pool */}
          {phase === "playing" && (
            <>
              <div className="panel min-h-[80px] rounded-2xl p-4">
                <p className="mb-2 text-[10px] uppercase tracking-wider text-slate-500">word pool · taps return them</p>
                <div className="flex flex-wrap items-center gap-1.5">
                  {pool.map((i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => pick(i)}
                      className="greek rounded-lg border border-white/12 bg-white/[0.04] px-2.5 py-1.5 text-lg text-slate-200 transition hover:border-amber-400/50 hover:bg-amber-400/10"
                    >
                      {round.words[i]}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={check}
                  disabled={chosen.length !== target.length}
                  className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-6 py-2.5 text-sm font-semibold text-slate-950 disabled:cursor-not-allowed disabled:opacity-40"
                >
                  Check order
                </button>
                <SpeakButton text={target.join(" ")} id={`hint-${roundIdx}`} label="Hear the verse" />
                <span className="text-xs text-slate-500">say it aloud before peeking at the English</span>
              </div>
            </>
          )}

          {phase === "solved" && (
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={next}
                className="rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 px-6 py-2.5 text-sm font-semibold text-slate-950"
              >
                {roundIdx + 1 >= rounds.length ? "Finish run 🏁" : "Next verse →"}
              </button>
              <p className="greek text-lg text-amber-100/80">{target.join(" ")}</p>
            </div>
          )}
        </div>
      )}

      {phase === "ended" && (
        <div className="panel rounded-3xl p-8 text-center">
          <p className="text-5xl">🏆</p>
          <h2 className="mt-3 text-2xl font-semibold text-slate-100">Run complete!</h2>
          <p className="mt-4 text-5xl font-bold text-amber-300">{score}</p>
          {result && (
            <p className="mt-3 text-sm text-slate-400">
              +{result.xpAwarded} XP · Personal best <span className="font-semibold text-amber-300">{result.best}</span> · Saved on this device
            </p>
          )}
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={start}
              className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-6 py-3 text-sm font-semibold text-slate-950"
            >
              Play again
            </button>
            <Link href="/leaderboard" className="rounded-xl border border-white/15 px-6 py-3 text-sm text-slate-200">
              🏆 Progress board
            </Link>
            <Link href="/games" className="rounded-xl border border-white/15 px-6 py-3 text-sm text-slate-400">
              All games
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
