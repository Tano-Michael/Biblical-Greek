"use client";

import { useEffect, useMemo, useState } from "react";
import { LESSON_CARDS, cardsFor, type LessonCard } from "@/lib/content/lessonCards";
import { TRACK_BY_ID } from "@/lib/content/curriculum";
import { GreekAudioProvider, SpeakButton } from "@/components/GreekAudio";
import { RATING_LABELS, type Rating } from "@/lib/srs";
import { rateLessonCard } from "@/lib/localProgress";

type LessonMeta = { slug: string; title: string; greekTitle: string; trackId: string };

export function LessonCardsBrowser({ lessons }: { lessons: LessonMeta[] }) {
  return (
    <GreekAudioProvider>
      <Inner lessons={lessons} />
    </GreekAudioProvider>
  );
}

function Inner({ lessons }: { lessons: LessonMeta[] }) {
  const [filterTrack, setFilterTrack] = useState<string>("all");
  const [filterType, setFilterType] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [queue, setQueue] = useState<LessonCard[]>([]);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [mode, setMode] = useState<"browse" | "study">("browse");
  const [session, setSession] = useState({ right: 0, total: 0 });

  const allCards = useMemo(() => {
    const list: (LessonCard & { lessonSlug: string; lessonTitle: string; trackId: string })[] = [];
    for (const meta of lessons) {
      for (const card of cardsFor(meta.slug)) {
        list.push({ ...card, lessonSlug: meta.slug, lessonTitle: meta.title, trackId: meta.trackId });
      }
    }
    return list;
  }, [lessons]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return allCards.filter((c) => {
      if (filterTrack !== "all" && c.trackId !== filterTrack) return false;
      if (filterType !== "all" && c.type !== filterType) return false;
      if (q && !`${c.front} ${c.back} ${c.lessonTitle}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [allCards, filterTrack, filterType, search]);

  useEffect(() => {
    if (mode === "study") {
      setQueue(filtered);
      setIndex(0);
      setFlipped(false);
      setSession({ right: 0, total: 0 });
    }
  }, [mode, filtered]);

  const card = queue[index] as (LessonCard & { lessonSlug: string; lessonTitle: string; trackId: string }) | undefined;

  async function rate(rating: Rating) {
    if (!card) return;
    rateLessonCard(`${card.lessonSlug}:${card.id}`, rating);
    setSession((s) => ({ right: s.right + (rating >= 2 ? 1 : 0), total: s.total + 1 }));
    if (rating === 0) {
      setQueue((q) => {
        const copy = [...q];
        const [rem] = copy.splice(index, 1);
        copy.splice(Math.min(index + 2, copy.length), 0, rem);
        return copy;
      });
      setFlipped(false);
    } else if (index + 1 >= queue.length) {
      setQueue([]);
      setMode("browse");
    } else {
      setIndex((i) => i + 1);
      setFlipped(false);
    }
  }

  return (
    <div className="space-y-6">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Κάρται</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Lesson Flashcards</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          {allCards.length} cards across all lessons — words, forms, concepts, sentences. Filter by track or type, then study. Rating affects SRS in lesson view.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search Greek, English, lesson…"
          className="w-full rounded-xl border border-white/10 bg-slate-900/70 px-4 py-2.5 text-sm text-slate-200 outline-none placeholder:text-slate-600 focus:border-amber-400/50 sm:w-72"
        />
        <select
          value={filterTrack}
          onChange={(e) => setFilterTrack(e.target.value)}
          className="rounded-xl border border-white/10 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-200 outline-none"
        >
          <option value="all">All tracks</option>
          <option value="foundations">Foundations</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
          <option value="scholar">Scholar</option>
        </select>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="rounded-xl border border-white/10 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-200 outline-none"
        >
          <option value="all">All types</option>
          <option value="word">Words</option>
          <option value="form">Forms</option>
          <option value="concept">Concepts</option>
          <option value="sentence">Sentences</option>
          <option value="sound">Sounds</option>
        </select>
        <button
          type="button"
          onClick={() => setMode(mode === "browse" ? "study" : "browse")}
          className={`ml-auto rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
            mode === "study" ? "bg-white/10 text-slate-300" : "bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950"
          }`}
        >
          {mode === "study" ? "Browse mode" : `Study ${filtered.length} cards`}
        </button>
      </div>

      {mode === "browse" ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((card) => {
            const track = TRACK_BY_ID[card.trackId as keyof typeof TRACK_BY_ID];
            return (
              <div key={`${card.lessonSlug}-${card.id}`} className="panel group rounded-2xl p-4 transition hover:border-amber-400/30">
                <div className="flex items-start justify-between gap-2">
                  <span className={`rounded-full border px-2 py-0.5 text-[10px] ${track?.chip ?? "border-white/10 text-slate-400"}`}>
                    {track?.name ?? card.trackId}
                  </span>
                  <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] text-slate-400">{card.type}</span>
                </div>
                <div className="mt-3 flex items-start gap-2">
                  <SpeakButton text={card.front} id={`b-${card.id}`} size="sm" />
                  <p className="greek text-lg leading-tight text-amber-100">{card.front}</p>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-slate-500 group-hover:text-slate-300">→ {card.back}</p>
                {card.hint && <p className="mt-1 text-[11px] text-slate-600">Hint: {card.hint}</p>}
                <p className="mt-2 text-[10px] text-slate-600">{card.lessonTitle}</p>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="panel rounded-3xl p-6 sm:p-8">
          {!card ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <p className="greek text-3xl text-amber-200">εὖγε!</p>
              <p className="mt-1 text-[11px] uppercase tracking-wider text-amber-300/60">EV-yeh · well done</p>
              <p className="mt-2 text-sm text-slate-300">
                Done — {session.right}/{session.total} correct.
              </p>
              <button
                type="button"
                onClick={() => setMode("browse")}
                className="mt-4 rounded-xl bg-white/10 px-5 py-2.5 text-sm text-slate-200"
              >
                Back to browse
              </button>
            </div>
          ) : (
            <>
              <div className="mb-4 flex items-center justify-between text-xs text-slate-500">
                <span>
                  {index + 1} / {queue.length}
                </span>
                <span>
                  {card.lessonTitle} · {card.type}
                </span>
              </div>

              <button
                type="button"
                onClick={() => setFlipped((f) => !f)}
                className="flex min-h-[240px] w-full flex-col items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 to-slate-800 p-6 text-center hover:border-amber-400/30"
              >
                <p className={`text-center ${/[\u0370-\u03FF\u1F00-\u1FFF]/.test(flipped ? card.back : card.front) ? "greek text-3xl text-amber-100" : "text-2xl font-semibold text-slate-100"}`}>
                  {flipped ? card.back : card.front}
                </p>
                {flipped && card.extra && <p className="mt-3 max-w-xl text-xs leading-relaxed text-slate-400">{card.extra}</p>}
                {flipped && card.hint && <p className="mt-2 text-[11px] text-slate-500">Hint: {card.hint}</p>}
                <span className="mt-4 text-[11px] uppercase tracking-wider text-slate-600">{flipped ? "Answer · tap to hide" : "Question · tap to reveal"}</span>
              </button>

              {flipped ? (
                <div className="mt-6 grid grid-cols-4 gap-2">
                  {RATING_LABELS.map((r) => (
                    <button key={r.value} type="button" onClick={() => rate(r.value as Rating)} className={`rounded-xl px-2 py-3 text-xs font-semibold text-white ${r.tone}`}>
                      {r.label}
                    </button>
                  ))}
                </div>
              ) : (
                <button type="button" onClick={() => setFlipped(true)} className="mx-auto mt-6 block rounded-xl border border-white/15 px-5 py-2.5 text-sm text-slate-300">
                  Show answer
                </button>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
