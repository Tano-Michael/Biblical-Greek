"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  CASES,
  GENDERS,
  MOODS,
  NUMBERS,
  TENSES,
  VOICES,
  type Drill,
} from "@/lib/content/parsing";
import { GreekAudioProvider, SpeakButton } from "@/components/GreekAudio";
import { saveGameScore } from "@/lib/localProgress";

type Result = { score: number; best: number; rank: number; xpAwarded: number } | null;

const DURATION = 45;

export function GameParsingRush({ drills }: { drills: Drill[] }) {
  return (
    <GreekAudioProvider>
      <Inner drills={drills} />
    </GreekAudioProvider>
  );
}

function Inner({ drills }: { drills: Drill[] }) {
  const [phase, setPhase] = useState<"ready" | "playing" | "ended">("ready");
  const [timeLeft, setTimeLeft] = useState(DURATION);
  const [score, setScore] = useState(0);
  const [forms, setForms] = useState(0);
  const [slotsRight, setSlotsRight] = useState(0);
  const [fullParses, setFullParses] = useState(0);
  const [picks, setPicks] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<Record<string, string>>({});
  const [seed, setSeed] = useState(0);
  const [result, setResult] = useState<Result>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const scoreRef = useRef(0);
  scoreRef.current = score;
  const endRef = useRef<() => void>(() => {});

  const current = useMemo(() => drills[Math.floor(Math.random() * drills.length)], [drills, seed]); // eslint-disable-line react-hooks/exhaustive-deps

  const slots = useMemo(() => {
    if (current.kind === "noun") {
      return [
        { key: "case", label: "Case", options: CASES, answer: current.case },
        { key: "number", label: "Number", options: NUMBERS, answer: current.number },
        { key: "gender", label: "Gender", options: GENDERS, answer: current.gender },
      ];
    }
    return [
      { key: "tense", label: "Tense-form", options: TENSES, answer: current.tense },
      { key: "voice", label: "Voice", options: VOICES, answer: current.voice },
      { key: "mood", label: "Mood", options: MOODS, answer: current.mood },
    ];
  }, [current]);

  const endGame = useCallback(async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase("ended");
    try {
      setResult(saveGameScore("parsing-rush", scoreRef.current));
    } catch {
      setResult(null);
    }
  }, []);

  endRef.current = () => void endGame();

  function start() {
    setPhase("playing");
    setTimeLeft(DURATION);
    setScore(0);
    setForms(0);
    setSlotsRight(0);
    setFullParses(0);
    setResult(null);
    setPicks({});
    setFeedback({});
    setSeed((s) => s + 1);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          endRef.current();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
  }

  useEffect(
    () => () => {
      if (timerRef.current) clearInterval(timerRef.current);
    },
    [],
  );

  function submit() {
    if (Object.keys(picks).length < slots.length) return;
    const verdict: Record<string, string> = {};
    let right = 0;
    for (const slot of slots) {
      const ok = picks[slot.key] === slot.answer;
      verdict[slot.key] = ok ? "right" : "wrong";
      if (ok) right++;
    }
    const full = right === slots.length;
    const gained = right * 4 + (full ? 4 : 0);
    setScore((s) => s + gained);
    setForms((n) => n + 1);
    setSlotsRight((n) => n + right);
    if (full) setFullParses((n) => n + 1);
    setFeedback(verdict);
    setTimeout(() => {
      setPicks({});
      setFeedback({});
      setSeed((s) => s + 1);
    }, full ? 350 : 900);
  }

  const pct = Math.round((timeLeft / DURATION) * 100);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header className="rise text-center">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">ΤΑΧΟΣ</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">🏋️ Parsing Rush</h1>
        <p className="mt-2 text-sm text-slate-400">
          45 seconds · +4 per correct slot · +4 bonus for full parse · wrong slot shows you the answer
        </p>
      </header>

      {phase === "ready" && (
        <div className="panel rounded-3xl p-8 text-center">
          <p className="text-6xl">🏋️</p>
          <h2 className="mt-3 text-xl font-semibold text-slate-100">Morphology under pressure</h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-400">
            Nouns need case · number · gender. Verbs need tense-form · voice · mood. Speed comes from
            recognising the morphemes — the -σα-, the -ντ-, the augment — not from charts.
          </p>
          <button
            type="button"
            onClick={start}
            className="mt-6 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-3.5 text-base font-semibold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:brightness-110"
          >
            Start rush →
          </button>
        </div>
      )}

      {phase === "playing" && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-white/10">
              <div
                className={`h-full rounded-full transition-all duration-1000 ${
                  timeLeft <= 10 ? "bg-rose-500" : "bg-gradient-to-r from-amber-400 to-orange-500"
                }`}
                style={{ width: `${pct}%` }}
              />
            </div>
            <span className={`w-12 text-right text-lg font-bold ${timeLeft <= 10 ? "text-rose-400" : "text-slate-200"}`}>
              {timeLeft}s
            </span>
          </div>

          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400">
              Score <span className="text-xl font-bold text-amber-300">{score}</span>
            </span>
            <span className="text-slate-500">
              {forms} parsed · {fullParses} full
            </span>
          </div>

          <div className="panel rounded-3xl p-7 text-center">
            <div className="flex items-center justify-center gap-3">
              <SpeakButton text={current.form} id={`pr-${current.form}`} size="lg" />
              <p className="greek text-4xl text-amber-100 sm:text-5xl">{current.form}</p>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              from <span className="greek text-sm">{current.lemma}</span> · {current.kind}
            </p>

            <div className="mt-6 space-y-4 text-left">
              {slots.map((slot) => (
                <div key={slot.key}>
                  <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
                    {slot.label}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {slot.options.map((option) => {
                      const picked = picks[slot.key] === option;
                      const judged = feedback[slot.key] !== undefined;
                      const isAnswer = slot.answer === option;
                      let tone = "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/30";
                      if (judged && isAnswer) tone = "border-emerald-400/50 bg-emerald-400/12 text-emerald-100";
                      else if (judged && picked) tone = "border-rose-400/50 bg-rose-400/12 text-rose-100";
                      else if (picked) tone = "border-amber-400/60 bg-amber-400/12 text-amber-100";
                      return (
                        <button
                          key={option}
                          type="button"
                          disabled={judged}
                          onClick={() => setPicks((p) => ({ ...p, [slot.key]: option }))}
                          className={`rounded-lg border px-2.5 py-1.5 text-xs transition ${tone} disabled:cursor-default`}
                        >
                          {option}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={submit}
              disabled={Object.keys(picks).length < slots.length || Object.keys(feedback).length > 0}
              className="mt-6 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-6 py-2.5 text-sm font-semibold text-slate-950 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Lock it in
            </button>
          </div>
        </div>
      )}

      {phase === "ended" && (
        <div className="panel rounded-3xl p-8 text-center">
          <p className="text-5xl">🏁</p>
          <h2 className="mt-3 text-2xl font-semibold text-slate-100">Rush over!</h2>
          <p className="mt-4 text-5xl font-bold text-amber-300">{score}</p>
          <div className="mx-auto mt-5 grid max-w-md grid-cols-3 gap-3 text-sm">
            <div className="rounded-xl bg-white/[0.04] p-3">
              <p className="text-lg font-semibold text-slate-100">{forms}</p>
              <p className="text-[10px] uppercase tracking-wider text-slate-500">forms</p>
            </div>
            <div className="rounded-xl bg-white/[0.04] p-3">
              <p className="text-lg font-semibold text-slate-100">{fullParses}</p>
              <p className="text-[10px] uppercase tracking-wider text-slate-500">full parses</p>
            </div>
            <div className="rounded-xl bg-white/[0.04] p-3">
              <p className="text-lg font-semibold text-emerald-300">{result ? `+${result.xpAwarded}` : "…"}</p>
              <p className="text-[10px] uppercase tracking-wider text-slate-500">XP earned</p>
            </div>
          </div>
          {result && (
            <p className="mt-4 text-sm text-slate-400">
              Personal best: <span className="font-semibold text-amber-300">{result.best}</span> · Saved on this device
            </p>
          )}
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={start}
              className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-6 py-3 text-sm font-semibold text-slate-950"
            >
              Play again
            </button>
            <Link href="/leaderboard" className="rounded-xl border border-white/15 px-6 py-3 text-sm text-slate-200">
              🏆 Progress board
            </Link>
            <Link href="/games" className="rounded-xl border border-white/15 px-6 py-3 text-sm text-slate-400">
              All games
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
