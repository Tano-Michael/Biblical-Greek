"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Vocab } from "@/lib/content/vocabulary";
import { GreekAudioProvider, SpeakButton } from "@/components/GreekAudio";
import { saveGameScore } from "@/lib/localProgress";

type Result = { score: number; best: number; rank: number; xpAwarded: number; playCount: number };

const DURATION = 60;
const WRONG_PENALTY = 3;

export function GameWordSprint({ pool }: { pool: Vocab[] }) {
  return (
    <GreekAudioProvider>
      <Inner pool={pool} />
    </GreekAudioProvider>
  );
}

function Inner({ pool }: { pool: Vocab[] }) {
  const [phase, setPhase] = useState<"ready" | "playing" | "ended">("ready");
  const [difficulty, setDifficulty] = useState<"foundations" | "advanced" | "all">("foundations");
  const [timeLeft, setTimeLeft] = useState(DURATION);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [answered, setAnswered] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [flash, setFlash] = useState<"right" | "wrong" | null>(null);
  const [current, setCurrent] = useState<{ word: Vocab; options: string[] } | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const filtered = useMemo(() => {
    if (difficulty === "foundations") return pool.filter((w) => w.level === "foundations");
    if (difficulty === "advanced")
      return pool.filter((w) => w.level === "intermediate" || w.level === "advanced" || w.level === "scholar");
    return pool;
  }, [pool, difficulty]);

  const nextQuestion = useCallback(() => {
    const words = filtered;
    const word = words[Math.floor(Math.random() * words.length)];
    const samePos = words.filter((w) => w.id !== word.id && w.pos === word.pos);
    const others = words.filter((w) => w.id !== word.id);
    const source = samePos.length >= 3 ? samePos : others;
    const optionsSet = new Set<string>();
    let guard = 0;
    while (optionsSet.size < 3 && guard < 100) {
      guard++;
      const candidate = source[Math.floor(Math.random() * source.length)];
      if (candidate && candidate.gloss !== word.gloss) optionsSet.add(candidate.gloss);
    }
    const options = [...optionsSet, word.gloss].sort(() => Math.random() - 0.5);
    setCurrent({ word, options });
  }, [filtered]);

  const scoreRef = useRef(0);
  scoreRef.current = score;
  const endGameRef = useRef<() => void>(() => {});

  const endGame = useCallback(async (finalScore: number) => {
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase("ended");
    try {
      setResult(saveGameScore("word-sprint", finalScore));
    } catch {
      setResult(null);
    }
  }, [difficulty]);

  endGameRef.current = () => void endGame(scoreRef.current);

  function start() {
    setPhase("playing");
    setTimeLeft(DURATION);
    setScore(0);
    setStreak(0);
    setBestCombo(0);
    setAnswered(0);
    setCorrect(0);
    setResult(null);
    setFlash(null);
    nextQuestion();
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          endGameRef.current();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
  }

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
  }, []);

  function multiplierFor(s: number) {
    if (s >= 12) return 4;
    if (s >= 6) return 3;
    if (s >= 3) return 2;
    return 1;
  }

  function choose(gloss: string) {
    if (!current || phase !== "playing") return;
    const isRight = gloss === current.word.gloss;
    setAnswered((n) => n + 1);
    if (isRight) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      setBestCombo((b) => Math.max(b, newStreak));
      const gained = 10 * multiplierFor(newStreak - 1);
      setScore((s) => s + gained);
      setCorrect((n) => n + 1);
      setFlash("right");
    } else {
      setStreak(0);
      setTimeLeft((t) => Math.max(0, t - WRONG_PENALTY));
      setFlash("wrong");
    }
    setTimeout(() => {
      setFlash(null);
      nextQuestion();
    }, isRight ? 180 : 650);
  }

  const pct = Math.round((timeLeft / DURATION) * 100);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header className="rise text-center">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">ΔΡΟΜΟΣ</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">⚡ Word Sprint</h1>
        <p className="mt-2 text-sm text-slate-400">
          {DURATION} seconds · combos ×2 at 3 streak, ×3 at 6, ×4 at 12 · wrong answer costs {WRONG_PENALTY}s
        </p>
      </header>

      {phase === "ready" && (
        <div className="panel rounded-3xl p-8 text-center">
          <p className="text-6xl">⚡</p>
          <h2 className="mt-3 text-xl font-semibold text-slate-100">Ready to sprint?</h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-400">
            Match each Greek word to its meaning as fast as you can. Precision builds combos — combo is where
            the points are.
          </p>
          <div className="mt-5 flex justify-center gap-2">
            {(
              [
                ["foundations", "Foundations"],
                ["advanced", "Intermediate+"],
                ["all", "Everything"],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => setDifficulty(value)}
                className={`rounded-xl px-4 py-2.5 text-sm font-medium transition ${
                  difficulty === value
                    ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/40"
                    : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <p className="mt-3 text-xs text-slate-500">{filtered.length} words in this deck</p>
          <button
            type="button"
            onClick={start}
            className="mt-6 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-3.5 text-base font-semibold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:brightness-110"
          >
            Start sprint →
          </button>
        </div>
      )}

      {phase === "playing" && current && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-white/10">
              <div
                className={`h-full rounded-full transition-all duration-1000 ${
                  timeLeft <= 10 ? "bg-rose-500" : "bg-gradient-to-r from-amber-400 to-orange-500"
                }`}
                style={{ width: `${pct}%` }}
              />
            </div>
            <span className={`w-12 text-right text-lg font-bold ${timeLeft <= 10 ? "text-rose-400" : "text-slate-200"}`}>
              {timeLeft}s
            </span>
          </div>

          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400">
              Score <span className="text-xl font-bold text-amber-300">{score}</span>
            </span>
            <span
              className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${
                streak >= 6
                  ? "border-amber-400/50 bg-amber-400/15 text-amber-200"
                  : streak >= 3
                    ? "border-sky-400/40 bg-sky-400/10 text-sky-200"
                    : "border-white/10 bg-white/[0.03] text-slate-400"
              }`}
            >
              {streak > 0 ? `🔥 ×${multiplierFor(streak)} — ${streak} streak` : "build a streak for combos"}
            </span>
            <span className="text-slate-500">
              {correct}/{answered}
            </span>
          </div>

          <div
            className={`panel rounded-3xl p-8 text-center transition ${
              flash === "right"
                ? "ring-2 ring-emerald-400/60"
                : flash === "wrong"
                  ? "ring-2 ring-rose-400/60"
                  : ""
            }`}
          >
            <div className="flex items-center justify-center gap-3">
              <SpeakButton text={current.word.lemma.split(",")[0]} size="lg" />
              <p className="greek text-4xl leading-tight text-amber-100 sm:text-5xl">{current.word.lemma}</p>
            </div>
            {flash === "wrong" && (
              <p className="mt-3 text-sm font-medium text-emerald-300">
                → {current.word.gloss}
              </p>
            )}
            <p className="mt-2 text-xs text-slate-500">
              {current.word.translit} · {current.word.pos}
              {current.word.frequency > 0 ? ` · ${current.word.frequency}× in the NT` : ""}
            </p>
          </div>

          <div className="grid gap-2.5 sm:grid-cols-2">
            {current.options.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => choose(option)}
                className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-4 text-left text-sm text-slate-200 transition hover:border-amber-400/50 hover:bg-amber-400/10"
              >
                {option}
              </button>
            ))}
          </div>
        </div>
      )}

      {phase === "ended" && (
        <div className="panel rounded-3xl p-8 text-center">
          <p className="text-5xl">🏁</p>
          <h2 className="mt-3 text-2xl font-semibold text-slate-100">Time!</h2>
          <p className="mt-4 text-5xl font-bold text-amber-300">{score}</p>
          <div className="mx-auto mt-5 grid max-w-md grid-cols-3 gap-3 text-sm">
            <div className="rounded-xl bg-white/[0.04] p-3">
              <p className="text-lg font-semibold text-slate-100">{correct}/{answered}</p>
              <p className="text-[10px] uppercase tracking-wider text-slate-500">accuracy</p>
            </div>
            <div className="rounded-xl bg-white/[0.04] p-3">
              <p className="text-lg font-semibold text-slate-100">🔥 {bestCombo}</p>
              <p className="text-[10px] uppercase tracking-wider text-slate-500">best streak</p>
            </div>
            <div className="rounded-xl bg-white/[0.04] p-3">
              <p className="text-lg font-semibold text-emerald-300">
                {result ? `+${result.xpAwarded}` : "…"}
              </p>
              <p className="text-[10px] uppercase tracking-wider text-slate-500">XP earned</p>
            </div>
          </div>
          {result && (
            <p className="mt-4 text-sm text-slate-400">
              Personal best: <span className="font-semibold text-amber-300">{result.best}</span> · Saved on this device
            </p>
          )}
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={start}
              className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-6 py-3 text-sm font-semibold text-slate-950"
            >
              Play again
            </button>
            <Link
              href="/leaderboard"
              className="rounded-xl border border-white/15 px-6 py-3 text-sm text-slate-200 hover:border-amber-400/40"
            >
              🏆 Progress board
            </Link>
            <Link href="/games" className="rounded-xl border border-white/15 px-6 py-3 text-sm text-slate-400">
              All games
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
