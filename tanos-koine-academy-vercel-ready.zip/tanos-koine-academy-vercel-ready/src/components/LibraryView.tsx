"use client";

import { useMemo, useState } from "react";
import type { MediaItem } from "@/lib/content/media";
import { VideoEmbed } from "@/components/VideoEmbed";

const CATEGORIES = [
  { id: "all", label: "Everything" },
  { id: "course", label: "Full courses" },
  { id: "immersion", label: "Immersion & stories" },
  { id: "audio-bible", label: "Audio Bibles" },
  { id: "pronunciation", label: "Pronunciation" },
  { id: "grammar", label: "Grammar" },
  { id: "scholarship", label: "Scholarship" },
];

const LEVELS = [
  { id: "all", label: "All levels" },
  { id: "beginner", label: "Beginner" },
  { id: "intermediate", label: "Intermediate" },
  { id: "advanced", label: "Advanced" },
  { id: "scholar", label: "Scholar" },
];

export function LibraryView({ items }: { items: MediaItem[] }) {
  const [category, setCategory] = useState("all");
  const [level, setLevel] = useState("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((item) => {
      if (category !== "all" && item.category !== category) return false;
      if (level !== "all" && item.level !== "all" && item.level !== level) return false;
      if (
        q &&
        !`${item.title} ${item.creator} ${item.description}`.toLowerCase().includes(q)
      )
        return false;
      return true;
    });
  }, [items, category, level, query]);

  const embeds = filtered.filter((i) => i.youtubeId);
  const links = filtered.filter((i) => !i.youtubeId);

  return (
    <div className="space-y-6">
      <header className="rise">
        <p className="greek text-sm tracking-[0.25em] text-amber-400/70">Βιβλιοθήκη</p>
        <h1 className="mt-1 text-3xl font-semibold text-slate-50 sm:text-4xl">Media Library</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          The best free Koine Greek video and audio on the internet, curated and sorted. Complete audio New
          Testaments, full university-level video courses, comprehensible-input channels, and seminar
          lectures from the scholars who write the grammars.
        </p>
      </header>

      <div className="space-y-3">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search titles, teachers, topics…"
          className="w-full rounded-xl border border-white/10 bg-slate-900/70 px-4 py-3 text-sm text-slate-200 outline-none placeholder:text-slate-600 focus:border-amber-400/50"
        />
        <div className="flex flex-wrap gap-1.5">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCategory(c.id)}
              className={`rounded-lg px-3 py-2 text-xs font-medium transition ${
                category === c.id
                  ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/30"
                  : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-1.5">
          {LEVELS.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => setLevel(l.id)}
              className={`rounded-lg px-3 py-1.5 text-[11px] transition ${
                level === l.id
                  ? "bg-sky-400/15 text-sky-200 ring-1 ring-sky-400/30"
                  : "bg-white/[0.03] text-slate-500 hover:text-slate-300"
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
      </div>

      <p className="text-xs text-slate-500">
        {filtered.length} resource{filtered.length === 1 ? "" : "s"}
      </p>

      {embeds.length > 0 && (
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {embeds.map((item) => (
            <VideoEmbed
              key={item.id}
              id={item.youtubeId!}
              kind={item.kind === "playlist" ? "playlist" : "video"}
              title={item.title}
              channel={`${item.creator}${item.minutes ? ` · ${item.minutes}` : ""}`}
              note={item.description}
              compact
            />
          ))}
        </section>
      )}

      {links.length > 0 && (
        <section>
          <h2 className="text-sm font-semibold text-slate-200">Websites, downloads & podcasts</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {links.map((item) => (
              <a
                key={item.id}
                href={item.url}
                target="_blank"
                rel="noreferrer noopener"
                className="panel panel-hover flex items-start gap-3 rounded-2xl p-4 transition"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5 text-lg">
                  {item.kind === "podcast" ? "🎙" : item.category === "audio-bible" ? "🎧" : "🔗"}
                </span>
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold text-slate-100">{item.title}</h3>
                  <p className="text-xs text-amber-300/80">
                    {item.creator}
                    {item.minutes ? ` · ${item.minutes}` : ""}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-slate-400">{item.description}</p>
                  <span className="mt-1.5 inline-block text-[11px] text-slate-500">Visit ↗</span>
                </div>
              </a>
            ))}
          </div>
        </section>
      )}

      {filtered.length === 0 && (
        <p className="panel rounded-2xl p-8 text-center text-sm text-slate-500">
          Nothing matches those filters. Try clearing the search.
        </p>
      )}
    </div>
  );
}
