# Tano's Koine Academy

A deployment-ready Biblical Greek learning site built with Next.js, React, TypeScript and Tailwind CSS.

## Vercel-ready edition

This package has been prepared for a simple Vercel deployment:

- No PostgreSQL database is required.
- No API key or environment variable is required.
- No server-side migration is required.
- The site builds as a static Next.js export.
- Lessons, quizzes, flashcards, spaced repetition, assignments, notes, XP, streaks and game records work immediately.
- Learning progress is stored privately in each learner's browser with `localStorage`.

Because progress is stored in the browser, it remains on that device and browser. It is not shared between learners or devices. A shared login/database edition can be added later without blocking this first public launch.

## Deploy with Vercel and GitHub

1. Extract this ZIP.
2. Create a new empty GitHub repository.
3. Upload **all files and folders from this project root** to the repository. Make sure `package.json` is at the repository root.
4. In Vercel, choose **Add New → Project**.
5. Import the GitHub repository.
6. Vercel should detect **Next.js** automatically.
7. Do not add environment variables.
8. Click **Deploy**.

The included `vercel.json` already selects the Next.js framework and the production build command.

## Deploy with the Vercel CLI

From the extracted project folder:

```bash
npm install
npm run build
npx vercel --prod
```

## Local development

```bash
npm install
npm run dev
```

Open the local address shown in the terminal.

## Production checks

```bash
npm run typecheck
npm run lint
npm run build
```

## Important files

- `src/lib/localProgress.ts` — browser-based progress, notes, assignments, SRS, XP and game records.
- `src/lib/content/` — curriculum, vocabulary, readings, assignments, media and lesson materials.
- `src/app/layout.tsx` — site metadata and global layout.
- `src/components/SiteNav.tsx` — navigation and academy name.
- `next.config.ts` — static export configuration.
- `vercel.json` — Vercel project defaults.

## Change the academy name

Search the project for `Tano's Koine Academy` and `TANO'S`, then replace those texts with the preferred public name before deployment.
